using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using PMusic.Core;
using Windows.Media;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.Storage.Streams;

namespace PMusic.Player
{
    /// <summary>Error con mensaje para la persona (no técnico).</summary>
    public sealed class UserError : Exception
    {
        public UserError(string message) : base(message) { }
    }

    /// <summary>
    /// El reproductor de música. Usa el reproductor de Windows, así la música sigue con la pantalla
    /// bloqueada y aparecen la portada, el nombre y los botones anterior / pausa / siguiente en la
    /// pantalla de bloqueo, en el panel de volumen y con las teclas multimedia.
    /// </summary>
    public static class Engine
    {
        private static MediaPlayer _mp;
        public static readonly List<Song> Queue = new List<Song>();
        private static List<Song> _unshuffled;
        public static int Index { get; private set; } = -1;
        public static Song Current => Index >= 0 && Index < Queue.Count ? Queue[Index] : null;
        public static string Source { get; private set; } = "";
        public static bool Loading { get; private set; }
        public static bool Playing { get; private set; }
        public static bool RadioMode { get; private set; }

        public static event Action SongChanged;
        public static event Action StateChanged;
        public static event Action QueueChanged;
        public static event Action<string> Message;

        private static int _gen;
        private static CancellationTokenSource _cts;
        private static bool _usingUrl, _triedFallback, _resolving, _opened, _autoPlay;
        private static int _failures;
        private static double _resumeAt;
        private static string _radioSeed, _radioCont;
        private static bool _radioBusy;
        private static DispatcherTimer _tick;
        private static DateTime _lastSave = DateTime.MinValue;
        private static readonly Random Rng = new Random();

        // temporizador para dormir
        public static DateTime? SleepAt { get; private set; }
        public static bool SleepEndOfSong { get; private set; }

        public static void Init()
        {
            try
            {
                _mp = new MediaPlayer
                {
                    AudioCategory = MediaPlayerAudioCategory.Media,
                    AutoPlay = false,
                    Volume = Prefs.S.Volume
                };
                _mp.CommandManager.IsEnabled = true;
                _mp.CommandManager.NextBehavior.EnablingRule = MediaCommandEnablingRule.Always;
                _mp.CommandManager.PreviousBehavior.EnablingRule = MediaCommandEnablingRule.Always;
                _mp.CommandManager.NextReceived += (s, e) => { e.Handled = true; UiThread.Post(() => Next(false)); };
                _mp.CommandManager.PreviousReceived += (s, e) => { e.Handled = true; UiThread.Post(Previous); };
                _mp.CommandManager.PauseReceived += (s, e) =>
                {
                    // Pausa que manda Windows al bloquear / apagar pantalla: se ignora.
                    if (SystemMoment(4)) { e.Handled = true; Log.Write("Pausa del sistema ignorada"); return; }
                    _wantPlay = false;
                };
                _mp.CommandManager.PlayReceived += (s, e) => { _wantPlay = true; };
                _mp.MediaOpened += (s, e) => UiThread.Post(OnOpened);
                _mp.MediaEnded += (s, e) => UiThread.Post(OnEnded);
                _mp.MediaFailed += (s, e) =>
                {
                    string detail = e.Error + " " + (e.ErrorMessage ?? "") + (e.ExtendedErrorCode != null ? " 0x" + e.ExtendedErrorCode.HResult.ToString("X8") : "");
                    UiThread.Post(() => OnFailed(detail));
                };
                _mp.PlaybackSession.PlaybackStateChanged += (s, e) => UiThread.Post(OnState);
            }
            catch (Exception e)
            {
                Log.Error(e, "MediaPlayer");
            }
            _tick = UiThread.Every(1000, OnTick);
        }

        public static bool Available => _mp != null;

        // ------------------------------------------------------------ tiempos

        public static double Position
        {
            get
            {
                try { return _mp != null && _opened ? _mp.PlaybackSession.Position.TotalSeconds : _resumeAt; }
                catch { return 0; }
            }
        }

        public static double Duration
        {
            get
            {
                double d = 0;
                try { if (_mp != null && _opened) d = _mp.PlaybackSession.NaturalDuration.TotalSeconds; } catch { }
                if (d <= 0 || double.IsNaN(d) || d > 86400 * 2) d = Current?.Seconds ?? 0;
                return d;
            }
        }

        public static void Seek(double seconds)
        {
            if (_mp == null) return;
            _lastPos = Math.Max(0, seconds);
            if (!_opened) { _resumeAt = Math.Max(0, seconds); StateChanged?.Invoke(); return; }
            try
            {
                double d = Duration;
                if (d > 0) seconds = Math.Min(seconds, d - 0.5);
                _mp.PlaybackSession.Position = TimeSpan.FromSeconds(Math.Max(0, seconds));
            }
            catch { }
        }

        public static double Volume
        {
            get => _mp?.Volume ?? Prefs.S.Volume;
            set
            {
                double v = Math.Max(0, Math.Min(1, value));
                if (_mp != null) _mp.Volume = v;
                if (v > 0.01) { Prefs.S.Volume = v; Prefs.Save(); }
            }
        }

        public static bool Muted
        {
            get => _mp != null && _mp.IsMuted;
            set { if (_mp != null) _mp.IsMuted = value; StateChanged?.Invoke(); }
        }

        // ------------------------------------------------------------ cola

        public static void PlayList(IList<Song> songs, int start, string source, bool shuffle = false)
        {
            var list = songs.Where(s => s != null && !s.PhoneOnly).Select(s => s.Clone()).ToList();
            if (list.Count == 0) { Message?.Invoke("No hay canciones para reproducir."); return; }
            Song first = start >= 0 && start < songs.Count && songs[start] != null ? songs[start] : null;
            int idx = first == null ? 0 : list.FindIndex(x => x.Key == first.Key);
            if (shuffle) idx = Rng.Next(list.Count);
            if (idx < 0) idx = 0;
            RadioMode = false;
            _radioSeed = null;
            _radioCont = null;
            Queue.Clear();
            Queue.AddRange(list);
            Index = idx;
            Source = source ?? "";
            _unshuffled = null;
            if (shuffle && !Prefs.S.Shuffle) { Prefs.S.Shuffle = true; Prefs.Save(); }
            if (Prefs.S.Shuffle) ShuffleRest();
            QueueChanged?.Invoke();
            Load(true, 0);
        }

        /// <summary>Mix de canciones parecidas a esta (la radio del catálogo, como en el teléfono).</summary>
        public static void StartRadio(Song seed, string source = null)
        {
            if (seed == null) return;
            Queue.Clear();
            Queue.Add(seed.Clone());
            Index = 0;
            _unshuffled = null;
            RadioMode = true;
            _radioSeed = seed.VideoId;
            _radioCont = null;
            Source = source ?? "Mix · " + seed.Title;
            QueueChanged?.Invoke();
            Load(true, 0);
            if (_radioSeed != null) ExtendRadio(false);
        }

        public static void PlayNext(Song s)
        {
            if (s == null) return;
            if (Current == null) { PlayList(new List<Song> { s }, 0, "Cola"); return; }
            Queue.Insert(Index + 1, s.Clone());
            _unshuffled?.Add(s.Clone());
            QueueChanged?.Invoke();
            Message?.Invoke("Sonará después de esta canción");
        }

        public static void AddToQueue(Song s)
        {
            if (s == null) return;
            if (Current == null) { PlayList(new List<Song> { s }, 0, "Cola"); return; }
            Queue.Add(s.Clone());
            _unshuffled?.Add(s.Clone());
            QueueChanged?.Invoke();
            Message?.Invoke("Agregada a la cola");
        }

        public static void AddRange(IEnumerable<Song> songs)
        {
            var add = songs.Where(x => x != null && !x.PhoneOnly).Select(x => x.Clone()).ToList();
            Queue.AddRange(add);
            _unshuffled?.AddRange(add);
            QueueChanged?.Invoke();
        }

        public static void RemoveAt(int i)
        {
            if (i < 0 || i >= Queue.Count || i == Index) return;
            var s = Queue[i];
            Queue.RemoveAt(i);
            _unshuffled?.Remove(s);
            if (i < Index) Index--;
            QueueChanged?.Invoke();
        }

        public static void Move(int from, int to)
        {
            if (from < 0 || from >= Queue.Count || to < 0 || to >= Queue.Count || from == to) return;
            var cur = Current;
            var s = Queue[from];
            Queue.RemoveAt(from);
            Queue.Insert(to, s);
            Index = Queue.IndexOf(cur);
            QueueChanged?.Invoke();
        }

        public static void JumpTo(int i)
        {
            if (i < 0 || i >= Queue.Count) return;
            Index = i;
            Load(true, 0);
        }

        public static void ClearUpcoming()
        {
            if (Current == null) return;
            if (Index + 1 < Queue.Count) Queue.RemoveRange(Index + 1, Queue.Count - Index - 1);
            _unshuffled = null;
            RadioMode = false;
            QueueChanged?.Invoke();
        }

        private static void ShuffleRest()
        {
            var cur = Current;
            if (cur == null) return;
            _unshuffled = Queue.ToList();
            var rest = Queue.Where((s, i) => i != Index).ToList();
            for (int i = rest.Count - 1; i > 0; i--)
            {
                int j = Rng.Next(i + 1);
                var t = rest[i];
                rest[i] = rest[j];
                rest[j] = t;
            }
            Queue.Clear();
            Queue.Add(cur);
            Queue.AddRange(rest);
            Index = 0;
        }

        public static void SetShuffle(bool on)
        {
            Prefs.S.Shuffle = on;
            Prefs.Save();
            var cur = Current;
            if (on) ShuffleRest();
            else if (_unshuffled != null && cur != null)
            {
                Queue.Clear();
                Queue.AddRange(_unshuffled);
                Index = Math.Max(0, Queue.IndexOf(cur));
                _unshuffled = null;
            }
            QueueChanged?.Invoke();
            StateChanged?.Invoke();
        }

        /// <summary>0 = sin repetir, 1 = repetir lista, 2 = repetir canción.</summary>
        public static void CycleRepeat()
        {
            Prefs.S.Repeat = (Prefs.S.Repeat + 1) % 3;
            Prefs.Save();
            StateChanged?.Invoke();
        }

        // ------------------------------------------------------------ controles

        private static DateTime _loadStarted = DateTime.Now;

        /// <summary>Texto mientras carga (dice si se está preparando el reproductor la primera vez).</summary>
        public static string LoadingText
        {
            get
            {
                double secs = (DateTime.Now - _loadStarted).TotalSeconds;
                string st = Streams.Status;
                if (!string.IsNullOrEmpty(st) && secs > 2) return st;
                if (secs < 6) return "Cargando…";
                if (secs < 20) return "Cargando… (" + (int)secs + " s)";
                return "Cargando con el método de respaldo… (" + (int)secs + " s)";
            }
        }

        /// <summary>La persona quiere que suene (así no se obedecen pausas que mete Windows al bloquear).</summary>
        private static volatile bool _wantPlay;
        private static long _systemTicks;
        private static double _lastPos;
        private static bool _waitingNet;
        private static DateTime _lastNetTry = DateTime.MinValue;

        public static void Toggle()
        {
            if (_mp == null || Current == null) return;
            if (Playing) Pause();
            else Play();
        }

        public static void Play()
        {
            if (_mp == null || Current == null) return;
            _wantPlay = true;
            if (_waitingNet) { _waitingNet = false; Load(true, _lastPos); return; }
            if (!_opened && !_resolving) { Load(true, Math.Max(_resumeAt, _lastPos)); return; }
            _autoPlay = true;
            try { _mp.Play(); } catch { }
        }

        public static void Pause()
        {
            _wantPlay = false;
            _autoPlay = false;
            try { _mp?.Pause(); } catch { }
            StateChanged?.Invoke();
        }

        public static void Next(bool auto)
        {
            if (Queue.Count == 0) return;
            if (SleepEndOfSong && auto)
            {
                SleepEndOfSong = false;
                Pause();
                Message?.Invoke("Temporizador: la música se detuvo");
                StateChanged?.Invoke();
                return;
            }
            int next = Index + 1;
            while (next < Queue.Count && Library.IsHidden(Queue[next])) next++;
            if (next >= Queue.Count)
            {
                if (Prefs.S.Repeat == 1) { Index = 0; Load(true, 0); return; }
                if (RadioMode || Prefs.S.Autoplay) { ExtendRadio(true); return; }
                if (!auto) Message?.Invoke("Es la última canción de la lista");
                return;
            }
            Index = next;
            Load(true, 0);
        }

        public static void Previous()
        {
            if (Current == null) return;
            if (Position > 4 || Index <= 0)
            {
                Seek(0);
                if (!Playing) Play();
                return;
            }
            Index--;
            Load(true, 0);
        }

        // ------------------------------------------------------------ cargar y tocar

        private static async void Load(bool autoPlay, double resumeAt)
        {
            var song = Current;
            if (song == null || _mp == null) return;
            int gen = ++_gen;
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var ct = _cts.Token;
            _triedFallback = false;
            _waitingNet = false;
            _autoPlay = autoPlay;
            if (autoPlay) _wantPlay = true;
            _resumeAt = Math.Max(0, resumeAt);
            _lastPos = _resumeAt;
            _opened = false;
            _resolving = true;
            _loadStarted = DateTime.Now;
            Loading = true;
            try { _mp.Pause(); } catch { }
            SongChanged?.Invoke();
            StateChanged?.Invoke();
            Log.Write("Cargar: " + song.Title + (_resumeAt > 1 ? " desde " + (int)_resumeAt + " s" : ""));
            try
            {
                if (song.NeedsLookup)
                {
                    var found = await YtMusic.First(song.Title, song.Artist);
                    if (gen != _gen) return;
                    if (found == null) throw new UserError("No se encontró esta canción.");
                    song.Url = found.Url;
                    if (string.IsNullOrEmpty(song.Image)) song.Image = found.Image;
                    if (song.Seconds <= 0) song.Seconds = found.Seconds;
                    SongChanged?.Invoke();
                }
                if (song.PhoneOnly) throw new UserError("Esta canción está guardada solo en tu teléfono.");
                AudioSource src;
                if (song.IsDirect) src = new AudioSource { Url = song.Identity };
                else src = await Streams.Resolve(song.VideoId, ct);
                if (gen != _gen) return;
                await Open(song, src, gen);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
            catch (Exception e)
            {
                if (gen != _gen) return;
                Log.Write("No se pudo abrir: " + e.GetType().Name + " " + e.Message);
                if (!(e is UserError) && song.VideoId != null && !_triedFallback)
                {
                    await Fallback(song, gen, _resumeAt);
                    return;
                }
                Fail(e is UserError ? e.Message : "No se pudo cargar esta canción.");
            }
        }

        private static async Task Open(Song song, AudioSource src, int gen)
        {
            MediaSource ms;
            if (src.IsFile)
            {
                var file = await Windows.Storage.StorageFile.GetFileFromPathAsync(src.File);
                if (gen != _gen) return;
                ms = MediaSource.CreateFromStorageFile(file);
            }
            else ms = MediaSource.CreateFromUri(new Uri(src.Url));
            _usingUrl = !src.IsFile;
            var item = new MediaPlaybackItem(ms);
            ApplyDisplay(item, song, null);
            _resolving = false;
            _mp.Source = item;
            if (_autoPlay) _mp.Play();
            if (_usingUrl && song.VideoId != null)
            {
                // Si el enlace no abre pronto, se toca la copia completa (sin brincar a otra canción).
                UiThread.After(10000, () =>
                {
                    if (gen != _gen || _opened || _triedFallback) return;
                    Log.Write("El enlace tarda demasiado: se usa la copia completa");
                    Streams.MarkFailed(song.VideoId);
                    var t = Fallback(song, gen, _resumeAt);
                });
            }
        }

        /// <summary>Baja la canción completa y la toca desde la PC, en el mismo segundo donde iba.</summary>
        private static async Task Fallback(Song song, int gen, double resumeAt)
        {
            if (_triedFallback || song.VideoId == null) return;
            _triedFallback = true;
            _resolving = true;
            _opened = false;
            _resumeAt = Math.Max(0, resumeAt);
            Loading = true;
            try { _mp.Source = null; } catch { }
            StateChanged?.Invoke();
            try
            {
                var ct = _cts?.Token ?? CancellationToken.None;
                string file = await Streams.Fetch(song.VideoId, ct);
                if (gen != _gen) return;
                await Open(song, new AudioSource { File = file }, gen);
            }
            catch (Exception e)
            {
                if (gen != _gen) return;
                Log.Write("Respaldo falló: " + e.GetType().Name + " " + e.Message);
                Fail("No se pudo cargar esta canción.");
            }
        }

        /// <summary>
        /// Sin internet: se queda en la misma canción y sigue sola cuando regresa la conexión.
        /// Con internet (la canción no está disponible): avisa y pasa a la siguiente (máximo 2 veces seguidas).
        /// </summary>
        private static async void Fail(string message)
        {
            int gen = _gen;
            _resolving = false;
            Loading = false;
            Playing = false;
            _opened = false;
            _resumeAt = _lastPos;
            try { _mp.Source = null; } catch { }
            PowerSettings.KeepAwake(false);
            StateChanged?.Invoke();
            bool online = await Net.Online();
            if (gen != _gen) return;
            if (!online)
            {
                _waitingNet = true;
                _lastNetTry = DateTime.Now;
                Message?.Invoke("Sin conexión. La canción sigue sola en cuanto regrese el internet.");
                return;
            }
            _failures++;
            if (_failures <= 2 && Index + 1 < Queue.Count && _wantPlay)
            {
                Message?.Invoke(message + " Sigue la siguiente…");
                UiThread.After(2500, () => { if (gen == _gen) Next(true); });
            }
            else Message?.Invoke(message + " Toca reproducir para intentar otra vez.");
        }

        private static async void RetryNet()
        {
            _lastNetTry = DateTime.Now;
            bool online = await Net.Online();
            if (!online || !_waitingNet || !_wantPlay) return;
            _waitingNet = false;
            Message?.Invoke("Regresó el internet");
            Load(true, _lastPos);
        }

        private static void ApplyDisplay(MediaPlaybackItem item, Song song, string art)
        {
            try
            {
                var props = item.GetDisplayProperties();
                props.Type = MediaPlaybackType.Music;
                props.MusicProperties.Title = song.Title ?? "";
                props.MusicProperties.Artist = song.Artist ?? "";
                props.MusicProperties.AlbumArtist = song.Artist ?? "";
                string img = art ?? song.Image;
                if (!string.IsNullOrEmpty(img) && img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                    props.Thumbnail = RandomAccessStreamReference.CreateFromUri(new Uri(img));
                item.ApplyDisplayProperties(props);
            }
            catch (Exception e) { Log.Error(e, "SMTC"); }
        }

        private static void OnOpened()
        {
            _opened = true;
            _resolving = false;
            _failures = 0;
            _waitingNet = false;
            if (_resumeAt > 1)
            {
                try { _mp.PlaybackSession.Position = TimeSpan.FromSeconds(_resumeAt); } catch { }
            }
            _lastPos = _resumeAt;
            _resumeAt = 0;
            OnState();
            var song = Current;
            if (song == null) return;
            Log.Write("Abierta (" + (_usingUrl ? "enlace" : "archivo") + "): " + song.Title);
            if (_autoPlay)
            {
                Library.AddRecent(song);
                Prefs.CountArtist(song.Artist);
            }
            SavePlayback(true);
            BetterArt(song, _gen);
            Prefetch();
            if (RadioMode || Prefs.S.Autoplay) MaybeExtend();
        }

        private static async void BetterArt(Song song, int gen)
        {
            if (!Yt.IsVideoThumb(song.Image)) return;
            string art = await Artwork.Better(song);
            if (gen != _gen || string.IsNullOrEmpty(art) || art == song.Image) return;
            song.Image = art;
            if (_mp?.Source is MediaPlaybackItem item) ApplyDisplay(item, song, art);
            SongChanged?.Invoke();
        }

        /// <summary>
        /// Guarda completas en la PC la canción actual (si suena por enlace) y las 2 siguientes:
        /// el cambio es inmediato y un corte de internet no la interrumpe.
        /// </summary>
        private static void Prefetch()
        {
            var ids = new List<string>();
            var cur = Current;
            if (_usingUrl && cur?.VideoId != null) ids.Add(cur.VideoId);
            for (int i = Index + 1; i < Queue.Count && ids.Count < 3; i++)
            {
                string id = Queue[i].VideoId;
                if (id != null && !ids.Contains(id)) ids.Add(id);
            }
            ids.RemoveAll(id => Downloads.FileFor(id) != null || Streams.Cached(id) != null);
            if (ids.Count == 0) return;
            var t = Task.Run(async () =>
            {
                await Task.Delay(1500).ConfigureAwait(false);
                foreach (string id in ids)
                {
                    try { await Streams.Fetch(id).ConfigureAwait(false); }
                    catch { }
                }
            });
        }

        private static void OnEnded()
        {
            var song = Current;
            double expected = song?.Seconds ?? 0;
            if (song != null && song.VideoId != null && expected > 40 && _lastPos < expected - 15)
            {
                // El enlace se cortó (internet o bloqueo): se sigue desde la copia completa donde iba.
                Log.Write("Se cortó en " + (int)_lastPos + " de " + expected + " s: se recupera");
                if (!_usingUrl) Streams.Drop(song.VideoId);
                _triedFallback = false;
                var t = Fallback(song, _gen, _lastPos);
                return;
            }
            if (Prefs.S.Repeat == 2)
            {
                try
                {
                    _mp.PlaybackSession.Position = TimeSpan.Zero;
                    _mp.Play();
                }
                catch { }
                return;
            }
            Next(true);
        }

        private static void OnFailed(string detail)
        {
            Log.Write("Reproductor: " + detail);
            var song = Current;
            if (song == null) return;
            if (song.VideoId != null && !_triedFallback)
            {
                Streams.Forget(song.VideoId);
                if (_usingUrl) Streams.MarkFailed(song.VideoId);
                else Streams.Drop(song.VideoId);
                var t = Fallback(song, _gen, Math.Max(_lastPos, _resumeAt));
                return;
            }
            Fail("No se pudo reproducir esta canción.");
        }

        private static bool SystemMoment(double seconds) =>
            DateTime.UtcNow.Ticks - Interlocked.Read(ref _systemTicks) < TimeSpan.FromSeconds(seconds).Ticks;

        /// <summary>
        /// Bloqueo, pantalla apagada, suspensión y regreso (los avisa la ventana). Si Windows pausó la
        /// música por eso, se reanuda sola donde iba.
        /// </summary>
        public static void SystemEvent(string what)
        {
            Interlocked.Exchange(ref _systemTicks, DateTime.UtcNow.Ticks);
            Log.Write("Sistema: " + what + (_wantPlay ? " (la música debe seguir)" : ""));
            bool back = what == "reanudar" || what == "pantalla encendida" || what == "desbloqueo";
            if (!back || !_wantPlay || Current == null) return;
            int gen = _gen;
            UiThread.After(1500, () =>
            {
                if (gen != _gen || !_wantPlay || Playing || _resolving) return;
                Log.Write("Se reanuda después de " + what);
                if (_opened) { try { _mp.Play(); } catch { } }
                else Load(true, _lastPos);
            });
        }

        private static void OnState()
        {
            if (_mp == null) return;
            MediaPlaybackState st;
            try { st = _mp.PlaybackSession.PlaybackState; }
            catch { return; }
            bool was = Playing;
            Playing = st == MediaPlaybackState.Playing;
            Loading = _resolving || st == MediaPlaybackState.Opening || st == MediaPlaybackState.Buffering;
            PowerSettings.KeepAwake(Playing || Loading);
            if (was != Playing) Log.Write(Playing ? "Sonando" : "Detenida: " + st + (_wantPlay ? " (sin que la persona la pausara)" : ""));
            StateChanged?.Invoke();
            if (!Playing) SavePlayback(false);
            if (st == MediaPlaybackState.Paused && _wantPlay && _opened && SystemMoment(20))
            {
                int gen = _gen;
                UiThread.After(1200, () =>
                {
                    if (gen != _gen || !_wantPlay || Playing || _resolving) return;
                    Log.Write("Windows pausó la música: se reanuda");
                    try { _mp.Play(); } catch { }
                });
            }
        }

        // ------------------------------------------------------------ mix continuo

        private static void MaybeExtend()
        {
            if (Queue.Count - Index <= 3) ExtendRadio(false);
        }

        private static async void ExtendRadio(bool playNext)
        {
            if (_radioBusy) return;
            string seed = _radioSeed ?? Current?.VideoId;
            if (seed == null)
            {
                for (int i = Queue.Count - 1; i >= 0 && seed == null; i--) seed = Queue[i].VideoId;
                if (seed == null) return;
            }
            _radioBusy = true;
            try
            {
                var existing = new HashSet<string>(Queue.Select(q => q.Key));
                var add = new List<Song>();
                string cont = seed == _radioSeed ? _radioCont : null;
                for (int round = 0; round < 2 && add.Count < 5; round++)
                {
                    var page = await YtMusic.Radio(seed, cont);
                    _radioSeed = seed;
                    _radioCont = page.Continuation;
                    cont = page.Continuation;
                    foreach (var s in page.Songs)
                        if (!Library.IsHidden(s) && existing.Add(s.Key)) add.Add(s);
                    if (!page.HasMore) break;
                }
                if (add.Count == 0)
                {
                    if (playNext) Message?.Invoke("No hay más canciones parecidas por ahora");
                    return;
                }
                Queue.AddRange(add);
                _unshuffled?.AddRange(add);
                if (!RadioMode && Prefs.S.Autoplay && string.IsNullOrEmpty(Source)) Source = "Reproducción automática";
                QueueChanged?.Invoke();
                if (playNext) { Index++; Load(true, 0); }
            }
            catch (Exception e)
            {
                Log.Write("Mix: " + e.Message);
                if (playNext) Message?.Invoke("No se pudo continuar con canciones parecidas");
            }
            finally
            {
                _radioBusy = false;
            }
        }

        // ------------------------------------------------------------ temporizador

        public static void SetSleep(int minutes)
        {
            SleepEndOfSong = false;
            SleepAt = minutes > 0 ? DateTime.Now.AddMinutes(minutes) : (DateTime?)null;
            StateChanged?.Invoke();
        }

        public static void SetSleepEndOfSong()
        {
            SleepAt = null;
            SleepEndOfSong = true;
            StateChanged?.Invoke();
        }

        private static void OnTick()
        {
            if (SleepAt.HasValue && DateTime.Now >= SleepAt.Value)
            {
                SleepAt = null;
                Pause();
                Message?.Invoke("Temporizador: la música se detuvo");
                StateChanged?.Invoke();
            }
            if (Playing && (DateTime.Now - _lastSave).TotalSeconds > 20) SavePlayback(false);
            if (Playing && _opened)
            {
                try { _lastPos = _mp.PlaybackSession.Position.TotalSeconds; } catch { }
            }
            if (_waitingNet && _wantPlay && (DateTime.Now - _lastNetTry).TotalSeconds >= 6) RetryNet();
            if (_resolving && Loading)
            {
                // Nunca se queda "Cargando…" para siempre (más tiempo si se está preparando el reproductor).
                double limit = string.IsNullOrEmpty(Streams.Status) ? 150 : 600;
                if ((DateTime.Now - _loadStarted).TotalSeconds > limit)
                {
                    Log.Write("Carga cancelada por tiempo");
                    _gen++;
                    _cts?.Cancel();
                    Fail("La canción tardó demasiado en cargar.");
                }
            }
        }

        // ------------------------------------------------------------ continuar donde te quedaste

        /// <summary>Guarda canción, posición y cola (igual que el teléfono, para seguir en otro lado).</summary>
        public static void SavePlayback(bool cloud)
        {
            var song = Current;
            if (song == null || song.NeedsLookup || song.PhoneOnly) return;
            _lastSave = DateTime.Now;
            var queue = new JsonArray();
            int from = Math.Max(0, Index - 5);
            foreach (var s in Queue.Skip(from).Take(40))
                if (!s.NeedsLookup && !s.PhoneOnly) queue.Add(s.Portable());
            var pb = new JsonObject
            {
                ["song"] = song.Portable(),
                ["positionMs"] = (long)(Position * 1000),
                ["updatedAtMs"] = J.NowMs(),
                ["queue"] = queue,
                ["mixMode"] = RadioMode
            };
            if (RadioMode) { pb["mixSeed"] = song.Title; pb["mixType"] = "song"; }
            Library.SetPlayback(pb, cloud);
        }

        /// <summary>Deja lista la última canción (en pausa) sin empezar a sonar.</summary>
        public static void Restore(JsonObject pb, bool remote)
        {
            if (pb == null || Playing || Loading) return;
            var song = Song.From(J.ObjOf(pb, "song"));
            if (song == null || song.NeedsLookup || song.PhoneOnly) return;
            var list = new List<Song>();
            var qa = J.ArrOf(pb, "queue");
            if (qa != null)
                foreach (var n in qa)
                {
                    var s = Song.From(n);
                    if (s != null && !s.NeedsLookup && !s.PhoneOnly) list.Add(s);
                }
            int idx = list.FindIndex(x => x.Key == song.Key);
            if (idx < 0) { list.Insert(0, song); idx = 0; }
            _gen++;
            _cts?.Cancel();
            try { if (_mp != null) _mp.Source = null; } catch { }
            _opened = false;
            _resolving = false;
            Queue.Clear();
            Queue.AddRange(list);
            Index = idx;
            _unshuffled = null;
            RadioMode = J.Bool(pb, "mixMode");
            _radioSeed = RadioMode ? song.VideoId : null;
            _radioCont = null;
            _resumeAt = Math.Max(0, J.Long(pb, "positionMs") / 1000.0);
            _lastPos = _resumeAt;
            _wantPlay = false;
            _waitingNet = false;
            Source = remote ? "Continuar desde otro dispositivo" : "Continuar escuchando";
            QueueChanged?.Invoke();
            SongChanged?.Invoke();
            StateChanged?.Invoke();
        }

        /// <summary>Detiene todo y vacía la cola (al cerrar sesión).</summary>
        public static void Stop()
        {
            _gen++;
            _cts?.Cancel();
            try { _mp?.Pause(); } catch { }
            try { if (_mp != null) _mp.Source = null; } catch { }
            _opened = false;
            _resolving = false;
            _wantPlay = false;
            _waitingNet = false;
            Loading = false;
            Playing = false;
            Queue.Clear();
            _unshuffled = null;
            Index = -1;
            RadioMode = false;
            Source = "";
            PowerSettings.KeepAwake(false);
            QueueChanged?.Invoke();
            SongChanged?.Invoke();
            StateChanged?.Invoke();
        }

        public static void Shutdown()
        {
            SavePlayback(false);
            try { _mp?.Pause(); } catch { }
            try { _mp?.Dispose(); } catch { }
            PowerSettings.KeepAwake(false);
        }
    }
}
