using System.Windows;

namespace PMusic
{
    public partial class App : Application
    {
    }
}
