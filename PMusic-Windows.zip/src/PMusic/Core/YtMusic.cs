using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PMusic.Core
{
    /// <summary>Una página de canciones y cómo pedir la siguiente.</summary>
    public sealed class SongPage
    {
        public List<Song> Songs = new List<Song>();
        public string Continuation;
        public bool HasMore => !string.IsNullOrEmpty(Continuation);
    }

    /// <summary>
    /// Catálogo de música (el mismo que usa la app del teléfono): buscar canciones, la radio de
    /// "canciones parecidas" y las listas de tops. Lee las respuestas buscando las piezas por nombre,
    /// así aguanta cambios de acomodo.
    /// </summary>
    public static class YtMusic
    {
        private const string Base = "https://music.youtube.com/youtubei/v1/";
        private const string SongsFilter = "EgWKAQIIAWoMEA4QChADEAQQCRAF";
        private const string FeaturedPlaylists = "EgeKAQQoADgBagwQDhAKEAMQBBAJEAU=";
        private const string CommunityPlaylists = "EgeKAQQoAEABagwQDhAKEAMQBBAJEAU=";
        private static readonly Regex DurationRx = new Regex(@"^\d{1,2}(:\d{2}){1,2}$", RegexOptions.Compiled);
        private static readonly string[] TypeLabels = { "canción", "cancion", "song", "video", "episodio", "episode", "sencillo", "single" };

        private static string _version;
        private static string _visitor = "";
        private static Task _init;
        private static readonly object InitGate = new object();

        private static string DefaultVersion => "1." + DateTime.UtcNow.AddDays(-2).ToString("yyyyMMdd", CultureInfo.InvariantCulture) + ".01.00";

        /// <summary>Lee la versión actual y el visitante de la página (una vez). Si falla, usa la de hoy.</summary>
        private static Task Init()
        {
            lock (InitGate)
            {
                if (_init == null) _init = Task.Run(async () =>
                {
                    try
                    {
                        string html = await Net.GetString("https://music.youtube.com/", 9000,
                            new Dictionary<string, string> { ["Cookie"] = "SOCS=CAI", ["Accept-Language"] = "es-419,es;q=0.9" }).ConfigureAwait(false);
                        var v = Regex.Match(html, "\"INNERTUBE_CLIENT_VERSION\":\"([0-9.]+)\"");
                        if (v.Success) _version = v.Groups[1].Value;
                        var vis = Regex.Match(html, "\"VISITOR_DATA\":\"([^\"]+)\"");
                        if (vis.Success) _visitor = vis.Groups[1].Value;
                    }
                    catch (Exception e) { Log.Write("Catálogo: inicio sin página (" + e.GetType().Name + ")"); }
                });
                return _init;
            }
        }

        private static JsonObject Context()
        {
            return new JsonObject
            {
                ["client"] = new JsonObject
                {
                    ["clientName"] = "WEB_REMIX",
                    ["clientVersion"] = _version ?? DefaultVersion,
                    ["hl"] = "es-419",
                    ["gl"] = "MX"
                },
                ["user"] = new JsonObject()
            };
        }

        private static async Task<JsonNode> Post(string endpoint, JsonObject body, string extra = null, CancellationToken ct = default(CancellationToken))
        {
            await Init().ConfigureAwait(false);
            body["context"] = Context();
            var headers = new Dictionary<string, string>
            {
                ["Origin"] = "https://music.youtube.com",
                ["Referer"] = "https://music.youtube.com/",
                ["X-Origin"] = "https://music.youtube.com",
                ["X-YouTube-Client-Name"] = "67",
                ["X-YouTube-Client-Version"] = _version ?? DefaultVersion,
                ["Accept-Language"] = "es-419,es;q=0.9",
                ["Cookie"] = "SOCS=CAI"
            };
            if (_visitor.Length > 0) headers["X-Goog-Visitor-Id"] = _visitor;
            string url = Base + endpoint + "?prettyPrint=false" + (extra ?? "");
            ct.ThrowIfCancellationRequested();
            var res = await Net.PostJson(url, Js.Node(body), headers, 20000, false, 12 * 1024 * 1024).ConfigureAwait(false);
            if (!res.Ok) throw new System.IO.IOException("Catálogo HTTP " + res.Code);
            ct.ThrowIfCancellationRequested();
            return J.Parse(res.Body);
        }

        // ------------------------------------------------------------ búsqueda

        public static async Task<SongPage> Search(string query, string continuation = null, CancellationToken ct = default(CancellationToken))
        {
            var body = new JsonObject { ["query"] = query, ["params"] = SongsFilter };
            string extra = string.IsNullOrEmpty(continuation) ? null
                : "&ctoken=" + Uri.EscapeDataString(continuation) + "&continuation=" + Uri.EscapeDataString(continuation) + "&type=next";
            var root = await Post("search", body, extra, ct).ConfigureAwait(false);
            var page = new SongPage();
            var seen = new HashSet<string>();
            foreach (var item in FindAll(root, "musicResponsiveListItemRenderer"))
            {
                var s = FromListItem(item, true);
                if (s != null && seen.Add(s.VideoId)) page.Songs.Add(s);
            }
            page.Continuation = FindContinuation(root);
            if (page.Songs.Count == 0) page.Continuation = null;
            return page;
        }

        /// <summary>La mejor coincidencia para "título artista" (tops y canciones sin enlace).</summary>
        public static async Task<Song> First(string title, string artist)
        {
            var page = await Search((title + " " + Tx.MainArtist(artist)).Trim()).ConfigureAwait(false);
            if (page.Songs.Count == 0) return null;
            string tk = Tx.TitleKey(title, artist);
            foreach (var s in page.Songs.Take(6))
            {
                string k = Tx.TitleKey(s.Title, s.Artist);
                if ((k == tk || k.Contains(tk) || tk.Contains(k)) && (string.IsNullOrEmpty(artist) || Tx.SameArtist(s.Artist, artist) || Tx.Plain(s.Artist).Contains(Tx.Plain(Tx.MainArtist(artist)))))
                    return s;
            }
            return page.Songs[0];
        }

        // ------------------------------------------------------------ radio (canciones parecidas)

        public static async Task<SongPage> Radio(string videoId, string continuation = null, CancellationToken ct = default(CancellationToken))
        {
            var body = new JsonObject
            {
                ["videoId"] = videoId,
                ["playlistId"] = "RDAMVM" + videoId,
                ["isAudioOnly"] = true,
                ["enablePersistentPlaylistPanel"] = true,
                ["tunerSettingValue"] = "AUTOMIX_SETTING_NORMAL",
                ["watchEndpointMusicSupportedConfigs"] = new JsonObject
                {
                    ["watchEndpointMusicConfig"] = new JsonObject
                    {
                        ["hasPersistentPlaylistPanel"] = true,
                        ["musicVideoType"] = "MUSIC_VIDEO_TYPE_ATV"
                    }
                }
            };
            string extra = null;
            if (!string.IsNullOrEmpty(continuation))
            {
                extra = "&ctoken=" + Uri.EscapeDataString(continuation) + "&continuation=" + Uri.EscapeDataString(continuation) + "&type=next";
            }
            var root = await Post("next", body, extra, ct).ConfigureAwait(false);
            var page = new SongPage();
            var seen = new HashSet<string>();
            foreach (var item in FindAll(root, "playlistPanelVideoRenderer"))
            {
                var s = FromPanelItem(item);
                if (s != null && seen.Add(s.VideoId)) page.Songs.Add(s);
            }
            page.Continuation = FindContinuation(root);
            if (page.Songs.Count == 0) page.Continuation = null;
            return page;
        }

        // ------------------------------------------------------------ listas (tops)

        /// <summary>Busca una lista por nombre ("Top 100 canciones México") y regresa sus canciones.</summary>
        public static async Task<List<Song>> PlaylistByQuery(string query, int max = 100)
        {
            foreach (string filter in new[] { FeaturedPlaylists, CommunityPlaylists })
            {
                try
                {
                    var root = await Post("search", new JsonObject { ["query"] = query, ["params"] = filter }).ConfigureAwait(false);
                    foreach (var item in FindAll(root, "musicResponsiveListItemRenderer"))
                    {
                        string id = J.AtStr(item, "navigationEndpoint", "browseEndpoint", "browseId");
                        if (string.IsNullOrEmpty(id)) continue;
                        var songs = await Playlist(id, max).ConfigureAwait(false);
                        if (songs.Count >= 5) return songs;
                        break;
                    }
                }
                catch (Exception e) { Log.Write("Lista '" + query + "': " + e.Message); }
            }
            var fallback = await Search(query).ConfigureAwait(false);
            return fallback.Songs;
        }

        public static async Task<List<Song>> Playlist(string browseId, int max = 100)
        {
            var list = new List<Song>();
            var seen = new HashSet<string>();
            var root = await Post("browse", new JsonObject { ["browseId"] = browseId }).ConfigureAwait(false);
            for (int pageNo = 0; pageNo < 4 && root != null; pageNo++)
            {
                foreach (var item in FindAll(root, "musicResponsiveListItemRenderer"))
                {
                    var s = FromListItem(item, false);
                    if (s != null && seen.Add(s.VideoId)) list.Add(s);
                }
                string cont = FindContinuation(root);
                if (list.Count >= max || string.IsNullOrEmpty(cont)) break;
                try
                {
                    root = await Post("browse", new JsonObject { ["continuation"] = cont },
                        "&ctoken=" + Uri.EscapeDataString(cont) + "&continuation=" + Uri.EscapeDataString(cont) + "&type=next").ConfigureAwait(false);
                }
                catch (Exception e)
                {
                    Log.Write("Lista: sin más páginas (" + e.Message + ")");
                    break;
                }
            }
            if (list.Count > max) list.RemoveRange(max, list.Count - max);
            return list;
        }

        // ------------------------------------------------------------ sugerencias al escribir

        public static async Task<List<string>> Suggestions(string input, CancellationToken ct)
        {
            var list = new List<string>();
            var root = await Post("music/get_search_suggestions", new JsonObject { ["input"] = input }, null, ct).ConfigureAwait(false);
            foreach (var item in FindAll(root, "searchSuggestionRenderer"))
            {
                string s = Runs(item["suggestion"]);
                if (s.Length > 0 && !list.Contains(s)) list.Add(s);
                if (list.Count >= 8) break;
            }
            return list;
        }

        // ------------------------------------------------------------ lectura de piezas

        private static List<JsonObject> FindAll(JsonNode root, string key)
        {
            var list = new List<JsonObject>();
            Walk(root, key, list, 0);
            return list;
        }

        private static void Walk(JsonNode n, string key, List<JsonObject> found, int depth)
        {
            if (n == null || depth > 60) return;
            if (n is JsonObject o)
            {
                foreach (var kv in o)
                {
                    if (kv.Key == key && kv.Value is JsonObject hit) { found.Add(hit); continue; }
                    Walk(kv.Value, key, found, depth + 1);
                }
            }
            else if (n is JsonArray a)
            {
                foreach (var x in a) Walk(x, key, found, depth + 1);
            }
        }

        private static string FindContinuation(JsonNode root)
        {
            foreach (string k in new[] { "nextContinuationData", "nextRadioContinuationData" })
                foreach (var c in FindAll(root, k))
                {
                    string t = J.Str(c, "continuation");
                    if (t.Length > 0) return t;
                }
            foreach (var c in FindAll(root, "continuationCommand"))
            {
                string t = J.Str(c, "token");
                if (t.Length > 0) return t;
            }
            return null;
        }

        private static string Runs(JsonNode textNode)
        {
            if (textNode == null) return "";
            string simple = J.Str(textNode, "simpleText");
            if (simple.Length > 0) return simple;
            var runs = J.ArrOf(textNode, "runs");
            if (runs == null) return "";
            var sb = new System.Text.StringBuilder();
            foreach (var r in runs) sb.Append(J.Str(r, "text"));
            return sb.ToString();
        }

        /// <summary>Separa "Artista • Álbum • 3:21" en grupos.</summary>
        private static List<string> Groups(JsonNode textNode)
        {
            var groups = new List<string>();
            var runs = J.ArrOf(textNode, "runs");
            if (runs == null)
            {
                string simple = J.Str(textNode, "simpleText");
                if (simple.Length > 0) groups.AddRange(simple.Split('•').Select(x => x.Trim()).Where(x => x.Length > 0));
                return groups;
            }
            var cur = new System.Text.StringBuilder();
            foreach (var r in runs)
            {
                string t = J.Str(r, "text");
                if (t.Trim() == "•")
                {
                    if (cur.ToString().Trim().Length > 0) groups.Add(cur.ToString().Trim());
                    cur.Clear();
                    continue;
                }
                cur.Append(t);
            }
            if (cur.ToString().Trim().Length > 0) groups.Add(cur.ToString().Trim());
            return groups;
        }

        private static string BestThumb(JsonNode thumbs)
        {
            var arr = thumbs as JsonArray;
            if (arr == null || arr.Count == 0) return "";
            string url = J.Str(arr[arr.Count - 1], "url");
            if (url.StartsWith("//", StringComparison.Ordinal)) url = "https:" + url;
            return Yt.BigArt(url);
        }

        private static Song FromListItem(JsonObject r, bool musicUrl)
        {
            string id = J.AtStr(r, "playlistItemData", "videoId");
            if (id.Length == 0)
                id = J.AtStr(r, "overlay", "musicItemThumbnailOverlayRenderer", "content", "musicPlayButtonRenderer", "playNavigationEndpoint", "watchEndpoint", "videoId");
            if (id.Length == 0)
                id = J.AtStr(r, "flexColumns", "0", "musicResponsiveListItemFlexColumnRenderer", "text", "runs", "0", "navigationEndpoint", "watchEndpoint", "videoId");
            if (Yt.IdOf(id) == null) return null;
            string title = Runs(J.At(r, "flexColumns", "0", "musicResponsiveListItemFlexColumnRenderer", "text"));
            if (title.Length == 0) return null;
            var groups = Groups(J.At(r, "flexColumns", "1", "musicResponsiveListItemFlexColumnRenderer", "text"));
            long seconds = 0;
            string fixedDur = Runs(J.At(r, "fixedColumns", "0", "musicResponsiveListItemFixedColumnRenderer", "text"));
            if (DurationRx.IsMatch(fixedDur)) seconds = Tx.ParseTime(fixedDur);
            if (groups.Count > 0 && DurationRx.IsMatch(groups[groups.Count - 1]))
            {
                if (seconds == 0) seconds = Tx.ParseTime(groups[groups.Count - 1]);
                groups.RemoveAt(groups.Count - 1);
            }
            if (groups.Count > 1 && TypeLabels.Contains(groups[0].ToLowerInvariant())) groups.RemoveAt(0);
            string artist = groups.Count > 0 ? groups[0] : "";
            string thumb = BestThumb(J.At(r, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails"));
            if (thumb.Length == 0) thumb = Yt.Thumb(id);
            return new Song(musicUrl ? Yt.MusicUrl(id) : Yt.WatchUrl(id), title, artist, thumb, seconds);
        }

        private static Song FromPanelItem(JsonObject r)
        {
            string id = J.Str(r, "videoId");
            if (Yt.IdOf(id) == null) return null;
            string title = Runs(r["title"]);
            if (title.Length == 0) return null;
            var groups = Groups(r["longBylineText"]);
            if (groups.Count == 0) groups = Groups(r["shortBylineText"]);
            string artist = groups.Count > 0 ? groups[0] : "";
            long seconds = Tx.ParseTime(Runs(r["lengthText"]));
            string thumb = BestThumb(J.At(r, "thumbnail", "thumbnails"));
            if (thumb.Length == 0) thumb = Yt.Thumb(id);
            return new Song(Yt.WatchUrl(id), title, artist, thumb, seconds);
        }
    }
}
