using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace PMusic.Core
{
    /// <summary>
    /// Que la tablet no se duerma mientras suena música (aunque esté bloqueada) y, si la persona quiere,
    /// que el botón de encendido solo apague la pantalla, como en el teléfono.
    /// </summary>
    public static class PowerSettings
    {
        private const uint ES_CONTINUOUS = 0x80000000;
        private const uint ES_SYSTEM_REQUIRED = 0x00000001;

        [DllImport("kernel32.dll")]
        private static extern uint SetThreadExecutionState(uint flags);

        private static bool _awake;

        /// <summary>Llamar desde el hilo de la interfaz (el pedido vive con ese hilo).</summary>
        public static void KeepAwake(bool playing)
        {
            if (playing == _awake) return;
            _awake = playing;
            try { SetThreadExecutionState(playing ? ES_CONTINUOUS | ES_SYSTEM_REQUIRED : ES_CONTINUOUS); }
            catch { }
        }

        private static string Run(string args)
        {
            try
            {
                var psi = new ProcessStartInfo("powercfg.exe", args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var p = Process.Start(psi))
                {
                    if (p == null) return null;
                    string o = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(8000);
                    return p.ExitCode == 0 ? o : null;
                }
            }
            catch { return null; }
        }

        /// <summary>true = el botón de encendido ya solo apaga la pantalla (con y sin cargador).</summary>
        public static bool ButtonTurnsOffDisplay()
        {
            string o = Run("/q SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION");
            if (string.IsNullOrEmpty(o)) return false;
            var m = Regex.Matches(o, @"0x([0-9a-fA-F]{8})");
            if (m.Count < 2) return false;
            string ac = m[m.Count - 2].Groups[1].Value, dc = m[m.Count - 1].Groups[1].Value;
            return Convert.ToInt32(ac, 16) == 4 && Convert.ToInt32(dc, 16) == 4;
        }

        /// <summary>on: botón = apagar pantalla (la música sigue). off: botón = suspender (lo normal).</summary>
        public static bool SetButtonDisplayOff(bool on)
        {
            string v = on ? "4" : "1";
            bool ok = Run("/setacvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION " + v) != null;
            ok &= Run("/setdcvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION " + v) != null;
            Run("/setactive SCHEME_CURRENT");
            Log.Write("Botón de encendido → " + (on ? "apagar pantalla" : "suspender") + (ok ? "" : " (falló)"));
            return ok;
        }
    }
}
