using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace PMusic.Core
{
    /// <summary>Carpetas de la app en %LocalAppData%\PMusic.</summary>
    public static class Paths
    {
        public static readonly string Root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PMusic");

        public static string File(string name)
        {
            Directory.CreateDirectory(Root);
            return Path.Combine(Root, name);
        }

        public static string Dir(string name)
        {
            string d = Path.Combine(Root, name);
            Directory.CreateDirectory(d);
            return d;
        }

        /// <summary>Canciones descargadas: Música\P Music (se ven en el Explorador).</summary>
        public static string Downloads()
        {
            string music = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
            if (string.IsNullOrEmpty(music)) music = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Music");
            string d = Path.Combine(music, "P Music");
            Directory.CreateDirectory(d);
            return d;
        }

        /// <summary>Escribe completo o nada (no deja archivos a medias si se apaga la tablet).</summary>
        public static void WriteAtomic(string path, string text)
        {
            string tmp = path + ".tmp";
            System.IO.File.WriteAllText(tmp, text, new UTF8Encoding(false));
            if (System.IO.File.Exists(path)) System.IO.File.Replace(tmp, path, null, true);
            else System.IO.File.Move(tmp, path);
        }

        public static string ReadOrEmpty(string path)
        {
            try { return System.IO.File.Exists(path) ? System.IO.File.ReadAllText(path, Encoding.UTF8) : ""; }
            catch { return ""; }
        }

        public static string Hash(string s)
        {
            byte[] b = SHA1.HashData(Encoding.UTF8.GetBytes(s ?? ""));
            var sb = new StringBuilder(40);
            foreach (byte x in b) sb.Append(x.ToString("x2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }

        /// <summary>Nombre de archivo válido en Windows.</summary>
        public static string SafeName(string s, int max = 90)
        {
            if (string.IsNullOrWhiteSpace(s)) return "cancion";
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
            {
                if (Array.IndexOf(Path.GetInvalidFileNameChars(), c) >= 0 || c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            string r = sb.ToString().Trim().TrimEnd('.');
            while (r.Contains("  ")) r = r.Replace("  ", " ");
            if (r.Length > max) r = r.Substring(0, max).Trim();
            return r.Length == 0 ? "cancion" : r;
        }
    }

    /// <summary>Registro de errores (log.txt), sin datos de la cuenta.</summary>
    public static class Log
    {
        private static readonly object Gate = new object();
        private static string _file;

        public static void Init()
        {
            try
            {
                _file = Paths.File("log.txt");
                var fi = new FileInfo(_file);
                if (fi.Exists && fi.Length > 1_000_000) fi.Delete();
                Write("Inicio P Music " + typeof(Log).Assembly.GetName().Version);
            }
            catch { }
        }

        public static void Write(string msg)
        {
            if (_file == null) return;
            try
            {
                lock (Gate) System.IO.File.AppendAllText(_file, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ", CultureInfo.InvariantCulture) + msg + Environment.NewLine);
            }
            catch { }
        }

        public static void Error(Exception e, string where = "")
        {
            if (e == null) return;
            Write("ERROR " + where + " (0x" + e.HResult.ToString("X8", CultureInfo.InvariantCulture) + "): " + e);
        }
    }

    /// <summary>Contraseña y sesión cifradas con la cuenta de Windows (DPAPI): solo este usuario las lee.</summary>
    public static class Secret
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct DataBlob
        {
            public int cbData;
            public IntPtr pbData;
        }

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptProtectData(ref DataBlob dataIn, string description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, ref DataBlob dataOut);

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CryptUnprotectData(ref DataBlob dataIn, IntPtr description, IntPtr entropy,
            IntPtr reserved, IntPtr prompt, int flags, ref DataBlob dataOut);

        [DllImport("kernel32.dll")]
        private static extern IntPtr LocalFree(IntPtr mem);

        private const int UiForbidden = 0x1;

        public static string Protect(string plain)
        {
            if (string.IsNullOrEmpty(plain)) return "";
            byte[] result = Run(Encoding.UTF8.GetBytes(plain), true);
            return result == null ? "" : Convert.ToBase64String(result);
        }

        public static string Unprotect(string stored)
        {
            if (string.IsNullOrEmpty(stored)) return "";
            try
            {
                byte[] result = Run(Convert.FromBase64String(stored), false);
                return result == null ? "" : Encoding.UTF8.GetString(result);
            }
            catch
            {
                return "";
            }
        }

        private static byte[] Run(byte[] data, bool protect)
        {
            IntPtr buf = Marshal.AllocHGlobal(Math.Max(1, data.Length));
            try
            {
                Marshal.Copy(data, 0, buf, data.Length);
                var input = new DataBlob { cbData = data.Length, pbData = buf };
                var output = new DataBlob();
                bool ok = protect
                    ? CryptProtectData(ref input, "PMusic", IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, UiForbidden, ref output)
                    : CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, UiForbidden, ref output);
                if (!ok || output.pbData == IntPtr.Zero) return null;
                var bytes = new byte[output.cbData];
                Marshal.Copy(output.pbData, bytes, 0, output.cbData);
                LocalFree(output.pbData);
                return bytes;
            }
            finally
            {
                Marshal.FreeHGlobal(buf);
            }
        }
    }

    /// <summary>Lectura tolerante de JSON.</summary>
    public static class J
    {
        public static JsonNode Parse(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            try { return JsonNode.Parse(s); }
            catch { return null; }
        }

        public static JsonObject Obj(string s) => Parse(s) as JsonObject;

        public static string Text(JsonNode v, string def = "")
        {
            if (v == null) return def;
            if (v is JsonValue jv)
            {
                if (jv.TryGetValue(out string s)) return s ?? def;
                if (jv.TryGetValue(out long l)) return l.ToString(CultureInfo.InvariantCulture);
                if (jv.TryGetValue(out double d)) return d.ToString(CultureInfo.InvariantCulture);
                if (jv.TryGetValue(out bool b)) return b ? "true" : "false";
                return Js.Node(jv).Trim('"');
            }
            return def;
        }

        public static string Str(JsonNode n, string key, string def = "")
        {
            if (!(n is JsonObject o)) return def;
            JsonNode v;
            if (!o.TryGetPropertyValue(key, out v) || v == null) return def;
            return Text(v, def) ?? def;
        }

        public static long Long(JsonNode n, string key, long def = 0)
        {
            string s = Str(n, key, "");
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out long l)) return l;
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out double d)) return (long)d;
            return def;
        }

        public static bool Bool(JsonNode n, string key, bool def = false)
        {
            string s = Str(n, key, "").Trim().ToLowerInvariant();
            if (s.Length == 0) return def;
            return s == "true" || s == "1" || s == "yes";
        }

        public static JsonObject ObjOf(JsonNode n, string key) => (n as JsonObject)?[key] as JsonObject;
        public static JsonArray ArrOf(JsonNode n, string key) => (n as JsonObject)?[key] as JsonArray;

        /// <summary>Camino dentro del JSON: nombres de campo o números de posición.</summary>
        public static JsonNode At(JsonNode n, params string[] path)
        {
            JsonNode cur = n;
            foreach (string p in path)
            {
                if (cur == null) return null;
                if (cur is JsonArray a)
                {
                    int i;
                    if (!int.TryParse(p, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) return null;
                    if (i < 0) i = a.Count + i;
                    if (i < 0 || i >= a.Count) return null;
                    cur = a[i];
                }
                else if (cur is JsonObject o)
                {
                    JsonNode v;
                    if (!o.TryGetPropertyValue(p, out v)) return null;
                    cur = v;
                }
                else return null;
            }
            return cur;
        }

        public static string AtStr(JsonNode n, params string[] path) => Text(At(n, path), "");

        public static long ToLong(string s, long def = 0)
        {
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out long l)) return l;
            return def;
        }

        public static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        public static JsonNode Clone(JsonNode n) => n?.DeepClone();
    }
}
