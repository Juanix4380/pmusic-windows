using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PMusic.Core
{
    public sealed class HttpResult
    {
        public int Code;
        public string Body = "";
        public bool Ok => Code >= 200 && Code < 300;
    }

    /// <summary>
    /// Clientes HTTP de la app: conexiones reutilizadas, descompresión y tiempos de espera cortos.
    /// Las cuentas y la nube van por un cliente que no sigue redirecciones (como en Android).
    /// </summary>
    public static class Net
    {
        public const string Desktop = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
        public const string AppAgent = "PMusic/1.0 (Windows; reproductor personal)";

        public static readonly HttpClient Client = Create(true);
        public static readonly HttpClient Strict = Create(false);

        private static HttpClient Create(bool redirects)
        {
            var handler = new SocketsHttpHandler
            {
                AutomaticDecompression = DecompressionMethods.All,
                PooledConnectionLifetime = TimeSpan.FromMinutes(5),
                PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
                MaxConnectionsPerServer = 12,
                ConnectTimeout = TimeSpan.FromSeconds(10),
                AllowAutoRedirect = redirects,
                MaxAutomaticRedirections = 8,
                UseCookies = false
            };
            var c = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
            c.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", Desktop);
            c.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "*/*");
            return c;
        }

        public static async Task<string> GetString(string url, int timeoutMs = 20000, IDictionary<string, string> headers = null,
            CancellationToken ct = default(CancellationToken))
        {
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(timeoutMs);
                using (var req = new HttpRequestMessage(HttpMethod.Get, url))
                {
                    if (headers != null) foreach (var h in headers) req.Headers.TryAddWithoutValidation(h.Key, h.Value);
                    using (var resp = await Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                    {
                        if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                        return await resp.Content.ReadAsStringAsync(cts.Token).ConfigureAwait(false);
                    }
                }
            }
        }

        /// <summary>GET que regresa el código aunque no sea 200 (para saber si no existe).</summary>
        public static async Task<HttpResult> Get(string url, int timeoutMs, IDictionary<string, string> headers = null)
        {
            using (var cts = new CancellationTokenSource(timeoutMs))
            using (var req = new HttpRequestMessage(HttpMethod.Get, url))
            {
                if (headers != null) foreach (var h in headers) req.Headers.TryAddWithoutValidation(h.Key, h.Value);
                using (var resp = await Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                {
                    var r = new HttpResult { Code = (int)resp.StatusCode };
                    r.Body = await resp.Content.ReadAsStringAsync(cts.Token).ConfigureAwait(false);
                    return r;
                }
            }
        }

        /// <summary>¿Hay internet de verdad? (no solo Wi-Fi conectado).</summary>
        public static async Task<bool> Online()
        {
            foreach (string url in new[] { "https://www.gstatic.com/generate_204", "https://www.youtube.com/generate_204" })
            {
                try
                {
                    var r = await Get(url, 5000).ConfigureAwait(false);
                    if (r.Code == 204 || r.Code == 200) return true;
                }
                catch { }
            }
            return false;
        }

        public static async Task<byte[]> GetBytes(string url, int timeoutMs = 20000, CancellationToken ct = default(CancellationToken))
        {
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(timeoutMs);
                using (var resp = await Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                {
                    if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                    return await resp.Content.ReadAsByteArrayAsync(cts.Token).ConfigureAwait(false);
                }
            }
        }

        /// <summary>POST con cuerpo JSON. Regresa código y texto (sin lanzar error por códigos 4xx/5xx).</summary>
        public static async Task<HttpResult> PostJson(string url, string json, IDictionary<string, string> headers, int timeoutMs,
            bool strict = false, int maxBytes = 4 * 1024 * 1024)
        {
            using (var cts = new CancellationTokenSource(timeoutMs))
            using (var req = new HttpRequestMessage(HttpMethod.Post, url))
            {
                req.Content = new StringContent(json ?? "{}", Encoding.UTF8, "application/json");
                if (headers != null) foreach (var h in headers) req.Headers.TryAddWithoutValidation(h.Key, h.Value);
                var client = strict ? Strict : Client;
                using (var resp = await client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                {
                    var r = new HttpResult { Code = (int)resp.StatusCode };
                    using (var s = await resp.Content.ReadAsStreamAsync(cts.Token).ConfigureAwait(false))
                    using (var ms = new MemoryStream())
                    {
                        var buf = new byte[16384];
                        int n;
                        while ((n = await s.ReadAsync(buf, 0, buf.Length, cts.Token).ConfigureAwait(false)) > 0)
                        {
                            if (ms.Length + n > maxBytes) throw new IOException("Respuesta demasiado grande");
                            ms.Write(buf, 0, n);
                        }
                        r.Body = Encoding.UTF8.GetString(ms.ToArray());
                    }
                    return r;
                }
            }
        }
    }
}
