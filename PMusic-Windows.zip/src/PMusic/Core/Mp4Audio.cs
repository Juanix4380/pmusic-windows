using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PMusic.Core
{
    /// <summary>
    /// El audio llega como MP4 "fragmentado" (formato de streaming). El reproductor de Windows lo abre
    /// pero lo ve de 0 segundos y lo termina al instante. Aquí se pasa a AAC simple (ADTS), que
    /// Windows toca completo, con su duración y adelantar/regresar.
    /// </summary>
    public static class Mp4Audio
    {
        private struct Box
        {
            public string Type;
            public long Start;
            public long DataStart;
            public long End;
        }

        private static uint U32(byte[] b, long p) =>
            (uint)(b[p] << 24) | (uint)(b[p + 1] << 16) | (uint)(b[p + 2] << 8) | b[p + 3];

        private static ulong U64(byte[] b, long p) => ((ulong)U32(b, p) << 32) | U32(b, p + 4);

        private static List<Box> Children(byte[] b, long from, long to)
        {
            var list = new List<Box>();
            long p = from;
            while (p + 8 <= to)
            {
                long size = U32(b, p);
                string type = Encoding.ASCII.GetString(b, (int)p + 4, 4);
                long header = 8;
                if (size == 1)
                {
                    if (p + 16 > to) break;
                    size = (long)U64(b, p + 8);
                    header = 16;
                }
                else if (size == 0) size = to - p;
                if (size < header || p + size > to) break;
                list.Add(new Box { Type = type, Start = p, DataStart = p + header, End = p + size });
                p += size;
            }
            return list;
        }

        private static Box? Find(List<Box> boxes, string type)
        {
            foreach (var x in boxes) if (x.Type == type) return x;
            return null;
        }

        private static Box? Deep(byte[] b, Box parent, params string[] path)
        {
            Box cur = parent;
            foreach (string t in path)
            {
                var next = Find(Children(b, cur.DataStart, cur.End), t);
                if (next == null) return null;
                cur = next.Value;
            }
            return cur;
        }

        /// <summary>¿Es un MP4 fragmentado (el que Windows no toca bien)?</summary>
        public static bool NeedsFix(string path)
        {
            string ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext != ".m4a" && ext != ".mp4") return false;
            try
            {
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    var head = new byte[16];
                    long p = 0, len = fs.Length;
                    while (p + 8 <= len)
                    {
                        fs.Position = p;
                        int got = fs.Read(head, 0, 16);
                        if (got < 8) break;
                        long size = U32(head, 0);
                        string type = Encoding.ASCII.GetString(head, 4, 4);
                        if (type == "moof") return true;
                        if (size == 1)
                        {
                            if (got < 16) break;
                            size = (long)U64(head, 8);
                        }
                        else if (size == 0) break;
                        if (size < 8) break;
                        p += size;
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>Convierte el MP4 fragmentado a AAC con encabezados ADTS.</summary>
        public static void ToAdts(string input, string output)
        {
            byte[] b = File.ReadAllBytes(input);
            var top = Children(b, 0, b.Length);
            var moovBox = Find(top, "moov");
            if (moovBox == null) throw new InvalidDataException("Archivo sin encabezado");
            var moov = moovBox.Value;

            // Pista de audio: id, configuración AAC y tamaño por omisión de las muestras.
            uint trackId = 0;
            int objectType = 2, freqIndex = 4, channels = 2;
            foreach (var trak in Children(b, moov.DataStart, moov.End))
            {
                if (trak.Type != "trak") continue;
                var stsd = Deep(b, trak, "mdia", "minf", "stbl", "stsd");
                if (stsd == null) continue;
                long esds = IndexOf(b, stsd.Value.DataStart, stsd.Value.End, "esds");
                if (esds < 4) continue;
                var tkhd = Find(Children(b, trak.DataStart, trak.End), "tkhd");
                if (tkhd != null)
                {
                    long q = tkhd.Value.DataStart;
                    int version = b[q];
                    trackId = U32(b, q + 4 + (version == 1 ? 16 : 8));
                }
                ReadAudioConfig(b, esds - 4, stsd.Value.End, ref objectType, ref freqIndex, ref channels);
                break;
            }
            uint defaultSize = 0;
            var trex = Deep(b, moov, "mvex", "trex");
            if (trex != null) defaultSize = U32(b, trex.Value.DataStart + 16);

            int profile = objectType >= 1 && objectType <= 4 ? objectType - 1 : 1;
            int frames = 0;
            using (var outStream = new FileStream(output + ".tmp", FileMode.Create, FileAccess.Write))
            {
                var header = new byte[7];
                for (int i = 0; i < top.Count; i++)
                {
                    var moof = top[i];
                    if (moof.Type != "moof") continue;
                    long mdatPayload = -1;
                    for (int k = i + 1; k < top.Count; k++)
                        if (top[k].Type == "mdat") { mdatPayload = top[k].DataStart; break; }
                    foreach (var traf in Children(b, moof.DataStart, moof.End))
                    {
                        if (traf.Type != "traf") continue;
                        var kids = Children(b, traf.DataStart, traf.End);
                        var tfhdBox = Find(kids, "tfhd");
                        if (tfhdBox == null) continue;
                        long p = tfhdBox.Value.DataStart;
                        uint flags = U32(b, p) & 0xFFFFFF;
                        p += 4;
                        uint tid = U32(b, p);
                        p += 4;
                        if (trackId != 0 && tid != trackId) continue;
                        long baseOffset = moof.Start;
                        if ((flags & 0x1) != 0) { baseOffset = (long)U64(b, p); p += 8; }
                        if ((flags & 0x2) != 0) p += 4;
                        if ((flags & 0x8) != 0) p += 4;
                        uint sampleSize = defaultSize;
                        if ((flags & 0x10) != 0) { sampleSize = U32(b, p); p += 4; }
                        long cursor = -1;
                        foreach (var trun in kids)
                        {
                            if (trun.Type != "trun") continue;
                            long q = trun.DataStart;
                            uint tf = U32(b, q) & 0xFFFFFF;
                            q += 4;
                            uint count = U32(b, q);
                            q += 4;
                            long data;
                            if ((tf & 0x1) != 0) { data = baseOffset + (int)U32(b, q); q += 4; }
                            else data = cursor >= 0 ? cursor : mdatPayload;
                            if ((tf & 0x4) != 0) q += 4;
                            if (data < 0) continue;
                            for (uint n = 0; n < count; n++)
                            {
                                if ((tf & 0x100) != 0) q += 4;
                                uint size = sampleSize;
                                if ((tf & 0x200) != 0) { size = U32(b, q); q += 4; }
                                if ((tf & 0x400) != 0) q += 4;
                                if ((tf & 0x800) != 0) q += 4;
                                if (size == 0 || size > 8000 || data + size > b.Length) break;
                                int len = (int)size + 7;
                                header[0] = 0xFF;
                                header[1] = 0xF1;
                                header[2] = (byte)((profile << 6) | (freqIndex << 2) | ((channels >> 2) & 0x1));
                                header[3] = (byte)(((channels & 0x3) << 6) | (len >> 11));
                                header[4] = (byte)((len >> 3) & 0xFF);
                                header[5] = (byte)(((len & 0x7) << 5) | 0x1F);
                                header[6] = 0xFC;
                                outStream.Write(header, 0, 7);
                                outStream.Write(b, (int)data, (int)size);
                                data += size;
                                frames++;
                            }
                            cursor = data;
                        }
                    }
                }
            }
            if (frames < 20)
            {
                try { File.Delete(output + ".tmp"); } catch { }
                throw new InvalidDataException("No se encontró audio AAC");
            }
            if (File.Exists(output)) File.Delete(output);
            File.Move(output + ".tmp", output);
        }

        // ------------------------------------------------------------ MP4 normal (duración exacta)

        /// <summary>Escritor de cajas MP4 (big-endian).</summary>
        private sealed class Writer
        {
            private readonly MemoryStream _m = new MemoryStream();
            public long Pos => _m.Position;
            public void Put8(int v) => _m.WriteByte((byte)v);
            public void Put16(int v) { Put8(v >> 8); Put8(v); }
            public void Put32(long v) { Put8((int)(v >> 24)); Put8((int)(v >> 16)); Put8((int)(v >> 8)); Put8((int)v); }
            public void Zeros(int n) { for (int i = 0; i < n; i++) _m.WriteByte(0); }
            public void Text(string s) { var x = Encoding.ASCII.GetBytes(s); _m.Write(x, 0, x.Length); }
            public void Raw(byte[] b, long off, long len) => _m.Write(b, (int)off, (int)len);
            public long Begin(string type) { long p = _m.Position; Put32(0); Text(type); return p; }
            public long BeginFull(string type, int version, int flags) { long p = Begin(type); Put8(version); Put8(flags >> 16); Put8(flags >> 8); Put8(flags); return p; }
            public void End(long start) { long end = _m.Position; _m.Position = start; Put32(end - start); _m.Position = end; }
            public void Patch32(long at, long v) { long end = _m.Position; _m.Position = at; Put32(v); _m.Position = end; }
            public byte[] ToArray() => _m.ToArray();

            public void Matrix()
            {
                Put32(0x00010000); Put32(0); Put32(0);
                Put32(0); Put32(0x00010000); Put32(0);
                Put32(0); Put32(0); Put32(0x40000000);
            }
        }

        /// <summary>
        /// Rearma el MP4 fragmentado como MP4 normal (mismo audio, sin recomprimir) y lo deja en la
        /// misma ruta. Así Windows ve la duración real y se puede adelantar.
        /// </summary>
        public static void Remux(string path)
        {
            byte[] b = File.ReadAllBytes(path);
            var top = Children(b, 0, b.Length);
            var moovBox = Find(top, "moov");
            if (moovBox == null) throw new InvalidDataException("Archivo sin encabezado");
            var moov = moovBox.Value;
            uint trackId = 0, timescale = 44100;
            Box? stsdBox = null;
            foreach (var trak in Children(b, moov.DataStart, moov.End))
            {
                if (trak.Type != "trak") continue;
                var stsd = Deep(b, trak, "mdia", "minf", "stbl", "stsd");
                if (stsd == null || IndexOf(b, stsd.Value.DataStart, stsd.Value.End, "mp4a") < 0) continue;
                stsdBox = stsd;
                var tkhd = Find(Children(b, trak.DataStart, trak.End), "tkhd");
                if (tkhd != null)
                {
                    long q = tkhd.Value.DataStart;
                    trackId = U32(b, q + 4 + (b[q] == 1 ? 16 : 8));
                }
                var mdhd = Deep(b, trak, "mdia", "mdhd");
                if (mdhd != null)
                {
                    long q = mdhd.Value.DataStart;
                    uint ts = U32(b, q + 4 + (b[q] == 1 ? 16 : 8));
                    if (ts > 0) timescale = ts;
                }
                break;
            }
            if (stsdBox == null) throw new InvalidDataException("Sin pista de audio AAC");
            uint defaultSize = 0, defaultDuration = 1024;
            var trex = Deep(b, moov, "mvex", "trex");
            if (trex != null)
            {
                uint d = U32(b, trex.Value.DataStart + 12);
                if (d > 0) defaultDuration = d;
                defaultSize = U32(b, trex.Value.DataStart + 16);
            }

            // Muestras: posición, tamaño y duración.
            var offsets = new List<long>();
            var sizes = new List<uint>();
            var durations = new List<uint>();
            for (int i = 0; i < top.Count; i++)
            {
                var moof = top[i];
                if (moof.Type != "moof") continue;
                long mdatPayload = -1;
                for (int k = i + 1; k < top.Count; k++)
                    if (top[k].Type == "mdat") { mdatPayload = top[k].DataStart; break; }
                foreach (var traf in Children(b, moof.DataStart, moof.End))
                {
                    if (traf.Type != "traf") continue;
                    var kids = Children(b, traf.DataStart, traf.End);
                    var tfhdBox = Find(kids, "tfhd");
                    if (tfhdBox == null) continue;
                    long p = tfhdBox.Value.DataStart;
                    uint flags = U32(b, p) & 0xFFFFFF;
                    p += 4;
                    uint tid = U32(b, p);
                    p += 4;
                    if (trackId != 0 && tid != trackId) continue;
                    long baseOffset = moof.Start;
                    if ((flags & 0x1) != 0) { baseOffset = (long)U64(b, p); p += 8; }
                    if ((flags & 0x2) != 0) p += 4;
                    uint sampleDuration = defaultDuration;
                    if ((flags & 0x8) != 0) { sampleDuration = U32(b, p); p += 4; }
                    uint sampleSize = defaultSize;
                    if ((flags & 0x10) != 0) { sampleSize = U32(b, p); p += 4; }
                    long cursor = -1;
                    foreach (var trun in kids)
                    {
                        if (trun.Type != "trun") continue;
                        long q = trun.DataStart;
                        uint tf = U32(b, q) & 0xFFFFFF;
                        q += 4;
                        uint count = U32(b, q);
                        q += 4;
                        long data;
                        if ((tf & 0x1) != 0) { data = baseOffset + (int)U32(b, q); q += 4; }
                        else data = cursor >= 0 ? cursor : mdatPayload;
                        if ((tf & 0x4) != 0) q += 4;
                        if (data < 0) continue;
                        for (uint n = 0; n < count; n++)
                        {
                            uint dur = sampleDuration;
                            if ((tf & 0x100) != 0) { dur = U32(b, q); q += 4; }
                            uint size = sampleSize;
                            if ((tf & 0x200) != 0) { size = U32(b, q); q += 4; }
                            if ((tf & 0x400) != 0) q += 4;
                            if ((tf & 0x800) != 0) q += 4;
                            if (size == 0 || data + size > b.Length) break;
                            offsets.Add(data);
                            sizes.Add(size);
                            durations.Add(dur == 0 ? 1024 : dur);
                            data += size;
                        }
                        cursor = data;
                    }
                }
            }
            if (sizes.Count < 20) throw new InvalidDataException("No se encontró audio");
            long total = 0;
            foreach (uint d in durations) total += d;

            var w = new Writer();
            long ftyp = w.Begin("ftyp");
            w.Text("M4A ");
            w.Put32(0);
            w.Text("M4A ");
            w.Text("mp42");
            w.Text("isom");
            w.End(ftyp);

            long moovStart = w.Begin("moov");
            long mvhd = w.BeginFull("mvhd", 0, 0);
            w.Put32(0); w.Put32(0); w.Put32(timescale); w.Put32(total);
            w.Put32(0x00010000); w.Put16(0x0100); w.Zeros(10);
            w.Matrix();
            w.Zeros(24);
            w.Put32(2);
            w.End(mvhd);

            long trakStart = w.Begin("trak");
            long tkhdStart = w.BeginFull("tkhd", 0, 7);
            w.Put32(0); w.Put32(0); w.Put32(1); w.Put32(0); w.Put32(total);
            w.Zeros(8); w.Put16(0); w.Put16(0); w.Put16(0x0100); w.Put16(0);
            w.Matrix();
            w.Put32(0); w.Put32(0);
            w.End(tkhdStart);

            long mdia = w.Begin("mdia");
            long mdhdStart = w.BeginFull("mdhd", 0, 0);
            w.Put32(0); w.Put32(0); w.Put32(timescale); w.Put32(total);
            w.Put16(0x55C4); w.Put16(0);
            w.End(mdhdStart);
            long hdlr = w.BeginFull("hdlr", 0, 0);
            w.Put32(0); w.Text("soun"); w.Zeros(12); w.Text("SoundHandler"); w.Put8(0);
            w.End(hdlr);

            long minf = w.Begin("minf");
            long smhd = w.BeginFull("smhd", 0, 0);
            w.Put16(0); w.Put16(0);
            w.End(smhd);
            long dinf = w.Begin("dinf");
            long dref = w.BeginFull("dref", 0, 0);
            w.Put32(1);
            long url = w.BeginFull("url ", 0, 1);
            w.End(url);
            w.End(dref);
            w.End(dinf);

            long stbl = w.Begin("stbl");
            var sd = stsdBox.Value;
            w.Raw(b, sd.Start, sd.End - sd.Start);

            // stts: duraciones agrupadas
            var runs = new List<long[]>();
            foreach (uint d in durations)
            {
                if (runs.Count > 0 && runs[runs.Count - 1][1] == d) runs[runs.Count - 1][0]++;
                else runs.Add(new long[] { 1, d });
            }
            long stts = w.BeginFull("stts", 0, 0);
            w.Put32(runs.Count);
            foreach (var r in runs) { w.Put32(r[0]); w.Put32(r[1]); }
            w.End(stts);

            long stsc = w.BeginFull("stsc", 0, 0);
            w.Put32(1); w.Put32(1); w.Put32(sizes.Count); w.Put32(1);
            w.End(stsc);

            long stsz = w.BeginFull("stsz", 0, 0);
            w.Put32(0); w.Put32(sizes.Count);
            foreach (uint z in sizes) w.Put32(z);
            w.End(stsz);

            long stco = w.BeginFull("stco", 0, 0);
            w.Put32(1);
            long chunkOffsetAt = w.Pos;
            w.Put32(0);
            w.End(stco);

            w.End(stbl);
            w.End(minf);
            w.End(mdia);
            w.End(trakStart);
            w.End(moovStart);

            long payload = 0;
            foreach (uint z in sizes) payload += z;
            long mdatHeaderAt = w.Pos;
            w.Patch32(chunkOffsetAt, mdatHeaderAt + 8);
            byte[] head = w.ToArray();

            string tmp = path + ".fix";
            using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
            {
                fs.Write(head, 0, head.Length);
                var mh = new byte[8];
                long mdatSize = payload + 8;
                mh[0] = (byte)(mdatSize >> 24); mh[1] = (byte)(mdatSize >> 16); mh[2] = (byte)(mdatSize >> 8); mh[3] = (byte)mdatSize;
                mh[4] = (byte)'m'; mh[5] = (byte)'d'; mh[6] = (byte)'a'; mh[7] = (byte)'t';
                fs.Write(mh, 0, 8);
                for (int i = 0; i < sizes.Count; i++) fs.Write(b, (int)offsets[i], (int)sizes[i]);
            }
            File.Delete(path);
            File.Move(tmp, path);
        }

        private static long IndexOf(byte[] b, long from, long to, string ascii)
        {
            byte c0 = (byte)ascii[0], c1 = (byte)ascii[1], c2 = (byte)ascii[2], c3 = (byte)ascii[3];
            for (long i = from; i + 4 <= to; i++)
                if (b[i] == c0 && b[i + 1] == c1 && b[i + 2] == c2 && b[i + 3] == c3) return i;
            return -1;
        }

        private static int DescLength(byte[] b, ref long p, long end)
        {
            int len = 0;
            for (int i = 0; i < 4 && p < end; i++)
            {
                byte x = b[p++];
                len = (len << 7) | (x & 0x7F);
                if ((x & 0x80) == 0) break;
            }
            return len;
        }

        /// <summary>Lee el AudioSpecificConfig (tipo AAC, frecuencia y canales) del esds.</summary>
        private static void ReadAudioConfig(byte[] b, long esdsBox, long limit, ref int objectType, ref int freqIndex, ref int channels)
        {
            try
            {
                long end = Math.Min(limit, esdsBox + U32(b, esdsBox));
                long p = esdsBox + 12;
                if (p >= end || b[p] != 0x03) return;
                p++;
                DescLength(b, ref p, end);
                p += 2;
                byte esFlags = b[p++];
                if ((esFlags & 0x80) != 0) p += 2;
                if ((esFlags & 0x40) != 0) { int urlLen = b[p++]; p += urlLen; }
                if ((esFlags & 0x20) != 0) p += 2;
                if (p >= end || b[p] != 0x04) return;
                p++;
                DescLength(b, ref p, end);
                p += 13;
                if (p >= end || b[p] != 0x05) return;
                p++;
                int ascLen = DescLength(b, ref p, end);
                if (ascLen < 2 || p + 2 > end) return;
                int v = (b[p] << 8) | b[p + 1];
                int aot = v >> 11;
                int fi = (v >> 7) & 0xF;
                int ch = (v >> 3) & 0xF;
                if (aot >= 1 && aot <= 4) objectType = aot;
                else objectType = 2;
                if (fi < 13) freqIndex = fi;
                if (ch >= 1 && ch <= 7) channels = ch;
            }
            catch { }
        }
    }
}
