using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos;
using YoutubeExplode.Videos.Streams;

namespace PMusic.Core
{
    /// <summary>Audio listo para tocar: enlace directo o archivo en la PC.</summary>
    public sealed class AudioSource
    {
        public string Url;
        public string File;
        public bool IsFile => !string.IsNullOrEmpty(File);
    }

    /// <summary>
    /// Saca el audio de cada canción (el de mejor calidad en AAC, que Windows toca sin extras),
    /// guarda una copia en caché para que se repita y adelante sin cortes, y si algo falla usa un
    /// segundo método que se descarga solo la primera vez.
    /// </summary>
    public static class Streams
    {
        private static readonly YoutubeClient Client = new YoutubeClient();
        private static readonly ConcurrentDictionary<string, KeyValuePair<DateTime, IStreamInfo>> Resolved =
            new ConcurrentDictionary<string, KeyValuePair<DateTime, IStreamInfo>>();
        private static readonly ConcurrentDictionary<string, Task<string>> Fetching = new ConcurrentDictionary<string, Task<string>>();
        private static readonly SemaphoreSlim ToolGate = new SemaphoreSlim(1);
        private static readonly string[] Exts = { ".m4a", ".webm", ".mp4", ".opus", ".mp3" };
        private const long CacheMax = 1536L * 1024 * 1024;

        private static string CacheDir => Paths.Dir("cache");

        public static void PruneCache()
        {
            Task.Run(() =>
            {
                try
                {
                    var files = new DirectoryInfo(CacheDir).GetFiles().OrderByDescending(f => f.LastAccessTimeUtc).ToList();
                    long total = 0;
                    foreach (var f in files)
                    {
                        if (f.Name.EndsWith(".part", StringComparison.OrdinalIgnoreCase) && f.LastWriteTimeUtc < DateTime.UtcNow.AddHours(-1))
                        {
                            try { f.Delete(); } catch { }
                            continue;
                        }
                        total += f.Length;
                        if (total > CacheMax) { try { f.Delete(); } catch { } }
                    }
                }
                catch { }
            });
        }

        public static long CacheBytes()
        {
            try { return new DirectoryInfo(CacheDir).GetFiles().Sum(f => f.Length); }
            catch { return 0; }
        }

        public static void ClearCache()
        {
            try
            {
                foreach (var f in new DirectoryInfo(CacheDir).GetFiles())
                    try { f.Delete(); } catch { }
            }
            catch { }
        }

        /// <summary>Archivo ya guardado en caché para este id (o null).</summary>
        public static string Cached(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            foreach (string ext in Exts)
            {
                string p = Path.Combine(CacheDir, id + ext);
                try
                {
                    var fi = new FileInfo(p);
                    if (fi.Exists && fi.Length > 32 * 1024)
                    {
                        try { fi.LastAccessTimeUtc = DateTime.UtcNow; } catch { }
                        return p;
                    }
                }
                catch { }
            }
            return null;
        }

        // ------------------------------------------------------------ enlace directo

        private static async Task<IStreamInfo> Pick(string id, CancellationToken ct)
        {
            KeyValuePair<DateTime, IStreamInfo> hit;
            if (Resolved.TryGetValue(id, out hit) && hit.Key > DateTime.UtcNow) return hit.Value;
            var manifest = await Client.Videos.Streams.GetManifestAsync(VideoId.Parse(id), cancellationToken: ct).ConfigureAwait(false);
            var audio = manifest.GetAudioOnlyStreams().ToList();
            IStreamInfo best =
                audio.Where(s => s.Container.Name == "mp4").OrderByDescending(s => s.Bitrate.BitsPerSecond).FirstOrDefault() as IStreamInfo
                ?? audio.OrderByDescending(s => s.Bitrate.BitsPerSecond).FirstOrDefault() as IStreamInfo
                ?? manifest.GetMuxedStreams().OrderBy(s => s.Size.Bytes).FirstOrDefault() as IStreamInfo;
            if (best == null) throw new IOException("Sin audio disponible");
            Resolved[id] = new KeyValuePair<DateTime, IStreamInfo>(DateTime.UtcNow.AddHours(4), best);
            return best;
        }

        /// <summary>Lo más rápido para empezar: caché si existe, si no el enlace directo.</summary>
        public static async Task<AudioSource> Resolve(string id, CancellationToken ct)
        {
            string file = Downloads.FileFor(id) ?? Cached(id);
            if (file != null) return new AudioSource { File = file };
            var info = await Pick(id, ct).ConfigureAwait(false);
            return new AudioSource { Url = info.Url };
        }

        public static void Forget(string id)
        {
            KeyValuePair<DateTime, IStreamInfo> x;
            Resolved.TryRemove(id, out x);
        }

        // ------------------------------------------------------------ copia completa en caché

        /// <summary>Descarga la canción completa a la caché (una sola vez aunque se pida varias).</summary>
        public static Task<string> Fetch(string id, CancellationToken ct = default(CancellationToken))
        {
            string done = Cached(id);
            if (done != null) return Task.FromResult(done);
            return Fetching.GetOrAdd(id, k => Task.Run(async () =>
            {
                try { return await FetchCore(k, ct).ConfigureAwait(false); }
                finally
                {
                    Task<string> t;
                    Fetching.TryRemove(k, out t);
                }
            }));
        }

        private static async Task<string> FetchCore(string id, CancellationToken ct)
        {
            Exception first = null;
            try
            {
                var info = await Pick(id, ct).ConfigureAwait(false);
                string ext = "." + (info.Container.Name == "mp4" ? (info is AudioOnlyStreamInfo ? "m4a" : "mp4") : info.Container.Name);
                string target = Path.Combine(CacheDir, id + ext);
                string part = target + ".part";
                await Client.Videos.Streams.DownloadAsync(info, part, cancellationToken: ct).ConfigureAwait(false);
                if (new FileInfo(part).Length < 32 * 1024) throw new IOException("Archivo incompleto");
                if (File.Exists(target)) File.Delete(target);
                File.Move(part, target);
                return target;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception e)
            {
                first = e;
                Forget(id);
                Log.Write("Audio " + id + ": método 1 falló (" + e.GetType().Name + ": " + e.Message + ")");
            }
            try
            {
                return await ViaTool(id, ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception e)
            {
                Log.Write("Audio " + id + ": método 2 falló (" + e.Message + ")");
                throw new IOException("No se pudo obtener el audio", first ?? e);
            }
        }

        // ------------------------------------------------------------ segundo método (herramienta)

        private static string ToolPath => Path.Combine(Paths.Dir("tools"), "yt-dlp.exe");

        private static async Task EnsureTool(CancellationToken ct)
        {
            await ToolGate.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                var fi = new FileInfo(ToolPath);
                if (fi.Exists && fi.Length > 1024 * 1024)
                {
                    if (fi.LastWriteTimeUtc < DateTime.UtcNow.AddDays(-14)) UpdateTool();
                    return;
                }
                Log.Write("Descargando herramienta de audio…");
                var bytes = await Net.GetBytes("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe", 180000, ct).ConfigureAwait(false);
                if (bytes.Length < 1024 * 1024) throw new IOException("Herramienta incompleta");
                string part = ToolPath + ".part";
                File.WriteAllBytes(part, bytes);
                if (File.Exists(ToolPath)) File.Delete(ToolPath);
                File.Move(part, ToolPath);
            }
            finally
            {
                ToolGate.Release();
            }
        }

        private static void UpdateTool()
        {
            try
            {
                File.SetLastWriteTimeUtc(ToolPath, DateTime.UtcNow);
                var psi = new ProcessStartInfo(ToolPath) { UseShellExecute = false, CreateNoWindow = true };
                psi.ArgumentList.Add("-U");
                Process.Start(psi);
            }
            catch { }
        }

        private static async Task<string> ViaTool(string id, CancellationToken ct)
        {
            await EnsureTool(ct).ConfigureAwait(false);
            string dir = CacheDir;
            string pattern = id + ".dl";
            foreach (var old in Directory.GetFiles(dir, pattern + ".*")) { try { File.Delete(old); } catch { } }
            var psi = new ProcessStartInfo(ToolPath)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };
            foreach (string a in new[]
            {
                "-f", "bestaudio[ext=m4a]/bestaudio/best", "--no-playlist", "--no-warnings", "--no-progress",
                "--force-overwrites", "--no-mtime", "-o", Path.Combine(dir, pattern + ".%(ext)s"), PMusic.Core.Yt.WatchUrl(id)
            }) psi.ArgumentList.Add(a);
            using (var p = Process.Start(psi))
            {
                if (p == null) throw new IOException("No se pudo abrir la herramienta");
                var err = p.StandardError.ReadToEndAsync();
                var outp = p.StandardOutput.ReadToEndAsync();
                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
                {
                    cts.CancelAfter(TimeSpan.FromMinutes(3));
                    try { await p.WaitForExitAsync(cts.Token).ConfigureAwait(false); }
                    catch (OperationCanceledException)
                    {
                        try { p.Kill(true); } catch { }
                        throw;
                    }
                }
                string e = await err.ConfigureAwait(false);
                if (p.ExitCode != 0) throw new IOException("Código " + p.ExitCode + ": " + (e.Length > 300 ? e.Substring(0, 300) : e));
            }
            var file = Directory.GetFiles(dir, pattern + ".*")
                .Where(f => !f.EndsWith(".part", StringComparison.OrdinalIgnoreCase) && !f.EndsWith(".ytdl", StringComparison.OrdinalIgnoreCase))
                .Select(f => new FileInfo(f)).OrderByDescending(f => f.Length).FirstOrDefault();
            if (file == null || file.Length < 32 * 1024) throw new IOException("Sin archivo");
            string ext = file.Extension.ToLowerInvariant();
            string target = Path.Combine(dir, id + ext);
            if (File.Exists(target)) File.Delete(target);
            File.Move(file.FullName, target);
            return target;
        }
    }
}
