using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos;
using YoutubeExplode.Videos.Streams;

namespace PMusic.Core
{
    /// <summary>Audio listo para tocar: enlace directo o archivo en la PC.</summary>
    public sealed class AudioSource
    {
        public string Url;
        public string File;
        public bool IsFile => !string.IsNullOrEmpty(File);
    }

    /// <summary>
    /// Saca el audio de cada canción con dos métodos:
    /// 1) el rápido (enlace directo, AAC que Windows toca sin extras);
    /// 2) el de respaldo, el mismo motor que usan los descargadores más actualizados, con su
    ///    componente de JavaScript (se preparan solos en segundo plano la primera vez).
    /// Guarda una copia completa en caché para que no se corte ni tarde al cambiar de canción.
    /// </summary>
    public static class Streams
    {
        private static readonly YoutubeClient Client = new YoutubeClient();
        private static readonly ConcurrentDictionary<string, KeyValuePair<DateTime, IStreamInfo>> Resolved =
            new ConcurrentDictionary<string, KeyValuePair<DateTime, IStreamInfo>>();
        private static readonly ConcurrentDictionary<string, Task<string>> Fetching = new ConcurrentDictionary<string, Task<string>>();
        private static readonly ConcurrentDictionary<string, DateTime> QuickFailed = new ConcurrentDictionary<string, DateTime>();
        private static readonly SemaphoreSlim ToolGate = new SemaphoreSlim(1);
        private static readonly SemaphoreSlim ToolRun = new SemaphoreSlim(3);
        private static readonly string[] Exts = { ".aac", ".m4a", ".mp4", ".mp3", ".webm", ".opus" };
        private const long CacheMax = 1536L * 1024 * 1024;
        private static int _quickFails;
        private static DateTime _quickFailAt = DateTime.MinValue;

        private static string CacheDir => Paths.Dir("cache");

        /// <summary>Qué está haciendo el respaldo (para mostrarlo mientras carga).</summary>
        public static string Status { get; private set; } = "";
        private static bool _preparing;
        private static string _toolError = "";

        private static void SetStatus(string text) => Status = text ?? "";

        public static string ToolText
        {
            get
            {
                if (_preparing) return string.IsNullOrEmpty(Status) ? "Preparando…" : Status;
                if (ToolReady) return "Listo" + (FindDeno() != null ? "" : " (sin componente de JavaScript)");
                return string.IsNullOrEmpty(_toolError) ? "Pendiente" : "No disponible: " + _toolError;
            }
        }

        /// <summary>El método rápido falló varias veces seguidas: por un rato se usa primero el de respaldo.</summary>
        private static bool ToolFirst => _quickFails >= 2 && (DateTime.UtcNow - _quickFailAt).TotalMinutes < 30 && ToolReady;

        private static bool RecentlyFailed(string id)
        {
            DateTime t;
            return QuickFailed.TryGetValue(id, out t) && (DateTime.UtcNow - t).TotalMinutes < 10;
        }

        /// <summary>El enlace directo de esta canción no sirvió: la próxima vez va directo al respaldo.</summary>
        public static void MarkFailed(string id) => MarkQuickFail(id);

        private static void MarkQuickFail(string id)
        {
            QuickFailed[id] = DateTime.UtcNow;
            Interlocked.Increment(ref _quickFails);
            _quickFailAt = DateTime.UtcNow;
        }

        // ------------------------------------------------------------ caché

        public static void PruneCache()
        {
            Task.Run(() =>
            {
                try
                {
                    var files = new DirectoryInfo(CacheDir).GetFiles().OrderByDescending(f => f.LastAccessTimeUtc).ToList();
                    long total = 0;
                    foreach (var f in files)
                    {
                        if ((f.Name.EndsWith(".part", StringComparison.OrdinalIgnoreCase) || f.Name.Contains(".dl.")) &&
                            f.LastWriteTimeUtc < DateTime.UtcNow.AddHours(-1))
                        {
                            try { f.Delete(); } catch { }
                            continue;
                        }
                        total += f.Length;
                        if (total > CacheMax) { try { f.Delete(); } catch { } }
                    }
                }
                catch { }
            });
        }

        public static long CacheBytes()
        {
            try { return new DirectoryInfo(CacheDir).GetFiles().Sum(f => f.Length); }
            catch { return 0; }
        }

        public static void ClearCache()
        {
            try
            {
                foreach (var f in new DirectoryInfo(CacheDir).GetFiles())
                    try { f.Delete(); } catch { }
            }
            catch { }
        }

        /// <summary>Archivo ya guardado en caché para este id (o null).</summary>
        public static string Cached(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            foreach (string ext in Exts)
            {
                string p = Path.Combine(CacheDir, id + ext);
                try
                {
                    var fi = new FileInfo(p);
                    if (fi.Exists && fi.Length > 32 * 1024)
                    {
                        try { fi.LastAccessTimeUtc = DateTime.UtcNow; } catch { }
                        return Playable(p);
                    }
                }
                catch { }
            }
            return null;
        }

        private static readonly object ConvertGate = new object();

        /// <summary>
        /// Deja el archivo en un formato que Windows toca completo: el MP4 fragmentado se pasa a AAC
        /// (si no, Windows lo abre y lo termina al instante). Regresa la ruta final.
        /// </summary>
        public static string Playable(string path)
        {
            if (string.IsNullOrEmpty(path)) return path;
            lock (ConvertGate)
            {
                try
                {
                    if (!File.Exists(path) || !Mp4Audio.NeedsFix(path)) return path;
                    try
                    {
                        Mp4Audio.Remux(path);
                        Log.Write("Audio acomodado para Windows: " + Path.GetFileName(path));
                        return path;
                    }
                    catch (Exception e)
                    {
                        Log.Write("No se pudo acomodar " + Path.GetFileName(path) + " (" + e.Message + "), se pasa a AAC");
                    }
                    string aac = Path.ChangeExtension(path, ".aac");
                    var done = new FileInfo(aac);
                    if (!done.Exists || done.Length < 32 * 1024) Mp4Audio.ToAdts(path, aac);
                    try { File.Delete(path); } catch { }
                    Log.Write("Audio pasado a AAC: " + Path.GetFileName(aac));
                    return aac;
                }
                catch (Exception e)
                {
                    Log.Write("No se pudo convertir " + Path.GetFileName(path) + ": " + e.Message);
                    return path;
                }
            }
        }

        /// <summary>Borra la copia en caché (si salió dañada).</summary>
        public static void Drop(string id)
        {
            if (string.IsNullOrEmpty(id)) return;
            foreach (string ext in Exts)
                try { File.Delete(Path.Combine(CacheDir, id + ext)); } catch { }
        }

        // ------------------------------------------------------------ enlace directo (rápido)

        private static async Task<IStreamInfo> Pick(string id, CancellationToken ct)
        {
            KeyValuePair<DateTime, IStreamInfo> hit;
            if (Resolved.TryGetValue(id, out hit) && hit.Key > DateTime.UtcNow) return hit.Value;
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(12000);
                try
                {
                    var manifest = await Client.Videos.Streams.GetManifestAsync(VideoId.Parse(id), cancellationToken: cts.Token).ConfigureAwait(false);
                    var audio = manifest.GetAudioOnlyStreams().ToList();
                    IStreamInfo best =
                        audio.Where(s => s.Container.Name == "mp4").OrderByDescending(s => s.Bitrate.BitsPerSecond).FirstOrDefault() as IStreamInfo
                        ?? audio.OrderByDescending(s => s.Bitrate.BitsPerSecond).FirstOrDefault() as IStreamInfo
                        ?? manifest.GetMuxedStreams().OrderBy(s => s.Size.Bytes).FirstOrDefault() as IStreamInfo;
                    if (best == null) throw new IOException("Sin audio disponible");
                    Resolved[id] = new KeyValuePair<DateTime, IStreamInfo>(DateTime.UtcNow.AddHours(4), best);
                    _quickFails = 0;
                    return best;
                }
                catch (Exception e) when (!ct.IsCancellationRequested)
                {
                    MarkQuickFail(id);
                    Log.Write("Audio " + id + ": método rápido falló (" + e.GetType().Name + ": " + e.Message + ")");
                    throw;
                }
            }
        }

        /// <summary>
        /// Audio de la canción como archivo en la PC (descarga, caché o se baja completo ahora):
        /// así no depende del internet mientras suena y no hay enlaces que fallen a medio camino.
        /// </summary>
        public static async Task<AudioSource> Resolve(string id, CancellationToken ct)
        {
            string file = Downloads.FileFor(id) ?? Cached(id);
            if (file != null) return new AudioSource { File = file };
            var task = Fetch(id, ct);
            var done = await Task.WhenAny(task, Task.Delay(Timeout.Infinite, ct)).ConfigureAwait(false);
            ct.ThrowIfCancellationRequested();
            return new AudioSource { File = await task.ConfigureAwait(false) };
        }

        public static void Forget(string id)
        {
            KeyValuePair<DateTime, IStreamInfo> x;
            Resolved.TryRemove(id, out x);
        }

        // ------------------------------------------------------------ copia completa en caché

        /// <summary>Descarga la canción completa a la caché (una sola vez aunque se pida varias).</summary>
        public static Task<string> Fetch(string id, CancellationToken ct = default(CancellationToken))
        {
            string done = Cached(id);
            if (done != null) return Task.FromResult(done);
            return Fetching.GetOrAdd(id, k => Task.Run(async () =>
            {
                try { return await FetchCore(k).ConfigureAwait(false); }
                finally
                {
                    Task<string> t;
                    Fetching.TryRemove(k, out t);
                }
            }));
        }

        /// <summary>
        /// Prueba el método rápido; si en 5 s no terminó (o falló) arranca también el respaldo y
        /// se queda con el primero que lo logre.
        /// </summary>
        private static async Task<string> FetchCore(string id)
        {
            var errors = new List<string>();
            bool toolFirst = ToolFirst || RecentlyFailed(id);
            Task<string> quick = toolFirst ? null : Guard(ViaQuick(id), "rápido", id, errors);
            if (quick != null)
            {
                var first = await Task.WhenAny(quick, Task.Delay(5000)).ConfigureAwait(false);
                if (first == quick && quick.Result != null) return quick.Result;
            }
            var pending = new List<Task<string>> { Guard(ViaTool(id), "respaldo", id, errors) };
            if (quick != null && !quick.IsCompleted) pending.Add(quick);
            while (pending.Count > 0)
            {
                var done = await Task.WhenAny(pending).ConfigureAwait(false);
                pending.Remove(done);
                if (done.Result != null) return done.Result;
            }
            if (toolFirst)
            {
                string q = await Guard(ViaQuick(id), "rápido", id, errors).ConfigureAwait(false);
                if (q != null) return q;
            }
            string cached = Cached(id);
            if (cached != null) return cached;
            string why;
            lock (errors) why = string.Join(" | ", errors);
            throw new IOException("No se pudo obtener el audio (" + why + ")");
        }

        private static async Task<string> Guard(Task<string> work, string label, string id, List<string> errors)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                string f = await work.ConfigureAwait(false);
                Log.Write("Audio " + id + " listo con método " + label + " en " + sw.Elapsed.TotalSeconds.ToString("0.0") + " s");
                return f;
            }
            catch (Exception e)
            {
                lock (errors) errors.Add(label + ": " + e.Message);
                Log.Write("Audio " + id + ": método " + label + " falló en " + sw.Elapsed.TotalSeconds.ToString("0.0") + " s (" + e.GetType().Name + ": " + e.Message + ")");
                return null;
            }
        }

        /// <summary>Deja el archivo listo en caché (si otro método ya lo dejó, se usa ese).</summary>
        private static string Place(string id, string downloaded, string ext)
        {
            string existing = Cached(id);
            if (existing != null)
            {
                try { File.Delete(downloaded); } catch { }
                return existing;
            }
            string target = Path.Combine(CacheDir, id + ext);
            if (File.Exists(target)) File.Delete(target);
            File.Move(downloaded, target);
            return Playable(target);
        }

        private static async Task<string> ViaQuick(string id)
        {
            var info = await Pick(id, CancellationToken.None).ConfigureAwait(false);
            string ext = "." + (info.Container.Name == "mp4" ? (info is AudioOnlyStreamInfo ? "m4a" : "mp4") : info.Container.Name);
            string target = Path.Combine(CacheDir, id + ext);
            string part = target + ".part";
            using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(60)))
            {
                try
                {
                    await Client.Videos.Streams.DownloadAsync(info, part, cancellationToken: cts.Token).ConfigureAwait(false);
                }
                catch
                {
                    Forget(id);
                    MarkQuickFail(id);
                    try { File.Delete(part); } catch { }
                    throw;
                }
            }
            if (new FileInfo(part).Length < 32 * 1024) throw new IOException("Archivo incompleto");
            return Place(id, part, ext);
        }

        // ------------------------------------------------------------ respaldo (herramientas)

        private static string ToolsDir => Paths.Dir("tools");
        private static string YtDlpDir => Path.Combine(ToolsDir, "yt-dlp");
        private static string DenoDir => Path.Combine(ToolsDir, "deno");
        private static string _ytdlp, _deno;

        public static bool ToolReady => FindYtDlp() != null;

        private static string FindYtDlp()
        {
            if (_ytdlp != null && File.Exists(_ytdlp)) return _ytdlp;
            try
            {
                if (Directory.Exists(YtDlpDir))
                    _ytdlp = Directory.GetFiles(YtDlpDir, "yt-dlp.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (_ytdlp == null)
                {
                    string single = Path.Combine(ToolsDir, "yt-dlp.exe");
                    if (File.Exists(single) && new FileInfo(single).Length > 1024 * 1024) _ytdlp = single;
                }
            }
            catch { }
            return _ytdlp;
        }

        private static string FindDeno()
        {
            if (_deno != null && File.Exists(_deno)) return _deno;
            try
            {
                if (Directory.Exists(DenoDir))
                    _deno = Directory.GetFiles(DenoDir, "deno.exe", SearchOption.AllDirectories).FirstOrDefault();
            }
            catch { }
            return _deno;
        }

        /// <summary>Prepara el método de respaldo en segundo plano (una vez; se renueva cada semana).</summary>
        public static void PrepareTools()
        {
            Task.Run(async () =>
            {
                try { await EnsureTools().ConfigureAwait(false); }
                catch (Exception e) { Log.Write("Respaldo: no se pudo preparar (" + e.Message + ")"); }
            });
        }

        private static async Task EnsureTools()
        {
            await ToolGate.WaitAsync().ConfigureAwait(false);
            try
            {
                string stamp = Path.Combine(ToolsDir, "yt-dlp.fecha");
                bool old = !File.Exists(stamp) || File.GetLastWriteTimeUtc(stamp) < DateTime.UtcNow.AddDays(-7);
                bool missing = FindYtDlp() == null || FindDeno() == null;
                if (!missing && !old) return;
                _preparing = true;
                if (FindYtDlp() == null || old)
                {
                    Log.Write("Respaldo: preparando lector de audio…");
                    try
                    {
                        await DownloadZip("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_win.zip", YtDlpDir,
                            "Preparando el reproductor (solo la primera vez) 1/2").ConfigureAwait(false);
                        _ytdlp = null;
                    }
                    catch (Exception e)
                    {
                        Log.Write("Respaldo: zip no disponible (" + e.Message + "), se usa el .exe");
                        var bytes = await DownloadBytes("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe",
                            "Preparando el reproductor (solo la primera vez) 1/2").ConfigureAwait(false);
                        if (bytes.Length < 1024 * 1024) throw new IOException("Herramienta incompleta");
                        string single = Path.Combine(ToolsDir, "yt-dlp.exe");
                        File.WriteAllBytes(single + ".part", bytes);
                        if (File.Exists(single)) File.Delete(single);
                        File.Move(single + ".part", single);
                        _ytdlp = null;
                    }
                    File.WriteAllText(stamp, DateTime.UtcNow.ToString("o"));
                }
                if (FindDeno() == null)
                {
                    Log.Write("Respaldo: preparando JavaScript…");
                    await DownloadZip("https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip", DenoDir,
                        "Preparando el reproductor (solo la primera vez) 2/2").ConfigureAwait(false);
                    _deno = null;
                }
                _toolError = "";
                Log.Write("Respaldo listo (lector: " + (FindYtDlp() != null) + ", JavaScript: " + (FindDeno() != null) + ")");
            }
            catch (Exception e)
            {
                _toolError = e.Message;
                throw;
            }
            finally
            {
                _preparing = false;
                SetStatus("");
                ToolGate.Release();
            }
        }

        /// <summary>Descarga mostrando el avance (las herramientas pesan varios MB).</summary>
        private static async Task<byte[]> DownloadBytes(string url, string label)
        {
            using (var cts = new CancellationTokenSource(TimeSpan.FromMinutes(10)))
            using (var resp = await Net.Client.GetAsync(url, System.Net.Http.HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
            {
                if (!resp.IsSuccessStatusCode) throw new IOException("HTTP " + (int)resp.StatusCode);
                long total = resp.Content.Headers.ContentLength ?? -1;
                using (var stream = await resp.Content.ReadAsStreamAsync(cts.Token).ConfigureAwait(false))
                using (var ms = new MemoryStream(total > 0 ? (int)Math.Min(total, int.MaxValue) : 1 << 20))
                {
                    var buf = new byte[81920];
                    long got = 0;
                    int n;
                    var last = DateTime.MinValue;
                    while ((n = await stream.ReadAsync(buf, 0, buf.Length, cts.Token).ConfigureAwait(false)) > 0)
                    {
                        ms.Write(buf, 0, n);
                        got += n;
                        if ((DateTime.UtcNow - last).TotalMilliseconds > 400)
                        {
                            last = DateTime.UtcNow;
                            SetStatus(label + ": " + (total > 0 ? (got * 100 / total) + " %" : (got / 1048576) + " MB"));
                        }
                    }
                    return ms.ToArray();
                }
            }
        }

        private static async Task DownloadZip(string url, string dir, string label)
        {
            var bytes = await DownloadBytes(url, label).ConfigureAwait(false);
            if (bytes.Length < 100 * 1024) throw new IOException("Descarga incompleta");
            SetStatus(label + ": instalando…");
            string tmp = dir + ".nuevo";
            try { if (Directory.Exists(tmp)) Directory.Delete(tmp, true); } catch { }
            Directory.CreateDirectory(tmp);
            using (var ms = new MemoryStream(bytes))
            using (var zip = new ZipArchive(ms, ZipArchiveMode.Read))
                zip.ExtractToDirectory(tmp, true);
            try { if (Directory.Exists(dir)) Directory.Delete(dir, true); } catch { }
            if (Directory.Exists(dir))
            {
                // Si algo está en uso, se copia encima.
                foreach (var f in Directory.GetFiles(tmp, "*", SearchOption.AllDirectories))
                {
                    string dest = Path.Combine(dir, Path.GetRelativePath(tmp, f));
                    Directory.CreateDirectory(Path.GetDirectoryName(dest));
                    try { File.Copy(f, dest, true); } catch { }
                }
                try { Directory.Delete(tmp, true); } catch { }
            }
            else Directory.Move(tmp, dir);
        }

        /// <summary>
        /// Respaldo: primero el modo ligero (no necesita JavaScript, es rápido); si no alcanza, el
        /// completo con JavaScript (el que aguanta los cambios de la página).
        /// </summary>
        private static async Task<string> ViaTool(string id)
        {
            if (FindYtDlp() == null) await EnsureTools().ConfigureAwait(false);
            string exe = FindYtDlp();
            if (exe == null) throw new IOException("El respaldo aún no está listo");
            await ToolRun.WaitAsync().ConfigureAwait(false);
            try
            {
                try
                {
                    return await RunTool(exe, id, "youtube:player_client=android_vr", false, TimeSpan.FromSeconds(70)).ConfigureAwait(false);
                }
                catch (Exception e)
                {
                    Log.Write("Audio " + id + ": respaldo ligero falló (" + e.Message + ")");
                }
                if (FindDeno() == null)
                {
                    try { await EnsureTools().ConfigureAwait(false); } catch { }
                }
                return await RunTool(exe, id, null, true, TimeSpan.FromMinutes(3)).ConfigureAwait(false);
            }
            finally
            {
                ToolRun.Release();
            }
        }

        private static async Task<string> RunTool(string exe, string id, string extractorArgs, bool js, TimeSpan timeout)
        {
            string dir = CacheDir;
            string pattern = id + ".dl";
            foreach (var old in Directory.GetFiles(dir, pattern + ".*")) { try { File.Delete(old); } catch { } }
            var psi = new ProcessStartInfo(exe)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                WorkingDirectory = Path.GetDirectoryName(exe)
            };
            var args = new List<string>
            {
                "-f", "bestaudio[ext=m4a]/bestaudio[acodec^=mp4a]/best[ext=mp4]/bestaudio/best", "--no-playlist", "--no-warnings",
                "--no-progress", "--force-overwrites", "--no-mtime", "--no-part", "--socket-timeout", "15", "--retries", "3",
                "--cache-dir", Path.Combine(ToolsDir, "cache"),
                "-o", Path.Combine(dir, pattern + ".%(ext)s")
            };
            if (!string.IsNullOrEmpty(extractorArgs)) { args.Add("--extractor-args"); args.Add(extractorArgs); }
            string deno = js ? FindDeno() : null;
            if (deno != null) { args.Add("--js-runtimes"); args.Add("deno:" + deno); }
            args.Add(Yt.WatchUrl(id));
            foreach (string a in args) psi.ArgumentList.Add(a);
            using (var p = Process.Start(psi))
            {
                if (p == null) throw new IOException("No se pudo abrir el lector");
                var err = p.StandardError.ReadToEndAsync();
                var outp = p.StandardOutput.ReadToEndAsync();
                using (var cts = new CancellationTokenSource(timeout))
                {
                    try { await p.WaitForExitAsync(cts.Token).ConfigureAwait(false); }
                    catch (OperationCanceledException)
                    {
                        try { p.Kill(true); } catch { }
                        throw new IOException("El lector tardó demasiado");
                    }
                }
                string e = (await err.ConfigureAwait(false)).Trim();
                if (p.ExitCode != 0) throw new IOException("Código " + p.ExitCode + ": " + (e.Length > 300 ? e.Substring(e.Length - 300) : e));
            }
            var file = Directory.GetFiles(dir, pattern + ".*")
                .Where(f => !f.EndsWith(".part", StringComparison.OrdinalIgnoreCase) && !f.EndsWith(".ytdl", StringComparison.OrdinalIgnoreCase))
                .Select(f => new FileInfo(f)).OrderByDescending(f => f.Length).FirstOrDefault();
            if (file == null || file.Length < 32 * 1024) throw new IOException("Sin archivo");
            return Place(id, file.FullName, file.Extension.ToLowerInvariant());
        }
    }
}
