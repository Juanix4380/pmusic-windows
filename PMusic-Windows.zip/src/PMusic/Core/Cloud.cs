using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace PMusic.Core
{
    public sealed class CloudExpired : Exception
    {
        public CloudExpired() : base("Sesión de nube vencida") { }
    }

    /// <summary>
    /// Sincroniza la biblioteca con la nube de música (la misma del teléfono), con la mezcla de tres
    /// vías de Android: lo que agregas o quitas aquí se respeta junto con lo que cambió en el teléfono.
    /// </summary>
    public static class Cloud
    {
        private const string Api = "https://martineztvxtream.com/api/music/state/";

        public static bool Busy { get; private set; }
        public static DateTime LastSync { get; private set; } = DateTime.MinValue;
        public static string LastError { get; private set; } = "";
        public static event Action StatusChanged;
        /// <summary>Llegaron cambios de otro dispositivo (para restaurar la reproducción).</summary>
        public static event Action<JsonObject> RemotePlayback;
        /// <summary>La cuenta ya no es aceptada: hay que volver a iniciar sesión.</summary>
        public static event Action<string> Rejected;

        private static DispatcherTimer _timer;
        private static bool _again;

        private static string BaseFile => Path.Combine(Account.Folder, "cloud_base.json");

        public static void Schedule(int delayMs)
        {
            if (!Account.CanSync) return;
            if (_timer == null)
            {
                _timer = new DispatcherTimer();
                _timer.Tick += (s, e) => { _timer.Stop(); var t = Run(); };
            }
            _timer.Stop();
            _timer.Interval = TimeSpan.FromMilliseconds(Math.Max(50, delayMs));
            _timer.Start();
        }

        /// <summary>Sincronizar ahora (se llama en el hilo de la interfaz).</summary>
        public static async Task Run()
        {
            if (!Account.CanSync) return;
            if (Busy) { _again = true; return; }
            Busy = true;
            LastError = "";
            StatusChanged?.Invoke();
            try
            {
                await RunOnce(true);
                LastSync = DateTime.Now;
            }
            catch (Exception e)
            {
                LastError = e is IOException || e is TaskCanceledException ? "Sin conexión con la nube" : e.Message;
                Log.Write("Nube: " + e.GetType().Name + " " + e.Message);
            }
            finally
            {
                Busy = false;
                StatusChanged?.Invoke();
                if (_again) { _again = false; Schedule(800); }
            }
        }

        private static async Task RunOnce(bool retry)
        {
            int versionAtStart = Library.Version;
            var localAtStart = Library.ToState();
            var baseState = J.Obj(Paths.ReadOrEmpty(BaseFile)) ?? new JsonObject();
            string token = Account.Token;
            string device = Prefs.S.DeviceId;
            JsonObject merged;
            try
            {
                merged = await Task.Run(() => Synchronize(token, device, baseState, localAtStart));
            }
            catch (CloudExpired)
            {
                if (!retry) throw;
                bool ok = await Account.Refresh();
                if (!ok)
                {
                    Rejected?.Invoke("La cuenta ha vencido o ya no es aceptada. Vuelve a iniciar sesión.");
                    return;
                }
                if (!Account.CanSync) return;
                await RunOnce(false);
                return;
            }
            try { Paths.WriteAtomic(BaseFile, Js.Node(merged)); } catch { }
            JsonObject result = merged;
            // Si se cambió algo aquí mientras se sincronizaba, se vuelve a aplicar encima.
            if (Library.Version != versionAtStart)
            {
                result = Merge(localAtStart, Library.ToState(), merged);
                _again = true;
            }
            var oldPlayback = J.Long(Library.Playback, "updatedAtMs");
            if (Js.Node(result) != Js.Node(Library.ToState())) Library.ApplyCloud(result);
            var pb = J.ObjOf(result, "playback");
            if (pb != null && J.Long(pb, "updatedAtMs") > oldPlayback) RemotePlayback?.Invoke(pb);
        }

        // ------------------------------------------------------------ transporte

        private static JsonObject Synchronize(string token, string deviceId, JsonObject baseState, JsonObject local)
        {
            if (string.IsNullOrEmpty(token)) throw new InvalidOperationException("No hay sesión de nube");
            var get = Call("get", token, new JsonObject());
            var remote = (J.ObjOf(get, "state")?.DeepClone() as JsonObject) ?? new JsonObject();
            long revision = J.Long(get, "revision");
            for (int attempt = 0; attempt < 4; attempt++)
            {
                var merged = Merge(baseState, local, remote);
                if (Js.Node(merged) == Js.Node(remote)) return remote;
                var request = new JsonObject
                {
                    ["revision"] = revision,
                    ["state"] = merged.DeepClone(),
                    ["deviceId"] = deviceId
                };
                var response = Call("save", token, request);
                if (J.Bool(response, "success")) return merged;
                if (!J.Bool(response, "conflict")) throw new Exception("Error de sincronización");
                revision = J.Long(response, "revision", revision);
                remote = (J.ObjOf(response, "state")?.DeepClone() as JsonObject) ?? new JsonObject();
            }
            throw new Exception("La biblioteca cambió durante la sincronización");
        }

        private static JsonObject Call(string action, string token, JsonObject data)
        {
            var headers = new Dictionary<string, string>
            {
                ["Accept"] = "application/json",
                ["Authorization"] = "Bearer " + token,
                ["User-Agent"] = Net.AppAgent
            };
            var res = Net.PostJson(Api + action, Js.Node(data), headers, 15000, true, 1024 * 1024).GetAwaiter().GetResult();
            if (res.Code >= 300 && res.Code < 400) throw new Exception("Redirección de nube no permitida");
            if (res.Code == 401 || res.Code == 403) throw new CloudExpired();
            var json = J.Obj(res.Body);
            if (json == null) throw new IOException("La nube no respondió");
            if (res.Code == 409) return json;
            if (res.Code != 200 || !J.Bool(json, "success"))
                throw new Exception(J.Str(json, "message", "Nube no disponible"));
            return json;
        }

        // ------------------------------------------------------------ mezcla (igual que Android)

        private static JsonArray Arr(JsonObject o, string key) => (o?[key] as JsonArray) ?? new JsonArray();
        private static JsonObject ObjOf(JsonObject o, string key) => (o?[key] as JsonObject) ?? new JsonObject();

        private static string Id(JsonNode song)
        {
            string source = J.Str(song, "sourceUrl");
            return source.Length == 0 ? J.Str(song, "url") : source;
        }

        private static bool Portable(JsonNode song)
        {
            string key = Id(song);
            return key.StartsWith("https://", StringComparison.Ordinal) || key.StartsWith("http://", StringComparison.Ordinal);
        }

        /// <summary>Mapa ordenado id → canción (solo enlaces que sirven en cualquier dispositivo).</summary>
        private static List<KeyValuePair<string, JsonNode>> Songs(JsonArray a)
        {
            var list = new List<KeyValuePair<string, JsonNode>>();
            var seen = new HashSet<string>();
            foreach (var item in a)
                if (item is JsonObject && Portable(item) && seen.Add(Id(item))) list.Add(new KeyValuePair<string, JsonNode>(Id(item), item));
            return list;
        }

        private static JsonArray ToArray(IEnumerable<KeyValuePair<string, JsonNode>> list)
        {
            var a = new JsonArray();
            foreach (var kv in list) a.Add(kv.Value.DeepClone());
            return a;
        }

        private static JsonArray MergeSongs(JsonArray baseA, JsonArray localA, JsonArray remoteA)
        {
            var b = Songs(baseA);
            var l = Songs(localA);
            var r = Songs(remoteA);
            var bKeys = new HashSet<string>(b.Select(x => x.Key));
            var lKeys = new HashSet<string>(l.Select(x => x.Key));
            r.RemoveAll(x => bKeys.Contains(x.Key) && !lKeys.Contains(x.Key));
            var outList = new List<KeyValuePair<string, JsonNode>>();
            var outKeys = new HashSet<string>();
            foreach (var kv in l)
                if (!bKeys.Contains(kv.Key) && outKeys.Add(kv.Key)) outList.Add(kv);
            // putAll: lo remoto reemplaza el valor de la misma llave sin cambiar su lugar.
            foreach (var kv in r)
            {
                int i = outList.FindIndex(x => x.Key == kv.Key);
                if (i >= 0) outList[i] = kv;
                else { outList.Add(kv); outKeys.Add(kv.Key); }
            }
            return ToArray(outList);
        }

        private static List<KeyValuePair<string, JsonObject>> FoldersOf(JsonArray a)
        {
            var list = new List<KeyValuePair<string, JsonObject>>();
            foreach (var f in a)
            {
                var o = f as JsonObject;
                if (o == null) continue;
                string name = J.Str(o, "name").Trim();
                if (name.Length == 0) continue;
                int i = list.FindIndex(x => x.Key == name);
                if (i >= 0) list[i] = new KeyValuePair<string, JsonObject>(name, o);
                else list.Add(new KeyValuePair<string, JsonObject>(name, o));
            }
            return list;
        }

        private static bool SameArrays(JsonArray a, JsonArray b)
        {
            var x = new HashSet<string>(Songs(a).Select(k => k.Key));
            var y = new HashSet<string>(Songs(b).Select(k => k.Key));
            return x.SetEquals(y);
        }

        private static JsonArray MergeFolders(JsonArray baseA, JsonArray localA, JsonArray remoteA)
        {
            var b = FoldersOf(baseA);
            var l = FoldersOf(localA);
            var r = FoldersOf(remoteA);
            JsonObject Get(List<KeyValuePair<string, JsonObject>> m, string name)
            {
                foreach (var kv in m) if (kv.Key == name) return kv.Value;
                return null;
            }
            void Put(string name, JsonObject value)
            {
                int i = r.FindIndex(x => x.Key == name);
                if (i >= 0) r[i] = new KeyValuePair<string, JsonObject>(name, value);
                else r.Add(new KeyValuePair<string, JsonObject>(name, value));
            }
            foreach (var kv in b)
                if (Get(l, kv.Key) == null) r.RemoveAll(x => x.Key == kv.Key);
            foreach (var kv in l)
            {
                string name = kv.Key;
                var old = Get(b, name);
                var server = Get(r, name);
                if (old == null)
                {
                    if (server == null) { Put(name, kv.Value); continue; }
                    Put(name, new JsonObject
                    {
                        ["name"] = name,
                        ["songs"] = MergeSongs(new JsonArray(), Arr(kv.Value, "songs"), Arr(server, "songs"))
                    });
                }
                else
                {
                    var previous = Arr(old, "songs");
                    var updated = Arr(kv.Value, "songs");
                    if (server == null)
                    {
                        // Una carpeta sin cambios aquí no revive una carpeta borrada en otro lado.
                        if (!SameArrays(previous, updated)) Put(name, kv.Value);
                    }
                    else
                    {
                        Put(name, new JsonObject
                        {
                            ["name"] = name,
                            ["songs"] = MergeSongs(previous, updated, Arr(server, "songs"))
                        });
                    }
                }
            }
            var outA = new JsonArray();
            foreach (var kv in r) outA.Add(kv.Value.DeepClone());
            return outA;
        }

        private static List<string> NamesOf(JsonArray a)
        {
            var list = new List<string>();
            foreach (var n in a)
            {
                string s = J.Text(n, "");
                if (s.Length > 0 && !list.Contains(s)) list.Add(s);
            }
            return list;
        }

        private static JsonArray MergeNames(JsonArray baseA, JsonArray localA, JsonArray remoteA)
        {
            var b = NamesOf(baseA);
            var l = NamesOf(localA);
            var r = NamesOf(remoteA);
            foreach (string name in b) if (!l.Contains(name)) r.Remove(name);
            foreach (string name in l) if (!b.Contains(name) && !r.Contains(name)) r.Add(name);
            var outA = new JsonArray();
            foreach (string s in r) outA.Add((JsonNode)s);
            return outA;
        }

        private static JsonArray MergeRecent(JsonArray baseA, JsonArray localA, JsonArray remoteA)
        {
            var b = Songs(baseA);
            var l = Songs(localA);
            var r = Songs(remoteA);
            if (b.Select(x => x.Key).SequenceEqual(l.Select(x => x.Key))) return ToArray(r);
            var outList = new List<KeyValuePair<string, JsonNode>>(l);
            foreach (var kv in r)
            {
                int i = outList.FindIndex(x => x.Key == kv.Key);
                if (i >= 0) outList[i] = kv;
                else outList.Add(kv);
            }
            while (outList.Count > 40) outList.RemoveAt(outList.Count - 1);
            return ToArray(outList);
        }

        public static JsonObject Merge(JsonObject baseS, JsonObject local, JsonObject remote)
        {
            var o = new JsonObject();
            o["favorites"] = MergeSongs(Arr(baseS, "favorites"), Arr(local, "favorites"), Arr(remote, "favorites"));
            o["recent"] = MergeRecent(Arr(baseS, "recent"), Arr(local, "recent"), Arr(remote, "recent"));
            o["folders"] = MergeFolders(Arr(baseS, "folders"), Arr(local, "folders"), Arr(remote, "folders"));
            o["autoDownloadFolders"] = MergeNames(Arr(baseS, "autoDownloadFolders"), Arr(local, "autoDownloadFolders"), Arr(remote, "autoDownloadFolders"));
            o["followedArtists"] = MergeNames(Arr(baseS, "followedArtists"), Arr(local, "followedArtists"), Arr(remote, "followedArtists"));
            o["hiddenSongs"] = MergeNames(Arr(baseS, "hiddenSongs"), Arr(local, "hiddenSongs"), Arr(remote, "hiddenSongs"));
            bool old = J.Bool(baseS, "autoDownloadFavorites");
            bool loc = J.Bool(local, "autoDownloadFavorites");
            o["autoDownloadFavorites"] = loc != old ? loc : J.Bool(remote, "autoDownloadFavorites");
            var lp = ObjOf(local, "playback");
            var rp = ObjOf(remote, "playback");
            o["playback"] = (J.Long(lp, "updatedAtMs") > J.Long(rp, "updatedAtMs") ? lp : rp).DeepClone();
            return o;
        }
    }
}
