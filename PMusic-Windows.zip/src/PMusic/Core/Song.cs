using System;
using System.Collections.Concurrent;
using System.Globalization;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace PMusic.Core
{
    /// <summary>
    /// Una canción, con el mismo formato que la app del teléfono (url, title, artist, image, seconds,
    /// sourceUrl) para que Me gusta, carpetas y recientes se sincronicen tal cual.
    /// </summary>
    public sealed class Song
    {
        public string Url = "";
        public string Title = "";
        public string Artist = "";
        public string Image = "";
        public string SourceUrl = "";
        public long Seconds;

        public Song() { }

        public Song(string url, string title, string artist, string image, long seconds)
        {
            Url = url ?? "";
            Title = title ?? "";
            Artist = artist ?? "";
            Image = image ?? "";
            Seconds = seconds;
        }

        /// <summary>Lo que identifica a la canción entre dispositivos (igual que en Android).</summary>
        public string Identity => string.IsNullOrEmpty(SourceUrl) ? Url : SourceUrl;

        public string VideoId => Yt.IdOf(Identity) ?? Yt.IdOf(Url);

        /// <summary>Llave para comparar: el id del video si lo hay (aunque cambie el formato del enlace).</summary>
        public string Key
        {
            get
            {
                string id = VideoId;
                if (id != null) return "yt:" + id;
                string i = Identity;
                return string.IsNullOrEmpty(i) ? "q:" + Tx.Plain(Title + " " + Artist) : i;
            }
        }

        /// <summary>Solo sabemos título y artista (por ejemplo, de un top): se busca al reproducir.</summary>
        public bool NeedsLookup => string.IsNullOrEmpty(Identity);

        /// <summary>Audio directo (radio o episodio) que no es de los catálogos de música.</summary>
        public bool IsDirect
        {
            get
            {
                string u = Identity;
                return VideoId == null && (u.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                                           u.StartsWith("http://", StringComparison.OrdinalIgnoreCase));
            }
        }

        /// <summary>Archivo del teléfono (no se puede reproducir en la PC).</summary>
        public bool PhoneOnly
        {
            get
            {
                string u = Identity;
                return u.Length > 0 && VideoId == null && !IsDirect;
            }
        }

        public JsonObject ToJson()
        {
            return new JsonObject
            {
                ["url"] = Url ?? "",
                ["title"] = Title ?? "",
                ["artist"] = Artist ?? "",
                ["image"] = Image ?? "",
                ["seconds"] = Seconds,
                ["sourceUrl"] = SourceUrl ?? ""
            };
        }

        /// <summary>Para la nube: solo enlaces que sirven en cualquier dispositivo.</summary>
        public JsonObject Portable()
        {
            var o = ToJson();
            if (!string.IsNullOrEmpty(SourceUrl))
            {
                o["url"] = SourceUrl;
                o["sourceUrl"] = "";
            }
            return o;
        }

        public static Song From(JsonNode n)
        {
            if (!(n is JsonObject)) return null;
            var s = new Song
            {
                Url = J.Str(n, "url"),
                Title = J.Str(n, "title"),
                Artist = J.Str(n, "artist"),
                Image = J.Str(n, "image"),
                Seconds = J.Long(n, "seconds"),
                SourceUrl = J.Str(n, "sourceUrl")
            };
            if (string.IsNullOrEmpty(s.Title)) s.Title = "Canción";
            return s;
        }

        public Song Clone()
        {
            return new Song { Url = Url, Title = Title, Artist = Artist, Image = Image, Seconds = Seconds, SourceUrl = SourceUrl };
        }

        public string Subtitle
        {
            get
            {
                string a = string.IsNullOrWhiteSpace(Artist) ? "" : Artist;
                if (Seconds > 0) a = a.Length == 0 ? Tx.Time(Seconds) : a + " · " + Tx.Time(Seconds);
                return a;
            }
        }
    }

    /// <summary>Enlaces de video: sacar el id de 11 caracteres.</summary>
    public static class Yt
    {
        private static readonly Regex IdRx = new Regex(@"^[A-Za-z0-9_-]{11}$", RegexOptions.Compiled);

        public static string IdOf(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return null;
            if (IdRx.IsMatch(url)) return url;
            Uri u;
            if (!Uri.TryCreate(url.Trim(), UriKind.Absolute, out u)) return null;
            string host = (u.Host ?? "").ToLowerInvariant();
            string id = null;
            if (host == "youtu.be" || host == "www.youtu.be")
                id = u.AbsolutePath.Trim('/');
            else if (host.EndsWith("youtube.com", StringComparison.Ordinal))
            {
                id = QueryValue(u.Query, "v");
                if (id == null)
                {
                    string p = u.AbsolutePath;
                    foreach (string pre in new[] { "/shorts/", "/embed/", "/live/" })
                        if (p.StartsWith(pre, StringComparison.OrdinalIgnoreCase)) id = p.Substring(pre.Length).Trim('/');
                }
            }
            if (id != null && id.Length > 11) id = id.Substring(0, 11);
            return id != null && IdRx.IsMatch(id) ? id : null;
        }

        private static string QueryValue(string query, string key)
        {
            if (string.IsNullOrEmpty(query)) return null;
            foreach (string part in query.TrimStart('?').Split('&'))
            {
                int eq = part.IndexOf('=');
                if (eq <= 0) continue;
                if (part.Substring(0, eq) == key) return Uri.UnescapeDataString(part.Substring(eq + 1));
            }
            return null;
        }

        public static string MusicUrl(string id) => "https://music.youtube.com/watch?v=" + id;
        public static string WatchUrl(string id) => "https://www.youtube.com/watch?v=" + id;
        public static string Thumb(string id) => "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg";

        /// <summary>Las portadas de música llegan chiquitas: se pide la versión grande.</summary>
        public static string BigArt(string url)
        {
            if (string.IsNullOrEmpty(url)) return "";
            if (url.Contains("googleusercontent.com") || url.Contains("ggpht.com"))
                return Regex.Replace(url, @"=w\d+-h\d+[^&?]*$", "=w544-h544-l90-rj");
            return url;
        }

        public static bool IsVideoThumb(string url) => !string.IsNullOrEmpty(url) && url.Contains("i.ytimg.com/");
    }

    /// <summary>Textos: comparar artistas y títulos igual que la app de Android, y formatear tiempos.</summary>
    public static class Tx
    {
        private static readonly ConcurrentDictionary<string, string> ArtistKeys = new ConcurrentDictionary<string, string>();
        private static readonly Regex NonAlnum = new Regex("[^a-z0-9]+", RegexOptions.Compiled);
        private static readonly Regex Spaces = new Regex(@"\s+", RegexOptions.Compiled);
        private static readonly Regex ArtistTail = new Regex("(?: official| oficial| topic| vevo| music| canal| channel)+$", RegexOptions.Compiled);
        private static readonly Regex T1 = new Regex(@"[(\[]\s*(official(?: music)? video|video oficial|audio oficial|official audio|lyric(?:s)?(?: video)?|letra(?:s)?|visualizer|hd|4k|remaster(?:ed)?|karaoke|sped up|slowed|live session)[^)]*[)\]]", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex T2 = new Regex(@"\s*[-|:]\s*(official(?: music)? video|video oficial|official audio|audio oficial|lyrics?|letra(?:s)?|visualizer|hd|4k|remastered?|karaoke)\s*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex T3 = new Regex(@"\s*[(\[]\s*(feat\.?|ft\.?|con )[^)\]]+[)\]]", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex Dash = new Regex(@"\s+[-–—]\s+", RegexOptions.Compiled);

        public static string Plain(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            string d = text.ToLowerInvariant().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(d.Length);
            foreach (char c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            string s = NonAlnum.Replace(sb.ToString(), " ");
            return Spaces.Replace(s, " ").Trim();
        }

        public static string CleanArtist(string artist)
        {
            if (artist == null) return "";
            string v = Regex.Replace(artist.Trim(), @"\s+-\s+topic$", "", RegexOptions.IgnoreCase);
            v = Regex.Replace(v, @"\s+vevo$", "", RegexOptions.IgnoreCase).Trim();
            string l = v.ToLowerInvariant();
            if (v.Length == 0 || l == "unknown" || l == "desconocido" || l == "various artists" || l == "auto-generated by youtube") return "";
            return v;
        }

        public static string ArtistKey(string artist)
        {
            if (artist == null) artist = "";
            return ArtistKeys.GetOrAdd(artist, a =>
            {
                string v = Plain(a);
                v = Spaces.Replace(ArtistTail.Replace(v, ""), " ").Trim();
                if (v == "unknown" || v == "desconocido" || v == "various artists" || v == "varios artistas" ||
                    v == "youtube" || v == "youtube music" || v == "auto generated by youtube") return "";
                return v;
            });
        }

        public static string TitleKey(string title, string artist)
        {
            string v = title ?? "";
            v = T1.Replace(v, " ");
            v = T2.Replace(v, "");
            v = T3.Replace(v, " ");
            string[] parts = Dash.Split(v, 2);
            if (parts.Length == 2)
            {
                string up = ArtistKey(artist), a = Plain(parts[0]), b = Plain(parts[1]);
                if (up.Length > 0 && a.Length > 0 && (up == a || (a.Length >= 5 && up.Contains(a)) || (up.Length >= 5 && a.Contains(up)))) v = parts[1];
                else if (up.Length > 0 && b.Length > 0 && (up == b || (b.Length >= 5 && up.Contains(b)))) v = parts[0];
            }
            return Plain(v);
        }

        /// <summary>Llave de "canción oculta" igual que en el teléfono.</summary>
        public static string SongKey(string title, string artist) => ArtistKey(artist) + "|" + TitleKey(title, artist);

        public static bool SameArtist(string first, string second)
        {
            string a = ArtistKey(first), b = ArtistKey(second);
            if (a.Length < 3 || b.Length < 3) return false;
            if (a == b) return true;
            if (Math.Min(a.Length, b.Length) >= 6 && (a.Contains(b) || b.Contains(a))) return true;
            var stop = new[] { "la", "el", "los", "las", "de", "del", "y", "the", "&", "grupo", "music" };
            var left = new System.Collections.Generic.HashSet<string>(a.Split(' '));
            var right = new System.Collections.Generic.HashSet<string>(b.Split(' '));
            foreach (string s in stop) { left.Remove(s); right.Remove(s); }
            if (left.Count == 0 || right.Count == 0) return false;
            int common = 0;
            foreach (string w in left) if (w.Length > 2 && right.Contains(w)) common++;
            return common >= 2 && common * 2 >= Math.Min(left.Count, right.Count);
        }

        /// <summary>Primer artista de "A & B, C" (para mixes y letras).</summary>
        public static string MainArtist(string artist)
        {
            string a = CleanArtist(artist);
            foreach (string sep in new[] { " & ", ", ", " x ", " X ", " feat", " ft.", " y " })
            {
                int i = a.IndexOf(sep, StringComparison.Ordinal);
                if (i > 1) a = a.Substring(0, i);
            }
            return a.Trim();
        }

        public static string Time(long seconds)
        {
            if (seconds < 0) seconds = 0;
            long h = seconds / 3600, m = seconds % 3600 / 60, s = seconds % 60;
            return h > 0
                ? h.ToString(CultureInfo.InvariantCulture) + ":" + m.ToString("00", CultureInfo.InvariantCulture) + ":" + s.ToString("00", CultureInfo.InvariantCulture)
                : m.ToString(CultureInfo.InvariantCulture) + ":" + s.ToString("00", CultureInfo.InvariantCulture);
        }

        public static long ParseTime(string t)
        {
            if (string.IsNullOrWhiteSpace(t)) return 0;
            long total = 0;
            foreach (string p in t.Trim().Split(':'))
            {
                long v;
                if (!long.TryParse(p.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out v)) return 0;
                total = total * 60 + v;
            }
            return total;
        }

        public static string Count(int n, string one, string many) => n.ToString(CultureInfo.InvariantCulture) + " " + (n == 1 ? one : many);

        public static string Minutes(long seconds)
        {
            long m = seconds / 60;
            if (m < 60) return m.ToString(CultureInfo.InvariantCulture) + " min";
            return (m / 60).ToString(CultureInfo.InvariantCulture) + " h " + (m % 60).ToString(CultureInfo.InvariantCulture) + " min";
        }
    }
}
