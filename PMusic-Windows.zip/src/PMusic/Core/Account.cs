using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace PMusic.Core
{
    public sealed class AuthFailure : Exception
    {
        public readonly bool Unavailable;
        public AuthFailure(string message, bool unavailable) : base(message) { Unavailable = unavailable; }
    }

    /// <summary>Lo que se guarda de la cuenta (contraseña y sesión cifradas con DPAPI).</summary>
    public sealed class AccountData
    {
        public string Source { get; set; } = "";
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string SessionToken { get; set; } = "";
        public string AccountKey { get; set; } = "";
        public long ExpiresAtMs { get; set; }
        public long VerifiedAtMs { get; set; }
    }

    /// <summary>
    /// Inicio de sesión de música (sesión propia: no usa conexiones de TV). Mismo servicio y mismos
    /// mensajes que la app de Android. Nunca se muestra en pantalla a dónde se conecta.
    /// </summary>
    public static class Account
    {
        private const string ApiLogin = "https://martineztvxtream.com/api/music/access";
        private const string AltLogin = "http://latinchannel.tv:8080/player_api.php";

        public static AccountData Current { get; private set; }
        public static string Password { get; private set; } = "";
        public static string Token { get; private set; } = "";
        public static bool Logged => Current != null;
        public static bool CanSync => Current != null && Current.Source == "music-api" && Token.Length > 0 && Current.AccountKey.Length > 0;

        /// <summary>Carpeta de datos de esta cuenta (Me gusta, carpetas…).</summary>
        public static string Folder
        {
            get
            {
                string id = Current == null ? "local" : (Current.AccountKey.Length > 0 ? "api." + Current.AccountKey : "local." + Current.Username.ToLowerInvariant());
                return Paths.Dir("cuentas\\" + Paths.Hash(id).Substring(0, 16));
            }
        }

        private static string File => Paths.File("account.json");

        public static void Load()
        {
            try
            {
                var a = Js.Read<AccountData>(Paths.ReadOrEmpty(File));
                if (a == null || string.IsNullOrEmpty(a.Username)) return;
                Password = Secret.Unprotect(a.Password);
                Token = Secret.Unprotect(a.SessionToken);
                if (a.ExpiresAtMs > 0 && a.ExpiresAtMs <= J.NowMs())
                {
                    Clear();
                    Expired = true;
                    return;
                }
                Current = a;
            }
            catch (Exception e) { Log.Error(e, "Account.Load"); }
        }

        /// <summary>La cuenta guardada venció (para avisar en la pantalla de entrada).</summary>
        public static bool Expired;

        private static void Save()
        {
            if (Current == null) return;
            var copy = new AccountData
            {
                Source = Current.Source,
                Username = Current.Username,
                Password = Secret.Protect(Password),
                SessionToken = Secret.Protect(Token),
                AccountKey = Current.AccountKey,
                ExpiresAtMs = Current.ExpiresAtMs,
                VerifiedAtMs = Current.VerifiedAtMs
            };
            try { Paths.WriteAtomic(File, Js.Write(copy)); }
            catch (Exception e) { Log.Error(e, "Account.Save"); }
        }

        public static void Clear()
        {
            Current = null;
            Password = "";
            Token = "";
            try { if (System.IO.File.Exists(File)) System.IO.File.Delete(File); } catch { }
        }

        /// <summary>Entrar con usuario y contraseña (servicio principal, cifrado).</summary>
        public static async Task Login(string username, string password)
        {
            var r = await ViaApi(username, password).ConfigureAwait(false);
            Password = password;
            Token = r.SessionToken;
            r.SessionToken = "";
            r.Password = "";
            Current = r;
            Save();
        }

        /// <summary>Acceso alternativo sin cifrado: solo después de que la persona lo acepta.</summary>
        public static async Task LoginAlternative(string username, string password)
        {
            var r = await ViaAlternative(username, password).ConfigureAwait(false);
            Password = password;
            Token = "";
            Current = r;
            Save();
        }

        /// <summary>
        /// Vuelve a validar la cuenta guardada (al abrir, cada día o si la nube pide sesión nueva).
        /// false = la cuenta ya no es aceptada y hay que salir. Sin internet se sigue con lo guardado.
        /// </summary>
        public static async Task<bool> Refresh()
        {
            var cur = Current;
            if (cur == null) return false;
            if (string.IsNullOrEmpty(Password)) return true;
            try
            {
                AccountData r = cur.Source == "latin"
                    ? await ViaAlternative(cur.Username, Password).ConfigureAwait(false)
                    : await ViaApi(cur.Username, Password).ConfigureAwait(false);
                if (r.Source == "music-api")
                {
                    Token = r.SessionToken;
                    r.SessionToken = "";
                }
                r.Password = "";
                Current = r;
                Save();
                return true;
            }
            catch (AuthFailure f)
            {
                if (f.Unavailable) return true;
                return false;
            }
            catch
            {
                return true;
            }
        }

        public static bool NeedsRefresh => Current != null &&
            (Current.Source != "music-api" || Token.Length == 0 || Current.AccountKey.Length == 0 ||
             J.NowMs() - Current.VerifiedAtMs >= 86400000L);

        public static bool IsExpiredNow => Current != null && Current.ExpiresAtMs > 0 && Current.ExpiresAtMs <= J.NowMs();

        private static async Task<AccountData> ViaApi(string username, string password)
        {
            var body = new JsonObject
            {
                ["username"] = username,
                ["password"] = password,
                ["deviceId"] = Prefs.S.DeviceId,
                ["deviceName"] = "Pacheco's Music Windows",
                ["deviceType"] = "android-music"
            };
            HttpResult res;
            try
            {
                res = await Net.PostJson(ApiLogin, Js.Node(body),
                    new Dictionary<string, string> { ["Accept"] = "application/json", ["User-Agent"] = Net.AppAgent },
                    20000, true, 65536).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                Log.Write("Login: sin conexión (" + e.GetType().Name + ")");
                throw new AuthFailure("No fue posible conectar con el servicio de inicio de sesión.", true);
            }
            int code = res.Code;
            Log.Write("Login HTTP " + code);
            if (code >= 300 && code < 400) throw new AuthFailure("No fue posible validar la conexión segura.", true);
            var json = J.Obj(res.Body) ?? new JsonObject();
            if (code >= 500) throw new AuthFailure("El servicio está temporalmente indisponible.", true);
            if (code == 404) throw new AuthFailure("Necesitas instalar la API R44 de música en tu servidor.", true);
            if (code == 401 || code == 403 || !J.Bool(json, "success"))
                throw new AuthFailure("La cuenta no fue aceptada. Verifica usuario, contraseña y vigencia.", false);
            if (code != 200) throw new AuthFailure("No pudimos verificar tu cuenta en este momento.", true);
            if (!J.Bool(json, "musicOnly"))
                throw new AuthFailure("Actualiza el servidor de música a R44 para ingresar sin usar conexiones de TV.", true);
            var account = J.ObjOf(json, "account");
            var data = J.ObjOf(json, "data");
            var userInfo = data == null ? null : J.ObjOf(data, "user_info");
            string actualUser = account != null ? J.Str(account, "username", username) : username;
            if (string.IsNullOrEmpty(actualUser)) actualUser = username;
            long expiry = account == null ? 0 : ParseExpiration(account["expirationDate"]);
            if (expiry <= 0 && userInfo != null) expiry = ParseExpiration(userInfo["exp_date"]);
            string key = account == null ? "" : J.Str(account, "accountKey");
            if (key.Length == 0 && account != null && account.ContainsKey("id")) key = "id:" + J.Str(account, "id");
            return new AccountData
            {
                Source = "music-api",
                Username = actualUser,
                SessionToken = J.Str(json, "sessionToken"),
                AccountKey = key,
                ExpiresAtMs = expiry,
                VerifiedAtMs = J.NowMs()
            };
        }

        private static async Task<AccountData> ViaAlternative(string username, string password)
        {
            string url = AltLogin + "?username=" + Uri.EscapeDataString(username) + "&password=" + Uri.EscapeDataString(password);
            HttpResult res;
            try
            {
                res = await Net.Get(url, 13000, new Dictionary<string, string> { ["Accept"] = "application/json" }).ConfigureAwait(false);
            }
            catch
            {
                throw new AuthFailure("No se pudo conectar con el servidor alternativo.", true);
            }
            if (res.Code != 200)
                throw new AuthFailure(res.Code >= 500 ? "El servidor alternativo no responde." : "La cuenta no fue aceptada.", res.Code >= 500);
            var json = J.Obj(res.Body);
            var info = json == null ? null : J.ObjOf(json, "user_info");
            if (info == null) throw new AuthFailure("No se recibieron datos válidos de la cuenta.", true);
            string auth = J.Str(info, "auth");
            if (!(auth == "1" || string.Equals(auth, "true", StringComparison.OrdinalIgnoreCase)))
                throw new AuthFailure("Usuario o contraseña incorrectos.", false);
            string status = J.Str(info, "status", "Active");
            if (!string.Equals(status, "active", StringComparison.OrdinalIgnoreCase))
                throw new AuthFailure("La cuenta no está activa: " + status, false);
            long exp = ParseExpiration(info["exp_date"]);
            if (exp > 0 && exp < J.NowMs()) throw new AuthFailure("La cuenta está vencida.", false);
            return new AccountData { Source = "latin", Username = username, ExpiresAtMs = exp, VerifiedAtMs = J.NowMs() };
        }

        private static long ParseExpiration(JsonNode value)
        {
            string s = J.Text(value, "").Trim();
            if (s.Length == 0 || s == "null") return 0;
            long n;
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out n))
            {
                if (n <= 0) return 0;
                return n < 100000000000L ? n * 1000L : n;
            }
            DateTimeOffset d;
            if (DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out d))
                return d.ToUnixTimeMilliseconds();
            return 0;
        }

        public static string ExpiryText
        {
            get
            {
                if (Current == null || Current.ExpiresAtMs <= 0) return "Sin fecha de vencimiento";
                var d = DateTimeOffset.FromUnixTimeMilliseconds(Current.ExpiresAtMs).ToLocalTime();
                return "Vence el " + d.ToString("d 'de' MMMM 'de' yyyy", new CultureInfo("es-MX"));
            }
        }
    }
}
