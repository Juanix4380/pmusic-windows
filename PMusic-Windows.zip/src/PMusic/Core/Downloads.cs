using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PMusic.Core
{
    public sealed class DownloadEntry
    {
        public string Id { get; set; } = "";
        public string File { get; set; } = "";
        public string Url { get; set; } = "";
        public string Title { get; set; } = "";
        public string Artist { get; set; } = "";
        public string Image { get; set; } = "";
        public long Seconds { get; set; }
        public long At { get; set; }

        public Song ToSong() => new Song(Url, Title, Artist, Image, Seconds);
    }

    /// <summary>
    /// Canciones para escuchar sin internet, en Música\P Music. Se bajan de una en una en segundo plano.
    /// </summary>
    public static class Downloads
    {
        private static readonly List<DownloadEntry> Items = new List<DownloadEntry>();
        private static readonly Dictionary<string, DownloadEntry> ById = new Dictionary<string, DownloadEntry>();
        private static readonly List<Song> Queue = new List<Song>();
        private static readonly object Gate = new object();
        private static bool _running;

        public static event Action Changed;
        public static string ActiveId { get; private set; }
        public static int Pending { get { lock (Gate) return Queue.Count + (ActiveId != null ? 1 : 0); } }

        private static string IndexFile => Paths.File("downloads.json");

        public static void Load()
        {
            try
            {
                var list = Js.Read<List<DownloadEntry>>(Paths.ReadOrEmpty(IndexFile)) ?? new List<DownloadEntry>();
                lock (Gate)
                {
                    Items.Clear();
                    ById.Clear();
                    foreach (var e in list)
                        if (!string.IsNullOrEmpty(e.Id) && System.IO.File.Exists(e.File) && !ById.ContainsKey(e.Id))
                        {
                            Items.Add(e);
                            ById[e.Id] = e;
                        }
                }
            }
            catch (Exception e) { Log.Error(e, "Downloads.Load"); }
        }

        private static void Save()
        {
            List<DownloadEntry> copy;
            lock (Gate) copy = Items.ToList();
            try { Paths.WriteAtomic(IndexFile, Js.Write(copy)); }
            catch (Exception e) { Log.Error(e, "Downloads.Save"); }
        }

        public static List<Song> All()
        {
            lock (Gate) return Items.OrderByDescending(e => e.At).Select(e => e.ToSong()).ToList();
        }

        public static int Count { get { lock (Gate) return Items.Count; } }

        public static string FileFor(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            lock (Gate)
            {
                DownloadEntry e;
                if (ById.TryGetValue(id, out e) && System.IO.File.Exists(e.File)) return e.File;
            }
            return null;
        }

        public static bool Has(Song s)
        {
            string id = s?.VideoId;
            if (id == null) return false;
            lock (Gate) return ById.ContainsKey(id);
        }

        public static bool IsQueued(Song s)
        {
            string id = s?.VideoId;
            if (id == null) return false;
            lock (Gate) return id == ActiveId || Queue.Any(q => q.VideoId == id);
        }

        public static long Bytes()
        {
            lock (Gate)
            {
                long t = 0;
                foreach (var e in Items)
                    try { t += new FileInfo(e.File).Length; } catch { }
                return t;
            }
        }

        public static void Enqueue(Song s)
        {
            if (s == null || s.VideoId == null || Has(s)) return;
            lock (Gate)
            {
                string id = s.VideoId;
                if (id == ActiveId || Queue.Any(q => q.VideoId == id)) return;
                Queue.Add(s.Clone());
                if (_running) { Notify(); return; }
                _running = true;
            }
            Notify();
            Task.Run(() => Work());
        }

        public static void EnqueueAll(IEnumerable<Song> songs)
        {
            foreach (var s in songs) Enqueue(s);
        }

        public static void Remove(Song s)
        {
            string id = s?.VideoId;
            if (id == null) return;
            DownloadEntry e;
            lock (Gate)
            {
                Queue.RemoveAll(q => q.VideoId == id);
                if (!ById.TryGetValue(id, out e)) e = null;
                else
                {
                    ById.Remove(id);
                    Items.Remove(e);
                }
            }
            if (e != null) { try { System.IO.File.Delete(e.File); } catch { } }
            Save();
            Notify();
        }

        public static void CancelPending()
        {
            lock (Gate) Queue.Clear();
            Notify();
        }

        private static void Notify() => UiThread.Post(() => Changed?.Invoke());

        private static async Task Work()
        {
            while (true)
            {
                Song next;
                lock (Gate)
                {
                    if (Queue.Count == 0) { _running = false; ActiveId = null; break; }
                    next = Queue[0];
                    Queue.RemoveAt(0);
                    ActiveId = next.VideoId;
                }
                Notify();
                try { await One(next).ConfigureAwait(false); }
                catch (Exception e) { Log.Write("Descarga falló: " + e.Message); }
            }
            Notify();
        }

        private static async Task One(Song s)
        {
            string id = s.VideoId;
            if (id == null || FileFor(id) != null) return;
            string cached = await Streams.Fetch(id).ConfigureAwait(false);
            string ext = Path.GetExtension(cached);
            string name = Paths.SafeName((string.IsNullOrWhiteSpace(s.Artist) ? "" : Tx.MainArtist(s.Artist) + " - ") + s.Title);
            string dir = Paths.Downloads();
            string target = Path.Combine(dir, name + ext);
            for (int i = 2; System.IO.File.Exists(target); i++) target = Path.Combine(dir, name + " (" + i + ")" + ext);
            System.IO.File.Copy(cached, target);
            var entry = new DownloadEntry
            {
                Id = id,
                File = target,
                Url = s.Identity,
                Title = s.Title,
                Artist = s.Artist,
                Image = s.Image,
                Seconds = s.Seconds,
                At = J.NowMs()
            };
            lock (Gate)
            {
                ById[id] = entry;
                Items.Add(entry);
            }
            Save();
        }
    }
}
