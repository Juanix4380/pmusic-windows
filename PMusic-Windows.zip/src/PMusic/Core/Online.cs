using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PMusic.Core
{
    public sealed class LyricLine
    {
        public double At;
        public string Text = "";
    }

    public sealed class Lyrics
    {
        public List<LyricLine> Lines = new List<LyricLine>();
        public string Plain = "";
        public bool Synced => Lines.Count > 0;
        public bool Empty => Lines.Count == 0 && string.IsNullOrWhiteSpace(Plain);
    }

    /// <summary>Letras sincronizadas (las mismas que en el teléfono), con caché.</summary>
    public static class LyricsService
    {
        private const string Base = "https://lrclib.net/api/";
        private const string Agent = "PMusic/1.0 (Windows; reproductor personal)";
        private static readonly Regex Brackets = new Regex(@"[\(\[][^\)\]]*[\)\]]", RegexOptions.Compiled);
        private static readonly Regex Feat = new Regex(@"\s+(ft\.?|feat\.?|featuring|con)\s+.*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex LineRx = new Regex(@"^\s*((\[\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?\])+)(.*)$", RegexOptions.Compiled);
        private static readonly Regex StampRx = new Regex(@"\[(\d{1,3}):(\d{1,2}(?:[.:]\d{1,3})?)\]", RegexOptions.Compiled);
        private static readonly ConcurrentDictionary<string, Lyrics> Memo = new ConcurrentDictionary<string, Lyrics>();
        private const int MaxGap = 7;

        public static async Task<Lyrics> Find(Song s)
        {
            if (s == null) return new Lyrics();
            string key = s.Key;
            Lyrics hit;
            if (Memo.TryGetValue(key, out hit)) return hit;
            string file = Path.Combine(Paths.Dir("letras"), Paths.Hash(key) + ".lrc");
            string raw = Paths.ReadOrEmpty(file);
            if (raw.Length == 0)
            {
                raw = await Task.Run(() => Fetch(s.Title, s.Artist, s.Seconds)).ConfigureAwait(false) ?? "";
                if (raw.Length > 0) { try { File.WriteAllText(file, raw); } catch { } }
            }
            var ly = Parse(raw);
            if (!ly.Empty || raw.Length > 0) Memo[key] = ly;
            return ly;
        }

        private static async Task<string> Get(string url)
        {
            try
            {
                var r = await Net.Get(url, 12000, new Dictionary<string, string> { ["User-Agent"] = Agent, ["Accept"] = "application/json" }).ConfigureAwait(false);
                return r.Code == 200 ? r.Body : null;
            }
            catch { return null; }
        }

        private static async Task<string> Fetch(string rawTitle, string rawArtist, long seconds)
        {
            string artist = CleanArtist(rawArtist);
            string title = CleanTitle(rawTitle, artist);
            if (title.Length == 0) return null;
            string plain = null;
            if (seconds > 0 && artist.Length > 0)
            {
                string exact = await Get(Base + "get?track_name=" + Uri.EscapeDataString(title) + "&artist_name=" + Uri.EscapeDataString(artist) + "&duration=" + seconds).ConfigureAwait(false);
                var o = J.Obj(exact);
                if (o != null)
                {
                    string synced = J.Str(o, "syncedLyrics");
                    if (Usable(synced)) return synced;
                    plain = J.Str(o, "plainLyrics");
                }
            }
            string first = await Get(Base + "search?track_name=" + Uri.EscapeDataString(title) + (artist.Length == 0 ? "" : "&artist_name=" + Uri.EscapeDataString(artist))).ConfigureAwait(false);
            string best = Pick(first, seconds, ref plain);
            if (best != null) return best;
            string second = await Get(Base + "search?q=" + Uri.EscapeDataString((title + " " + artist).Trim())).ConfigureAwait(false);
            best = Pick(second, seconds, ref plain);
            if (best != null) return best;
            return string.IsNullOrWhiteSpace(plain) || plain == "null" ? null : plain;
        }

        private static string Pick(string json, long seconds, ref string plain)
        {
            var arr = J.Parse(json) as JsonArray;
            if (arr == null) return null;
            string chosen = null;
            long bestGap = long.MaxValue;
            foreach (var item in arr)
            {
                if (!(item is JsonObject)) continue;
                string synced = J.Str(item, "syncedLyrics");
                double dv;
                double.TryParse(J.Text(item["duration"], "0"), NumberStyles.Float, CultureInfo.InvariantCulture, out dv);
                long duration = (long)Math.Round(dv);
                long gap = seconds > 0 && duration > 0 ? Math.Abs(duration - seconds) : MaxGap - 1;
                if (seconds > 0 && duration > 0 && gap > MaxGap) continue;
                if (!Usable(synced))
                {
                    string p = J.Str(item, "plainLyrics");
                    if (plain == null && !string.IsNullOrWhiteSpace(p) && p != "null") plain = p;
                    continue;
                }
                if (gap < bestGap) { bestGap = gap; chosen = synced; }
            }
            return chosen;
        }

        private static bool Usable(string synced) => !string.IsNullOrEmpty(synced) && synced != "null" && synced.Contains("[");

        private static string CleanArtist(string raw)
        {
            if (raw == null) return "";
            string a = Regex.Replace(raw, @"\s*-\s*topic$", "", RegexOptions.IgnoreCase);
            a = Regex.Replace(a, "vevo$", "", RegexOptions.IgnoreCase);
            a = Regex.Replace(a, @"\s*(oficial|official)$", "", RegexOptions.IgnoreCase).Trim();
            foreach (string cut in new[] { ",", "&", " x ", " X ", " ft", " feat" })
            {
                int at = a.IndexOf(cut, StringComparison.Ordinal);
                if (at > 0) a = a.Substring(0, at).Trim();
            }
            return a;
        }

        private static string CleanTitle(string raw, string artist)
        {
            if (raw == null) return "";
            string t = Brackets.Replace(raw, " ");
            int dash = t.IndexOf(" - ", StringComparison.Ordinal);
            if (dash > 0)
            {
                string left = t.Substring(0, dash).Trim().ToLowerInvariant();
                string right = t.Substring(dash + 3).Trim();
                string who = (artist ?? "").ToLowerInvariant();
                if (who.Length > 0 && (left.Contains(who) || who.Contains(left))) t = right;
            }
            t = Feat.Replace(t, "");
            t = Regex.Replace(t, @"\b(video oficial|official video|official audio|audio oficial|lyric video|letra|lyrics|visualizer|hd|4k)\b", "", RegexOptions.IgnoreCase);
            t = Regex.Replace(t.Replace('|', ' ').Replace('•', ' '), @"\s+", " ").Trim();
            return Regex.Replace(t, @"^[-–:\s]+|[-–:\s]+$", "");
        }

        public static Lyrics Parse(string raw)
        {
            var ly = new Lyrics();
            if (string.IsNullOrWhiteSpace(raw)) return ly;
            if (!raw.Contains("["))
            {
                ly.Plain = raw.Trim();
                return ly;
            }
            foreach (string line in raw.Replace("\r", "").Split('\n'))
            {
                var m = LineRx.Match(line);
                if (!m.Success) continue;
                string text = m.Groups[3].Value.Trim();
                foreach (Match st in StampRx.Matches(m.Groups[1].Value))
                {
                    double min = double.Parse(st.Groups[1].Value, CultureInfo.InvariantCulture);
                    double sec = double.Parse(st.Groups[2].Value.Replace(':', '.'), CultureInfo.InvariantCulture);
                    ly.Lines.Add(new LyricLine { At = min * 60 + sec, Text = text });
                }
            }
            ly.Lines = ly.Lines.OrderBy(l => l.At).ToList();
            if (ly.Lines.Count == 0) ly.Plain = Regex.Replace(raw, @"\[[^\]]*\]", "").Trim();
            return ly;
        }
    }

    /// <summary>Portadas cuadradas grandes cuando la canción solo trae la imagen del video.</summary>
    public static class Artwork
    {
        private static readonly ConcurrentDictionary<string, string> Memo = new ConcurrentDictionary<string, string>();

        public static async Task<string> Better(Song s)
        {
            if (s == null) return "";
            if (!string.IsNullOrEmpty(s.Image) && !Yt.IsVideoThumb(s.Image)) return s.Image;
            string key = s.Key;
            string hit;
            if (Memo.TryGetValue(key, out hit)) return hit.Length > 0 ? hit : s.Image;
            string found = "";
            try
            {
                string artist = Tx.MainArtist(s.Artist);
                string term = (Tx.TitleKey(s.Title, s.Artist) + " " + Tx.Plain(artist)).Trim();
                string json = await Net.GetString("https://itunes.apple.com/search?media=music&entity=song&limit=6&country=mx&term=" + Uri.EscapeDataString(term), 9000).ConfigureAwait(false);
                var results = J.ArrOf(J.Obj(json), "results");
                if (results != null)
                    foreach (var r in results)
                    {
                        if (!Tx.SameArtist(J.Str(r, "artistName"), artist) && !Tx.Plain(J.Str(r, "artistName")).Contains(Tx.Plain(artist))) continue;
                        string art = J.Str(r, "artworkUrl100");
                        if (art.Length == 0) continue;
                        found = art.Replace("100x100bb", "600x600bb");
                        break;
                    }
            }
            catch { }
            Memo[key] = found;
            return found.Length > 0 ? found : s.Image;
        }
    }

    /// <summary>Lo más escuchado en México (se actualiza solo).</summary>
    public static class Charts
    {
        private static List<Song> _top;
        private static DateTime _at;

        public static async Task<List<Song>> TopMexico()
        {
            if (_top != null && DateTime.UtcNow - _at < TimeSpan.FromHours(6)) return _top;
            var list = new List<Song>();
            try
            {
                string json = await Net.GetString("https://rss.applemarketingtools.com/api/v2/mx/music/most-played/50/songs.json", 12000).ConfigureAwait(false);
                var items = J.ArrOf(J.ObjOf(J.Obj(json), "feed"), "results");
                if (items != null)
                    foreach (var it in items)
                    {
                        string name = J.Str(it, "name");
                        if (name.Length == 0) continue;
                        string art = J.Str(it, "artworkUrl100").Replace("100x100bb", "600x600bb");
                        list.Add(new Song("", name, J.Str(it, "artistName"), art, 0));
                    }
            }
            catch (Exception e) { Log.Write("Top México: " + e.Message); }
            if (list.Count > 0) { _top = list; _at = DateTime.UtcNow; }
            return list;
        }
    }
}
