using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace PMusic.Core
{
    /// <summary>Ajustes de la app en esta PC (no viajan a la nube).</summary>
    public sealed class Settings
    {
        public double Volume { get; set; } = 0.85;
        public bool Autoplay { get; set; } = true;
        public bool Shuffle { get; set; }
        public int Repeat { get; set; }
        public string DeviceId { get; set; } = "";
        public List<string> Searches { get; set; } = new List<string>();
        public Dictionary<string, int> ArtistPlays { get; set; } = new Dictionary<string, int>();
        public int LibraryTab { get; set; }
        public int FavoritesSort { get; set; }
        public bool AskedPowerButton { get; set; }
    }

    public static class Prefs
    {
        public static Settings S = new Settings();
        private static string File => Paths.File("settings.json");
        private static System.Windows.Threading.DispatcherTimer _timer;

        public static void Load()
        {
            try
            {
                var s = Js.Read<Settings>(Paths.ReadOrEmpty(File));
                if (s != null) S = s;
            }
            catch (Exception e) { Log.Error(e, "Prefs.Load"); }
            if (S.Searches == null) S.Searches = new List<string>();
            if (S.ArtistPlays == null) S.ArtistPlays = new Dictionary<string, int>();
            if (S.Volume <= 0 || S.Volume > 1) S.Volume = 0.85;
            if (!IsDeviceId(S.DeviceId)) { S.DeviceId = NewDeviceId(); SaveNow(); }
        }

        public static void Save()
        {
            if (_timer == null)
            {
                _timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                _timer.Tick += (s, e) => { _timer.Stop(); SaveNow(); };
            }
            _timer.Stop();
            _timer.Start();
        }

        public static void SaveNow()
        {
            try { Paths.WriteAtomic(File, Js.Write(S)); }
            catch (Exception e) { Log.Error(e, "Prefs.Save"); }
        }

        public static void AddSearch(string q)
        {
            q = (q ?? "").Trim();
            if (q.Length == 0) return;
            S.Searches.RemoveAll(x => string.Equals(x, q, StringComparison.OrdinalIgnoreCase));
            S.Searches.Insert(0, q);
            while (S.Searches.Count > 12) S.Searches.RemoveAt(S.Searches.Count - 1);
            Save();
        }

        public static void CountArtist(string artist)
        {
            string a = Tx.MainArtist(artist);
            if (a.Length < 2) return;
            int n;
            S.ArtistPlays.TryGetValue(a, out n);
            S.ArtistPlays[a] = n + 1;
            if (S.ArtistPlays.Count > 400)
            {
                var keys = new List<string>(S.ArtistPlays.Keys);
                keys.Sort((x, y) => S.ArtistPlays[x].CompareTo(S.ArtistPlays[y]));
                for (int i = 0; i < 100; i++) S.ArtistPlays.Remove(keys[i]);
            }
            Save();
        }

        private static bool IsDeviceId(string s)
        {
            if (string.IsNullOrEmpty(s) || s.Length != 16) return false;
            foreach (char c in s) if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
            return true;
        }

        /// <summary>Id fijo de esta PC (no cambia al reinstalar la app).</summary>
        private static string NewDeviceId()
        {
            string guid = "";
            try
            {
                using (var hk = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                using (var k = hk.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                    guid = k?.GetValue("MachineGuid") as string ?? "";
            }
            catch { }
            if (string.IsNullOrEmpty(guid)) guid = Guid.NewGuid().ToString("N");
            byte[] h = SHA256.HashData(Encoding.UTF8.GetBytes("pmusic|" + guid));
            var sb = new StringBuilder(16);
            for (int i = 0; i < 8; i++) sb.Append(h[i].ToString("x2", System.Globalization.CultureInfo.InvariantCulture));
            return sb.ToString();
        }
    }
}
