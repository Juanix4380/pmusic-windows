using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json.Nodes;
using System.Windows.Threading;

namespace PMusic.Core
{
    public sealed class Folder
    {
        public string Name = "";
        public List<Song> Songs = new List<Song>();
    }

    /// <summary>
    /// Me gusta, recientes, carpetas, artistas seguidos y canciones ocultas de la cuenta. Se guarda en
    /// la PC y se sincroniza con la nube con el mismo formato que la app del teléfono.
    /// </summary>
    public static class Library
    {
        public static readonly List<Song> Favorites = new List<Song>();
        public static readonly List<Song> Recent = new List<Song>();
        public static readonly List<Folder> Folders = new List<Folder>();
        public static readonly List<string> FollowedArtists = new List<string>();
        public static readonly List<string> HiddenSongs = new List<string>();
        public static readonly List<string> AutoFolders = new List<string>();
        public static bool AutoFavorites;
        public static JsonObject Playback = new JsonObject();

        /// <summary>Sube con cada cambio hecho en esta PC.</summary>
        public static int Version { get; private set; }
        public static event Action Changed;

        private static readonly HashSet<string> FavKeys = new HashSet<string>();
        private static string _file;
        private static DispatcherTimer _save;

        public static void Load()
        {
            _file = Path.Combine(Account.Folder, "library.json");
            var st = J.Obj(Paths.ReadOrEmpty(_file)) ?? new JsonObject();
            FromState(st);
            Version++;
            Changed?.Invoke();
        }

        // ------------------------------------------------------------ estado (formato de la nube)

        public static JsonObject ToState()
        {
            var fav = new JsonArray();
            foreach (var s in Favorites) fav.Add(s.Portable());
            var rec = new JsonArray();
            foreach (var s in Recent) rec.Add(s.Portable());
            var folders = new JsonArray();
            foreach (var f in Folders)
            {
                var songs = new JsonArray();
                foreach (var s in f.Songs) songs.Add(s.Portable());
                folders.Add(new JsonObject { ["name"] = f.Name, ["songs"] = songs });
            }
            return new JsonObject
            {
                ["favorites"] = fav,
                ["recent"] = rec,
                ["folders"] = folders,
                ["autoDownloadFolders"] = Names(AutoFolders),
                ["followedArtists"] = Names(FollowedArtists),
                ["hiddenSongs"] = Names(HiddenSongs),
                ["autoDownloadFavorites"] = AutoFavorites,
                ["playback"] = Playback == null ? new JsonObject() : Playback.DeepClone()
            };
        }

        private static JsonArray Names(List<string> list)
        {
            var a = new JsonArray();
            foreach (string s in list) a.Add((JsonNode)s);
            return a;
        }

        public static void FromState(JsonObject st)
        {
            Favorites.Clear();
            Recent.Clear();
            Folders.Clear();
            FollowedArtists.Clear();
            HiddenSongs.Clear();
            AutoFolders.Clear();
            ReadSongs(J.ArrOf(st, "favorites"), Favorites);
            ReadSongs(J.ArrOf(st, "recent"), Recent);
            var folders = J.ArrOf(st, "folders");
            if (folders != null)
                foreach (var f in folders)
                {
                    string name = J.Str(f, "name").Trim();
                    if (name.Length == 0 || Folders.Any(x => x.Name == name)) continue;
                    var folder = new Folder { Name = name };
                    ReadSongs(J.ArrOf(f, "songs"), folder.Songs);
                    Folders.Add(folder);
                }
            ReadNames(J.ArrOf(st, "followedArtists"), FollowedArtists);
            ReadNames(J.ArrOf(st, "hiddenSongs"), HiddenSongs);
            ReadNames(J.ArrOf(st, "autoDownloadFolders"), AutoFolders);
            AutoFavorites = J.Bool(st, "autoDownloadFavorites");
            Playback = (J.ObjOf(st, "playback")?.DeepClone() as JsonObject) ?? new JsonObject();
            RebuildKeys();
        }

        private static void ReadSongs(JsonArray a, List<Song> into)
        {
            if (a == null) return;
            var seen = new HashSet<string>();
            foreach (var n in a)
            {
                var s = Song.From(n);
                if (s == null || s.NeedsLookup) continue;
                if (seen.Add(s.Key)) into.Add(s);
            }
        }

        private static void ReadNames(JsonArray a, List<string> into)
        {
            if (a == null) return;
            foreach (var n in a)
            {
                string s = J.Text(n, "");
                if (s.Length > 0 && !into.Contains(s)) into.Add(s);
            }
        }

        private static void RebuildKeys()
        {
            FavKeys.Clear();
            foreach (var s in Favorites) FavKeys.Add(s.Key);
        }

        /// <summary>Guardar (en 1.5 s), avisar a las pantallas y mandar a la nube.</summary>
        public static void Touch(bool cloud = true)
        {
            Version++;
            RebuildKeys();
            if (_save == null)
            {
                _save = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1500) };
                _save.Tick += (s, e) => { _save.Stop(); SaveNow(); };
            }
            _save.Stop();
            _save.Start();
            Changed?.Invoke();
            if (cloud) Cloud.Schedule(1500);
        }

        public static void SaveNow()
        {
            if (_file == null) return;
            try { Paths.WriteAtomic(_file, Js.Node(ToState())); }
            catch (Exception e) { Log.Error(e, "Library.Save"); }
        }

        /// <summary>Canción y posición actuales (sin redibujar pantallas).</summary>
        public static void SetPlayback(JsonObject pb, bool cloud)
        {
            Playback = pb ?? new JsonObject();
            Version++;
            if (_save == null)
            {
                _save = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1500) };
                _save.Tick += (s, e) => { _save.Stop(); SaveNow(); };
            }
            _save.Stop();
            _save.Start();
            if (cloud) Cloud.Schedule(5000);
        }

        /// <summary>Lo que llega de la nube reemplaza lo local (ya viene mezclado).</summary>
        public static void ApplyCloud(JsonObject st)
        {
            FromState(st);
            Version++;
            SaveNow();
            Changed?.Invoke();
        }

        // ------------------------------------------------------------ Me gusta

        public static bool IsFavorite(Song s) => s != null && FavKeys.Contains(s.Key);

        public static bool ToggleFavorite(Song s)
        {
            if (s == null || s.NeedsLookup) return false;
            string key = s.Key;
            int i = Favorites.FindIndex(x => x.Key == key);
            bool now;
            if (i >= 0) { Favorites.RemoveAt(i); now = false; }
            else
            {
                var copy = s.Clone();
                if (!string.IsNullOrEmpty(copy.SourceUrl)) { copy.Url = copy.SourceUrl; copy.SourceUrl = ""; }
                Favorites.Insert(0, copy);
                now = true;
            }
            Touch();
            if (now && AutoFavorites) Downloads.Enqueue(s);
            return now;
        }

        // ------------------------------------------------------------ recientes

        public static void AddRecent(Song s)
        {
            if (s == null || s.NeedsLookup || s.PhoneOnly) return;
            string key = s.Key;
            Recent.RemoveAll(x => x.Key == key);
            var copy = s.Clone();
            if (!string.IsNullOrEmpty(copy.SourceUrl)) { copy.Url = copy.SourceUrl; copy.SourceUrl = ""; }
            Recent.Insert(0, copy);
            while (Recent.Count > 40) Recent.RemoveAt(Recent.Count - 1);
            Touch();
        }

        public static void ClearRecent()
        {
            Recent.Clear();
            Touch();
        }

        // ------------------------------------------------------------ carpetas

        public static Folder FolderNamed(string name) => Folders.FirstOrDefault(f => f.Name == name);

        public static Folder CreateFolder(string name)
        {
            name = (name ?? "").Trim();
            if (name.Length == 0) return null;
            var f = FolderNamed(name);
            if (f != null) return f;
            f = new Folder { Name = name };
            Folders.Insert(0, f);
            Touch();
            return f;
        }

        public static bool RenameFolder(Folder f, string name)
        {
            name = (name ?? "").Trim();
            if (f == null || name.Length == 0 || FolderNamed(name) != null) return false;
            int auto = AutoFolders.IndexOf(f.Name);
            if (auto >= 0) AutoFolders[auto] = name;
            f.Name = name;
            Touch();
            return true;
        }

        public static void DeleteFolder(Folder f)
        {
            if (f == null) return;
            Folders.Remove(f);
            AutoFolders.Remove(f.Name);
            Touch();
        }

        /// <summary>false = ya estaba en la carpeta.</summary>
        public static bool AddToFolder(Folder f, Song s)
        {
            if (f == null || s == null || s.NeedsLookup) return false;
            string key = s.Key;
            if (f.Songs.Any(x => x.Key == key)) return false;
            var copy = s.Clone();
            if (!string.IsNullOrEmpty(copy.SourceUrl)) { copy.Url = copy.SourceUrl; copy.SourceUrl = ""; }
            f.Songs.Add(copy);
            Touch();
            if (AutoFolders.Contains(f.Name)) Downloads.Enqueue(s);
            return true;
        }

        public static void RemoveFromFolder(Folder f, Song s)
        {
            if (f == null || s == null) return;
            string key = s.Key;
            f.Songs.RemoveAll(x => x.Key == key);
            Touch();
        }

        public static void SetAutoFolder(Folder f, bool on)
        {
            if (f == null) return;
            AutoFolders.Remove(f.Name);
            if (on)
            {
                AutoFolders.Add(f.Name);
                foreach (var s in f.Songs) Downloads.Enqueue(s);
            }
            Touch();
        }

        public static void SetAutoFavorites(bool on)
        {
            AutoFavorites = on;
            if (on) foreach (var s in Favorites) Downloads.Enqueue(s);
            Touch();
        }

        // ------------------------------------------------------------ artistas y ocultas

        public static bool IsFollowing(string artist) => FollowedArtists.Any(a => Tx.SameArtist(a, artist));

        public static bool ToggleFollow(string artist)
        {
            string clean = Tx.CleanArtist(artist);
            if (clean.Length == 0) return false;
            string old = FollowedArtists.FirstOrDefault(a => Tx.SameArtist(a, clean));
            if (old != null) FollowedArtists.Remove(old);
            else FollowedArtists.Add(clean);
            while (FollowedArtists.Count > 450) FollowedArtists.RemoveAt(0);
            Touch();
            return old == null;
        }

        public static bool IsHidden(Song s)
        {
            if (s == null || HiddenSongs.Count == 0) return false;
            return HiddenSongs.Contains(Tx.SongKey(s.Title, s.Artist));
        }

        public static void Hide(Song s)
        {
            if (s == null) return;
            string k = Tx.SongKey(s.Title, s.Artist);
            if (!HiddenSongs.Contains(k)) HiddenSongs.Add(k);
            while (HiddenSongs.Count > 450) HiddenSongs.RemoveAt(0);
            Touch();
        }

        public static void Unhide(string key)
        {
            HiddenSongs.Remove(key);
            Touch();
        }

        // ------------------------------------------------------------ gustos

        /// <summary>Artistas que más escuchas (Me gusta, recientes y reproducciones).</summary>
        public static List<string> TopArtists(int max)
        {
            var score = new Dictionary<string, int>();
            var display = new Dictionary<string, string>();
            void Add(string artist, int pts)
            {
                string a = Tx.MainArtist(artist);
                string k = Tx.ArtistKey(a);
                if (k.Length < 2) return;
                int v;
                score.TryGetValue(k, out v);
                score[k] = v + pts;
                if (!display.ContainsKey(k)) display[k] = a;
            }
            foreach (var s in Favorites.Take(200)) Add(s.Artist, 8);
            int i = 0;
            foreach (var s in Recent) Add(s.Artist, Math.Max(1, 10 - i++ / 4));
            foreach (var kv in Prefs.S.ArtistPlays) Add(kv.Key, Math.Min(30, kv.Value * 2));
            foreach (var a in FollowedArtists) Add(a, 25);
            return score.OrderByDescending(kv => kv.Value).Take(max).Select(kv => display[kv.Key]).ToList();
        }
    }
}
