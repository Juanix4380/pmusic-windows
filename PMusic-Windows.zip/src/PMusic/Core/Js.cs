using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace PMusic.Core
{
    /// <summary>
    /// JSON propio para guardar archivos y enviar datos a Cloud. No usa el escritor ni el serializador
    /// de System.Text.Json (en el .exe único fallaban al cargar). Para leer usa JsonDocument.
    /// </summary>
    public static class Js
    {
        private sealed class Prop
        {
            public string Name;
            public PropertyInfo Info;
            public Type Type;
        }

        private static readonly ConcurrentDictionary<Type, Prop[]> Props = new ConcurrentDictionary<Type, Prop[]>();
        private static readonly ConcurrentDictionary<Type, Dictionary<string, Prop>> Maps = new ConcurrentDictionary<Type, Dictionary<string, Prop>>();
        private static readonly JsonDocumentOptions DocOptions = new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip };

        private static Prop[] PropsOf(Type t)
        {
            return Props.GetOrAdd(t, k => k.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.GetIndexParameters().Length == 0 && p.GetGetMethod() != null && p.GetSetMethod() != null &&
                            p.GetCustomAttribute<JsonIgnoreAttribute>() == null)
                .Select(p => new Prop { Name = p.Name, Info = p, Type = p.PropertyType })
                .ToArray());
        }

        private static Dictionary<string, Prop> MapOf(Type t)
        {
            return Maps.GetOrAdd(t, k =>
            {
                var d = new Dictionary<string, Prop>(StringComparer.OrdinalIgnoreCase);
                foreach (var p in PropsOf(k)) d[p.Name] = p;
                return d;
            });
        }

        // ================================================================== escribir

        /// <summary>Objeto, lista o diccionario a texto JSON.</summary>
        public static string Write(object value)
        {
            var sb = new StringBuilder(1024);
            Value(sb, value, 0);
            return sb.ToString();
        }

        /// <summary>Nodo JSON (JsonObject, JsonArray, JsonValue) a texto.</summary>
        public static string Node(JsonNode node)
        {
            var sb = new StringBuilder(256);
            NodeTo(sb, node, 0);
            return sb.ToString();
        }

        private static void Value(StringBuilder sb, object v, int depth)
        {
            if (v == null || depth > 48) { sb.Append("null"); return; }
            if (v is string s) { Str(sb, s); return; }
            if (v is bool b) { sb.Append(b ? "true" : "false"); return; }
            if (v is int i) { sb.Append(i.ToString(CultureInfo.InvariantCulture)); return; }
            if (v is long l) { sb.Append(l.ToString(CultureInfo.InvariantCulture)); return; }
            if (v is double d) { Num(sb, d); return; }
            if (v is float f) { Num(sb, f); return; }
            if (v is decimal m) { sb.Append(m.ToString(CultureInfo.InvariantCulture)); return; }
            if (v is JsonNode n) { NodeTo(sb, n, depth); return; }
            if (v is JsonElement e) { Element(sb, e, depth); return; }
            if (v is Enum) { sb.Append(Convert.ToInt64(v, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture)); return; }
            if (v is char c) { Str(sb, c.ToString()); return; }
            Type t = v.GetType();
            if (t.IsPrimitive)
            {
                sb.Append(Convert.ToString(v, CultureInfo.InvariantCulture));
                return;
            }
            if (v is IDictionary dict)
            {
                sb.Append('{');
                bool first = true;
                foreach (DictionaryEntry kv in dict)
                {
                    if (!first) sb.Append(',');
                    first = false;
                    Str(sb, Convert.ToString(kv.Key, CultureInfo.InvariantCulture));
                    sb.Append(':');
                    Value(sb, kv.Value, depth + 1);
                }
                sb.Append('}');
                return;
            }
            if (v is IEnumerable list)
            {
                sb.Append('[');
                bool first = true;
                foreach (object x in list)
                {
                    if (!first) sb.Append(',');
                    first = false;
                    Value(sb, x, depth + 1);
                }
                sb.Append(']');
                return;
            }
            sb.Append('{');
            bool firstProp = true;
            foreach (var p in PropsOf(t))
            {
                object pv;
                try { pv = p.Info.GetValue(v); }
                catch { continue; }
                if (!firstProp) sb.Append(',');
                firstProp = false;
                Str(sb, p.Name);
                sb.Append(':');
                Value(sb, pv, depth + 1);
            }
            sb.Append('}');
        }

        private static void NodeTo(StringBuilder sb, JsonNode n, int depth)
        {
            if (n == null || depth > 48) { sb.Append("null"); return; }
            if (n is JsonObject o)
            {
                sb.Append('{');
                bool first = true;
                foreach (var kv in o)
                {
                    if (!first) sb.Append(',');
                    first = false;
                    Str(sb, kv.Key);
                    sb.Append(':');
                    NodeTo(sb, kv.Value, depth + 1);
                }
                sb.Append('}');
                return;
            }
            if (n is JsonArray a)
            {
                sb.Append('[');
                for (int i = 0; i < a.Count; i++)
                {
                    if (i > 0) sb.Append(',');
                    NodeTo(sb, a[i], depth + 1);
                }
                sb.Append(']');
                return;
            }
            var jv = n as JsonValue;
            if (jv == null) { sb.Append("null"); return; }
            JsonElement el;
            if (jv.TryGetValue(out el)) { Element(sb, el, depth); return; }
            string s;
            if (jv.TryGetValue(out s)) { Str(sb, s); return; }
            bool b;
            if (jv.TryGetValue(out b)) { sb.Append(b ? "true" : "false"); return; }
            long l;
            if (jv.TryGetValue(out l)) { sb.Append(l.ToString(CultureInfo.InvariantCulture)); return; }
            int i32;
            if (jv.TryGetValue(out i32)) { sb.Append(i32.ToString(CultureInfo.InvariantCulture)); return; }
            double d;
            if (jv.TryGetValue(out d)) { Num(sb, d); return; }
            float f;
            if (jv.TryGetValue(out f)) { Num(sb, f); return; }
            decimal m;
            if (jv.TryGetValue(out m)) { sb.Append(m.ToString(CultureInfo.InvariantCulture)); return; }
            object raw;
            if (jv.TryGetValue(out raw)) { Value(sb, raw, depth + 1); return; }
            sb.Append("null");
        }

        private static void Element(StringBuilder sb, JsonElement e, int depth)
        {
            switch (e.ValueKind)
            {
                case JsonValueKind.Object:
                {
                    sb.Append('{');
                    bool first = true;
                    foreach (var p in e.EnumerateObject())
                    {
                        if (!first) sb.Append(',');
                        first = false;
                        Str(sb, p.Name);
                        sb.Append(':');
                        if (depth > 48) sb.Append("null");
                        else Element(sb, p.Value, depth + 1);
                    }
                    sb.Append('}');
                    return;
                }
                case JsonValueKind.Array:
                {
                    sb.Append('[');
                    bool first = true;
                    foreach (var x in e.EnumerateArray())
                    {
                        if (!first) sb.Append(',');
                        first = false;
                        if (depth > 48) sb.Append("null");
                        else Element(sb, x, depth + 1);
                    }
                    sb.Append(']');
                    return;
                }
                case JsonValueKind.String: Str(sb, e.GetString()); return;
                case JsonValueKind.Number: sb.Append(e.GetRawText()); return;
                case JsonValueKind.True: sb.Append("true"); return;
                case JsonValueKind.False: sb.Append("false"); return;
                default: sb.Append("null"); return;
            }
        }

        private static void Num(StringBuilder sb, double d)
        {
            if (double.IsNaN(d) || double.IsInfinity(d)) { sb.Append('0'); return; }
            sb.Append(d.ToString("R", CultureInfo.InvariantCulture));
        }

        private static void Num(StringBuilder sb, float f)
        {
            if (float.IsNaN(f) || float.IsInfinity(f)) { sb.Append('0'); return; }
            sb.Append(f.ToString("R", CultureInfo.InvariantCulture));
        }

        private static void Str(StringBuilder sb, string s)
        {
            sb.Append('"');
            if (s != null)
            {
                foreach (char ch in s)
                {
                    switch (ch)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        case '\b': sb.Append("\\b"); break;
                        case '\f': sb.Append("\\f"); break;
                        default:
                            if (ch < ' ' || ch == '\u2028' || ch == '\u2029')
                                sb.Append("\\u").Append(((int)ch).ToString("x4", CultureInfo.InvariantCulture));
                            else
                                sb.Append(ch);
                            break;
                    }
                }
            }
            sb.Append('"');
        }

        // ================================================================== leer

        /// <summary>Texto JSON a un objeto (propiedades públicas con get/set, listas y diccionarios).</summary>
        public static T Read<T>(string json) where T : class
        {
            if (string.IsNullOrWhiteSpace(json)) return null;
            using (var doc = JsonDocument.Parse(json, DocOptions))
                return To(doc.RootElement, typeof(T), 0) as T;
        }

        public static T Read<T>(Stream stream) where T : class
        {
            using (var doc = JsonDocument.Parse(stream, DocOptions))
                return To(doc.RootElement, typeof(T), 0) as T;
        }

        private static object To(JsonElement e, Type t, int depth)
        {
            Type under = Nullable.GetUnderlyingType(t);
            if (under != null) return e.ValueKind == JsonValueKind.Null || e.ValueKind == JsonValueKind.Undefined ? null : To(e, under, depth);
            if (t == typeof(string)) return Text(e);
            if (t == typeof(int)) return (int)Long(e);
            if (t == typeof(long)) return Long(e);
            if (t == typeof(double)) return Dbl(e);
            if (t == typeof(float)) return (float)Dbl(e);
            if (t == typeof(decimal)) return (decimal)Dbl(e);
            if (t == typeof(bool)) return Bool(e);
            if (t == typeof(short)) return (short)Long(e);
            if (t == typeof(byte)) return (byte)Long(e);
            if (t.IsEnum) return Enum.ToObject(t, Long(e));
            if (t == typeof(JsonElement) || t == typeof(object)) return e.Clone();
            if (depth > 48) return t.IsValueType ? Activator.CreateInstance(t) : null;

            if (t.IsArray)
            {
                Type et = t.GetElementType();
                if (e.ValueKind != JsonValueKind.Array) return Array.CreateInstance(et, 0);
                var arr = Array.CreateInstance(et, e.GetArrayLength());
                int i = 0;
                foreach (var x in e.EnumerateArray()) arr.SetValue(To(x, et, depth + 1), i++);
                return arr;
            }

            if (t.IsGenericType)
            {
                Type g = t.GetGenericTypeDefinition();
                if (g == typeof(List<>) || g == typeof(IList<>) || g == typeof(IEnumerable<>) ||
                    g == typeof(ICollection<>) || g == typeof(IReadOnlyList<>) || g == typeof(IReadOnlyCollection<>))
                {
                    Type et = t.GetGenericArguments()[0];
                    var list = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(et));
                    if (e.ValueKind == JsonValueKind.Array)
                        foreach (var x in e.EnumerateArray()) list.Add(To(x, et, depth + 1));
                    return list;
                }
                if (g == typeof(Dictionary<,>) || g == typeof(IDictionary<,>) || g == typeof(IReadOnlyDictionary<,>))
                {
                    Type[] args = t.GetGenericArguments();
                    var dict = (IDictionary)Activator.CreateInstance(typeof(Dictionary<,>).MakeGenericType(args));
                    if (e.ValueKind == JsonValueKind.Object)
                    {
                        foreach (var p in e.EnumerateObject())
                        {
                            object key;
                            try { key = args[0] == typeof(string) ? p.Name : Convert.ChangeType(p.Name, args[0], CultureInfo.InvariantCulture); }
                            catch { continue; }
                            dict[key] = To(p.Value, args[1], depth + 1);
                        }
                    }
                    return dict;
                }
            }

            if (e.ValueKind != JsonValueKind.Object) return t.IsValueType ? Activator.CreateInstance(t) : null;
            object o = Activator.CreateInstance(t);
            var map = MapOf(t);
            foreach (var p in e.EnumerateObject())
            {
                Prop pr;
                if (!map.TryGetValue(p.Name, out pr)) continue;
                object val = To(p.Value, pr.Type, depth + 1);
                if (val == null && !pr.Type.IsValueType && p.Value.ValueKind == JsonValueKind.Null) continue;
                if (val == null && pr.Type == typeof(string)) continue;
                try { pr.Info.SetValue(o, val); }
                catch { }
            }
            return o;
        }

        private static string Text(JsonElement e)
        {
            switch (e.ValueKind)
            {
                case JsonValueKind.String: return e.GetString();
                case JsonValueKind.Number: return e.GetRawText();
                case JsonValueKind.True: return "true";
                case JsonValueKind.False: return "false";
                default: return null;
            }
        }

        private static long Long(JsonElement e)
        {
            switch (e.ValueKind)
            {
                case JsonValueKind.Number:
                    long l;
                    if (e.TryGetInt64(out l)) return l;
                    double d;
                    return e.TryGetDouble(out d) && !double.IsNaN(d) && !double.IsInfinity(d) ? (long)d : 0;
                case JsonValueKind.String:
                    return J.ToLong(e.GetString());
                case JsonValueKind.True: return 1;
                default: return 0;
            }
        }

        private static double Dbl(JsonElement e)
        {
            switch (e.ValueKind)
            {
                case JsonValueKind.Number:
                    double d;
                    return e.TryGetDouble(out d) ? d : 0;
                case JsonValueKind.String:
                    double p;
                    return double.TryParse((e.GetString() ?? "").Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out p) ? p : 0;
                case JsonValueKind.True: return 1;
                default: return 0;
            }
        }

        private static bool Bool(JsonElement e)
        {
            switch (e.ValueKind)
            {
                case JsonValueKind.True: return true;
                case JsonValueKind.Number:
                    double d;
                    return e.TryGetDouble(out d) && d != 0;
                case JsonValueKind.String:
                    string s = (e.GetString() ?? "").Trim().ToLowerInvariant();
                    return s == "true" || s == "1" || s == "yes";
                default: return false;
            }
        }
    }
}
