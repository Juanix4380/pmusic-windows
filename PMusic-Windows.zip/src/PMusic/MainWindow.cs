using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using PMusic.Core;
using PMusic.Player;
using PMusic.UI;
using PMusic.UI.Pages;
using Page = PMusic.UI.Page;

namespace PMusic
{
    /// <summary>
    /// La única ventana: pantallas adentro, barra de "sonando ahora", pestañas de abajo (como en el
    /// teléfono), el reproductor grande encima y las ventanitas de opciones.
    /// </summary>
    public sealed class MainWindow : Window
    {
        public static MainWindow Instance { get; private set; }

        private readonly Grid _root = new Grid();
        private readonly Grid _shell = new Grid();
        private readonly Grid _pageHost = new Grid();
        private readonly MiniPlayer _mini;
        private readonly Border _nav;
        private readonly Dictionary<string, KeyValuePair<TextBlock, TextBlock>> _navItems = new Dictionary<string, KeyValuePair<TextBlock, TextBlock>>();
        private readonly Dictionary<string, Border> _navPills = new Dictionary<string, Border>();
        private readonly List<Page> _stack = new List<Page>();
        private readonly Dictionary<string, Page> _roots = new Dictionary<string, Page>();
        private DispatcherTimer _periodic;
        private DateTime _lastAccountCheck = DateTime.Now;
        private bool _started, _fullscreen;
        private WindowState _prevState = WindowState.Maximized;

        public NowPlaying Player { get; }
        public Grid SheetLayer { get; } = new Grid { Visibility = Visibility.Collapsed };
        public Border ToastHost { get; }
        public bool ShellVisible { get; private set; }
        public Page Current => _stack.Count == 0 ? null : _stack[_stack.Count - 1];

        public MainWindow()
        {
            Instance = this;
            Title = "P Music";
            Width = 1280;
            Height = 820;
            MinWidth = 520;
            MinHeight = 520;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = Ui.B("Bg");
            Foreground = Ui.B("Text");
            FontFamily = Ui.Font;
            UseLayoutRounding = true;
            SnapsToDevicePixels = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Ideal);
            Stylus.SetIsPressAndHoldEnabled(this, true);
            try { Icon = BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico", UriKind.Absolute)); } catch { }
            WindowState = WindowState.Maximized;

            _shell.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            _shell.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _shell.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _shell.Children.Add(_pageHost);
            _mini = new MiniPlayer();
            Grid.SetRow(_mini, 1);
            _shell.Children.Add(_mini);
            _nav = BuildNav();
            Grid.SetRow(_nav, 2);
            _shell.Children.Add(_nav);
            _root.Children.Add(_shell);

            Player = new NowPlaying();
            _root.Children.Add(Player);

            ToastHost = new Border
            {
                Background = Ui.B("Gold"),
                CornerRadius = new CornerRadius(22),
                Padding = new Thickness(20, 11, 20, 11),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(20, 0, 20, 170),
                IsHitTestVisible = false,
                Visibility = Visibility.Collapsed
            };
            _root.Children.Add(SheetLayer);
            _root.Children.Add(ToastHost);
            Content = _root;

            SourceInitialized += (s, e) => DarkTitle(new WindowInteropHelper(this).Handle);
            Loaded += (s, e) => Start();
            PreviewKeyDown += OnKey;
            PreviewMouseDown += (s, e) =>
            {
                if (e.ChangedButton == MouseButton.XButton1) { Back(); e.Handled = true; }
            };
            Closing += (s, e) =>
            {
                Engine.Shutdown();
                Library.SaveNow();
                Prefs.SaveNow();
            };
            Engine.Message += Toast.Show;
            Engine.StateChanged += () =>
            {
                if (Engine.Playing) MaybeAskPowerButton();
            };
            Cloud.Rejected += msg => Logout(msg);
            Cloud.RemotePlayback += pb => Engine.Restore(pb, true);
            SetShell(false);
        }

        // ------------------------------------------------------------ inicio

        private void Start()
        {
            if (_started) return;
            _started = true;
            if (!Account.Logged)
            {
                ShowLogin(Account.Expired ? "La cuenta ha vencido. Vuelve a iniciar sesión." : null);
                return;
            }
            EnterApp();
        }

        private void ShowLogin(string message)
        {
            SetShell(false);
            _stack.Clear();
            Show(new LoginPage(message), null);
        }

        /// <summary>Ya hay cuenta: carga la biblioteca y abre el Inicio.</summary>
        public void EnterApp()
        {
            Library.Load();
            Engine.Restore(Library.Playback, false);
            _roots.Clear();
            SetShell(true);
            SwitchTab("home");
            Cloud.Schedule(400);
            if (Account.NeedsRefresh) CheckAccount();
            if (_periodic == null)
            {
                _periodic = UiThread.Every(10 * 60 * 1000, () =>
                {
                    if (!Account.Logged) return;
                    if (Account.IsExpiredNow) { Logout("La cuenta ha vencido. Vuelve a iniciar sesión."); return; }
                    Cloud.Schedule(0);
                    if ((DateTime.Now - _lastAccountCheck).TotalHours >= 12) CheckAccount();
                });
            }
        }

        private async void CheckAccount()
        {
            _lastAccountCheck = DateTime.Now;
            bool ok = await Account.Refresh();
            if (!Account.Logged) return;
            if (!ok) { Logout("La cuenta ha vencido o ya no es aceptada. Vuelve a iniciar sesión."); return; }
            Cloud.Schedule(500);
        }

        /// <summary>Cerrar sesión (la persona lo pide o la cuenta ya no es aceptada).</summary>
        public void Logout(string message)
        {
            if (!Account.Logged) return;
            Engine.SavePlayback(false);
            Library.SaveNow();
            Engine.Stop();
            Player.Close();
            Sheet.Close();
            Account.Clear();
            _roots.Clear();
            ShowLogin(message);
        }

        private void SetShell(bool on)
        {
            ShellVisible = on;
            _nav.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
            _mini.Paint();
        }

        // ------------------------------------------------------------ pestañas de abajo

        private Border BuildNav()
        {
            var g = new Grid { Height = 66 };
            var items = new[]
            {
                new[] { "home", G.Home, "Inicio" },
                new[] { "search", G.Search, "Buscar" },
                new[] { "liked", G.Heart, "Me gusta" },
                new[] { "library", G.Library, "Biblioteca" }
            };
            for (int i = 0; i < items.Length; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                string tab = items[i][0];
                var cell = new Grid { Background = Brushes.Transparent, Cursor = Cursors.Hand };
                var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                var pill = new Border { Width = 60, Height = 32, CornerRadius = new CornerRadius(16), HorizontalAlignment = HorizontalAlignment.Center };
                var icon = Ui.Icon(items[i][1], 21, "Muted2");
                pill.Child = icon;
                sp.Children.Add(pill);
                var label = Ui.T(items[i][2], 11.5, "Muted2", true);
                label.HorizontalAlignment = HorizontalAlignment.Center;
                label.Margin = new Thickness(0, 3, 0, 0);
                sp.Children.Add(label);
                cell.Children.Add(sp);
                Grid.SetColumn(cell, i);
                g.Children.Add(cell);
                _navItems[tab] = new KeyValuePair<TextBlock, TextBlock>(icon, label);
                _navPills[tab] = pill;
                Ui.Tap(cell, () => SwitchTab(tab));
            }
            return new Border
            {
                Background = Ui.B("Bg2"),
                BorderBrush = Ui.Hex("#1FFFFFFF"),
                BorderThickness = new Thickness(0, 1, 0, 0),
                Child = g
            };
        }

        private void PaintNav(string tab)
        {
            foreach (var kv in _navItems)
            {
                bool on = kv.Key == tab;
                kv.Value.Key.Foreground = Ui.B(on ? "Gold" : "Muted2");
                kv.Value.Value.Foreground = Ui.B(on ? "Text" : "Muted2");
                _navPills[kv.Key].Background = on ? Ui.B("GoldSoft") : Brushes.Transparent;
                if (kv.Key == "liked") kv.Value.Key.Text = on ? G.HeartFill : G.Heart;
            }
        }

        private Page Root(string tab)
        {
            Page p;
            if (_roots.TryGetValue(tab, out p)) return p;
            switch (tab)
            {
                case "search": p = new SearchPage(); break;
                case "liked": p = new LikedPage(); break;
                case "library": p = new LibraryPage(); break;
                default: p = new HomePage(); break;
            }
            _roots[tab] = p;
            return p;
        }

        public void SwitchTab(string tab)
        {
            if (Player.IsOpen) Player.Close();
            var root = Root(tab);
            if (_stack.Count == 1 && ReferenceEquals(_stack[0], root))
            {
                if (root is SearchPage sp) sp.FocusBox();
                return;
            }
            var old = Current;
            _stack.Clear();
            _stack.Add(root);
            Show(root, old);
        }

        // ------------------------------------------------------------ navegación

        public void Go(Page p)
        {
            if (Player.IsOpen) Player.Close();
            var old = Current;
            _stack.Add(p);
            Show(p, old);
        }

        public void Back()
        {
            if (Sheet.IsOpen) { Sheet.Close(); return; }
            if (Player.Back()) return;
            var cur = Current;
            if (cur != null && cur.OnBack()) return;
            if (_stack.Count > 1)
            {
                _stack.RemoveAt(_stack.Count - 1);
                Show(Current, cur);
                return;
            }
            if (ShellVisible && !(cur is HomePage)) SwitchTab("home");
        }

        private void Show(Page p, Page old)
        {
            if (old != null && !ReferenceEquals(old, p)) old.OnHide();
            _pageHost.Children.Clear();
            _pageHost.Children.Add(p);
            p.OnShow();
            string tab = p.Tab;
            if (tab == null)
                for (int i = _stack.Count - 1; i >= 0 && tab == null; i--) tab = _stack[i].Tab;
            PaintNav(tab ?? "");
        }

        public void OpenSearch(string query)
        {
            SwitchTab("search");
            var sp = Root("search") as SearchPage;
            if (sp == null) return;
            if (string.IsNullOrWhiteSpace(query)) sp.FocusBox();
            else sp.Run(query);
        }

        public void OpenPlayer()
        {
            if (Engine.Current == null) return;
            Sheet.Close();
            Player.Open();
        }

        // ------------------------------------------------------------ teclado

        private void OnKey(object sender, KeyEventArgs e)
        {
            bool typing = Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is PasswordBox;
            if (e.Key == Key.Escape || e.Key == Key.BrowserBack)
            {
                if (typing && Current is SearchPage && !Sheet.IsOpen) { Keyboard.ClearFocus(); e.Handled = true; return; }
                Back();
                e.Handled = true;
                return;
            }
            if (e.Key == Key.F11) { ToggleFullscreen(); e.Handled = true; return; }
            if (typing || !ShellVisible) return;
            if (e.Key == Key.Space) { Engine.Toggle(); e.Handled = true; }
            else if (e.Key == Key.F && Keyboard.Modifiers == ModifierKeys.Control) { OpenSearch(""); e.Handled = true; }
            else if (e.Key == Key.Right && Keyboard.Modifiers == ModifierKeys.Control) { Engine.Next(false); e.Handled = true; }
            else if (e.Key == Key.Left && Keyboard.Modifiers == ModifierKeys.Control) { Engine.Previous(); e.Handled = true; }
            else if (e.Key == Key.L && Keyboard.Modifiers == ModifierKeys.Control)
            {
                var s = Engine.Current;
                if (s != null) { bool now = Library.ToggleFavorite(s); Toast.Show(now ? "Agregada a Me gusta" : "Quitada de Me gusta"); }
                e.Handled = true;
            }
        }

        private void ToggleFullscreen()
        {
            if (!_fullscreen)
            {
                _prevState = WindowState;
                WindowStyle = WindowStyle.None;
                WindowState = WindowState.Normal;
                WindowState = WindowState.Maximized;
                _fullscreen = true;
            }
            else
            {
                WindowStyle = WindowStyle.SingleBorderWindow;
                WindowState = _prevState == WindowState.Minimized ? WindowState.Maximized : _prevState;
                _fullscreen = false;
            }
        }

        public void BringToFront()
        {
            if (WindowState == WindowState.Minimized) WindowState = _prevState == WindowState.Minimized ? WindowState.Maximized : _prevState;
            Activate();
            Topmost = true;
            Topmost = false;
            Focus();
        }

        // ------------------------------------------------------------ pantalla bloqueada (una vez)

        private bool _askedThisRun;

        private async void MaybeAskPowerButton()
        {
            if (_askedThisRun || Prefs.S.AskedPowerButton) return;
            _askedThisRun = true;
            bool already = await Task.Run(() => PowerSettings.ButtonTurnsOffDisplay());
            if (already) { Prefs.S.AskedPowerButton = true; Prefs.Save(); return; }
            await Task.Delay(2500);
            if (Sheet.IsOpen) return;
            Prefs.S.AskedPowerButton = true;
            Prefs.Save();
            Sheet.Confirm("¿Que la música siga con la pantalla apagada?",
                "La música ya sigue sonando con la tablet bloqueada y verás los controles en la pantalla de bloqueo. " +
                "Si además quieres que al presionar el botón de encendido solo se apague la pantalla (como en el teléfono) y la música no se detenga, actívalo aquí. " +
                "Lo puedes cambiar cuando quieras en Tu cuenta y ajustes.",
                "Sí, activarlo", async () =>
                {
                    bool ok = await Task.Run(() => PowerSettings.SetButtonDisplayOff(true));
                    Toast.Show(ok ? "Listo: el botón de encendido solo apaga la pantalla" : "Windows no permitió el cambio. Hazlo en Configuración › Sistema › Energía.");
                }, "Ahora no");
        }

        // ------------------------------------------------------------ barra de título oscura

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        private static void DarkTitle(IntPtr hwnd)
        {
            try
            {
                int on = 1;
                DwmSetWindowAttribute(hwnd, 20, ref on, 4);
                int color = 0x000D0908;
                DwmSetWindowAttribute(hwnd, 35, ref color, 4);
            }
            catch { }
        }
    }
}
