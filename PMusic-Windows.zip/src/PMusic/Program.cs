using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using PMusic.Core;
using PMusic.Player;
using PMusic.UI;

namespace PMusic
{
    public static class Program
    {
        private const string MutexName = "PMusic.Windows.Single";
        private const string ShowEventName = "PMusic.Windows.Show";

        [STAThread]
        public static void Main(string[] args)
        {
            // Una sola ventana: si ya está abierta, se trae al frente en vez de abrir otra.
            bool first;
            using (var mutex = new Mutex(true, MutexName, out first))
            {
                if (!first)
                {
                    try
                    {
                        using (var ev = EventWaitHandle.OpenExisting(ShowEventName)) ev.Set();
                    }
                    catch { }
                    return;
                }
                using (var show = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName))
                {
                    Log.Init();
                    Log.Write("Windows " + Environment.OSVersion.Version + " · .NET " + Environment.Version);
                    AppDomain.CurrentDomain.UnhandledException += (s, e) => Log.Error(e.ExceptionObject as Exception, "AppDomain");
                    System.Threading.Tasks.TaskScheduler.UnobservedTaskException += (s, e) =>
                    {
                        Log.Error(e.Exception, "Task");
                        e.SetObserved();
                    };
                    Prefs.Load();
                    Account.Load();
                    Downloads.Load();
                    Streams.PruneCache();

                    var app = new App();
                    app.InitializeComponent();
                    app.DispatcherUnhandledException += OnUiError;
                    Engine.Init();
                    var win = new MainWindow();
                    var waiter = new Thread(() =>
                    {
                        try
                        {
                            while (show.WaitOne())
                                win.Dispatcher.BeginInvoke(new Action(win.BringToFront));
                        }
                        catch { }
                    })
                    { IsBackground = true, Name = "single-instance" };
                    waiter.Start();
                    app.Run(win);
                    Prefs.SaveNow();
                }
            }
        }

        private static void OnUiError(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            Log.Error(e.Exception, "UI");
            e.Handled = true;
            try { Toast.Show("Algo falló, pero la música sigue. Intenta otra vez."); } catch { }
        }
    }
}
