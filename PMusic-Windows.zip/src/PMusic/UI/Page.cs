using System;
using System.Windows;
using System.Windows.Controls;

namespace PMusic.UI
{
    /// <summary>Una pantalla de la app (todas viven dentro de la misma ventana).</summary>
    public abstract class Page : Grid
    {
        protected MainWindow Main => MainWindow.Instance;

        /// <summary>Pestaña de abajo que se marca ("home", "search", "liked", "library").</summary>
        public virtual string Tab => null;

        public virtual void OnShow() { }
        public virtual void OnHide() { }
        public virtual bool OnBack() => false;

        /// <summary>Barra de arriba de las pantallas internas: regresar + título.</summary>
        protected FrameworkElement TopBar(string title, params UIElement[] right)
        {
            var g = new Grid { Margin = new Thickness(16, 14, 20, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var back = Ui.IconBtn(G.Back, () => Main.Back(), "Regresar");
            g.Children.Add(back);
            var t = Ui.T(title ?? "", 18, "Text", true);
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(8, 0, 0, 0);
            Grid.SetColumn(t, 1);
            g.Children.Add(t);
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var r in right) if (r != null) sp.Children.Add(r);
            Grid.SetColumn(sp, 2);
            g.Children.Add(sp);
            return g;
        }

        /// <summary>Margen lateral según el ancho (tablet vertical u horizontal).</summary>
        protected static double Side(double width) => width >= 1100 ? 36 : width >= 800 ? 28 : 18;
    }
}
