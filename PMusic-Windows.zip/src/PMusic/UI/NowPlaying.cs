using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PMusic.Core;
using PMusic.Player;
using PMusic.UI.Pages;

namespace PMusic.UI
{
    /// <summary>
    /// El reproductor grande: portada, controles, barra de avance, volumen, cola y letra sincronizada.
    /// En la tablet horizontal la cola/letra va a la derecha; en vertical se abre encima.
    /// </summary>
    public sealed class NowPlaying : Grid
    {
        private readonly Border _ambient;
        private readonly Border _art;
        private readonly TextBlock _title, _artist, _source, _pos, _dur, _sleep;
        private readonly Button _heart, _play, _shuffle, _repeat, _mute, _download, _tabQueue, _tabLyrics, _sideToggleQueue, _sideToggleLyrics;
        private readonly Slider _seek, _volume;
        private readonly Grid _main;
        private readonly Grid _left;
        private readonly Border _side;
        private readonly StackPanel _queueList, _lyricsList;
        private readonly ScrollViewer _queueScroll, _lyricsScroll;
        private readonly StackPanel _info;
        private readonly Button _sideClose;
        private readonly DispatcherTimer _timer;
        private bool _dragging, _setting, _wide = true, _sideOpen;
        private int _tab;
        private string _shownKey, _lyricsKey, _artUrl;
        private Lyrics _lyrics;
        private int _lyricIndex = -1;
        private DateTime _userScroll = DateTime.MinValue;
        private readonly TranslateTransform _slide = new TranslateTransform();

        public bool IsOpen { get; private set; }

        public NowPlaying()
        {
            Visibility = Visibility.Collapsed;
            Background = Ui.B("Bg");
            RenderTransform = _slide;
            ClipToBounds = true;

            _ambient = new Border { Opacity = 0.6 };
            Children.Add(_ambient);
            var shade = new Border
            {
                Background = new LinearGradientBrush(new GradientStopCollection
                {
                    new GradientStop(Color.FromArgb(0x88, 8, 9, 13), 0),
                    new GradientStop(Color.FromArgb(0xE6, 8, 9, 13), 0.55),
                    new GradientStop(Color.FromArgb(0xFA, 8, 9, 13), 1)
                }, 90)
            };
            Children.Add(shade);

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            Children.Add(root);

            // ---------------- barra de arriba
            var top = new Grid { Margin = new Thickness(14, 12, 14, 0) };
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            top.Children.Add(Ui.IconBtn(G.Down, Close, "Cerrar", 52, 22));
            var from = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            var lbl = Ui.T("REPRODUCIENDO DESDE", 11, "Muted", true);
            lbl.HorizontalAlignment = HorizontalAlignment.Center;
            from.Children.Add(lbl);
            _source = Ui.T("", 14, "Text", true);
            _source.HorizontalAlignment = HorizontalAlignment.Center;
            from.Children.Add(_source);
            Grid.SetColumn(from, 1);
            top.Children.Add(from);
            var more = Ui.IconBtn(G.More, () => { if (Engine.Current != null) SongMenu.Show(Engine.Current); }, "Más opciones", 52, 22);
            Grid.SetColumn(more, 2);
            top.Children.Add(more);
            root.Children.Add(top);

            // ---------------- cuerpo
            _main = new Grid();
            _main.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _main.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(440) });
            Grid.SetRow(_main, 1);
            root.Children.Add(_main);

            _left = new Grid();
            _main.Children.Add(_left);
            _info = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
            _left.Children.Add(_info);

            _art = Ui.Cover("", 420, 16, 640);
            _art.HorizontalAlignment = HorizontalAlignment.Center;
            _info.Children.Add(_art);

            var titleRow = new Grid { Margin = new Thickness(0, 26, 0, 0) };
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var names = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            _title = Ui.T("", 26, "Text", true);
            _title.FontWeight = FontWeights.Bold;
            _artist = Ui.T("", 17, "Text2");
            _artist.Margin = new Thickness(0, 4, 0, 0);
            _artist.Cursor = Cursors.Hand;
            Ui.Tap(_artist, () =>
            {
                var s = Engine.Current;
                string a = s == null ? "" : Tx.MainArtist(s.Artist);
                if (a.Length < 2) return;
                Close();
                MainWindow.Instance.Go(ListPage.Artist(a));
            });
            names.Children.Add(_title);
            names.Children.Add(_artist);
            titleRow.Children.Add(names);
            _heart = Ui.IconBtn(G.Heart, () =>
            {
                var s = Engine.Current;
                if (s == null) return;
                bool now = Library.ToggleFavorite(s);
                Toast.Show(now ? "Agregada a Me gusta" : "Quitada de Me gusta");
            }, "Me gusta", 54, 24);
            Grid.SetColumn(_heart, 1);
            titleRow.Children.Add(_heart);
            _info.Children.Add(titleRow);

            _seek = new Slider { Style = Ui.S("Seek"), Minimum = 0, Maximum = 1, Margin = new Thickness(-6, 14, -6, 0) };
            _seek.AddHandler(Thumb.DragStartedEvent, new DragStartedEventHandler((s, e) => _dragging = true));
            _seek.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler((s, e) =>
            {
                _dragging = false;
                Engine.Seek(_seek.Value);
            }));
            _seek.ValueChanged += (s, e) =>
            {
                if (_dragging) { _pos.Text = Tx.Time((long)e.NewValue); return; }
                if (_setting) return;
                Engine.Seek(e.NewValue);
            };
            _info.Children.Add(_seek);
            var times = new Grid();
            _pos = Ui.T("0:00", 13, "Muted");
            _dur = Ui.T("0:00", 13, "Muted");
            _dur.HorizontalAlignment = HorizontalAlignment.Right;
            times.Children.Add(_pos);
            times.Children.Add(_dur);
            _info.Children.Add(times);

            var controls = new Grid { Margin = new Thickness(0, 10, 0, 0) };
            for (int i = 0; i < 5; i++) controls.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _shuffle = Ui.IconBtn(G.Shuffle, () => { Engine.SetShuffle(!Prefs.S.Shuffle); Toast.Show(Prefs.S.Shuffle ? "Aleatorio activado" : "Aleatorio desactivado"); }, "Aleatorio", 56, 22);
            var prev = Ui.IconBtn(G.Prev, Engine.Previous, "Anterior", 64, 28);
            _play = new Button { Style = Ui.S("PlayBig"), Content = G.Play };
            _play.Click += (s, e) => Engine.Toggle();
            var next = Ui.IconBtn(G.Next, () => Engine.Next(false), "Siguiente", 64, 28);
            _repeat = Ui.IconBtn(G.Repeat, () =>
            {
                Engine.CycleRepeat();
                Toast.Show(Prefs.S.Repeat == 0 ? "Sin repetir" : Prefs.S.Repeat == 1 ? "Repetir la lista" : "Repetir esta canción");
            }, "Repetir", 56, 22);
            var ctl = new UIElement[] { _shuffle, prev, _play, next, _repeat };
            for (int i = 0; i < ctl.Length; i++)
            {
                var fe = (FrameworkElement)ctl[i];
                fe.HorizontalAlignment = HorizontalAlignment.Center;
                fe.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(fe, i);
                controls.Children.Add(fe);
            }
            _info.Children.Add(controls);

            // fila de extras
            var extras = new Grid { Margin = new Thickness(0, 18, 0, 0) };
            extras.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            extras.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            extras.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var left = new StackPanel { Orientation = Orientation.Horizontal };
            left.Children.Add(Ui.IconBtn(G.Radio, () => { var s = Engine.Current; if (s != null) { Engine.StartRadio(s); Toast.Show("Mix de canciones parecidas"); } }, "Mix de canciones parecidas", 48, 19));
            left.Children.Add(Ui.IconBtn(G.Folder, () => { var s = Engine.Current; if (s != null && !s.NeedsLookup) SongMenu.PickFolder(s); }, "Agregar a una carpeta", 48, 19));
            _download = Ui.IconBtn(G.Download, () =>
            {
                var s = Engine.Current;
                if (s == null || s.VideoId == null) return;
                if (Downloads.Has(s)) { Toast.Show("Ya está descargada en Música\\P Music"); return; }
                Downloads.Enqueue(s);
                Toast.Show("Descargando…");
            }, "Descargar", 48, 19);
            left.Children.Add(_download);
            left.Children.Add(Ui.IconBtn(G.Moon, SleepMenu, "Temporizador", 48, 19));
            _sideToggleQueue = Ui.IconBtn(G.Queue, () => OpenSide(0), "Cola", 48, 19);
            _sideToggleLyrics = Ui.IconBtn(G.Lyrics, () => OpenSide(1), "Letra", 48, 19);
            left.Children.Add(_sideToggleQueue);
            left.Children.Add(_sideToggleLyrics);
            extras.Children.Add(left);
            _sleep = Ui.T("", 12, "Gold", true);
            _sleep.VerticalAlignment = VerticalAlignment.Center;
            _sleep.Margin = new Thickness(8, 0, 0, 0);
            Grid.SetColumn(_sleep, 1);
            extras.Children.Add(_sleep);
            var vol = new StackPanel { Orientation = Orientation.Horizontal };
            _mute = Ui.IconBtn(G.Volume, () => { Engine.Muted = !Engine.Muted; PaintState(); }, "Silenciar", 44, 18);
            vol.Children.Add(_mute);
            _volume = new Slider { Style = Ui.S("Seek"), Minimum = 0, Maximum = 1, Width = 120, VerticalAlignment = VerticalAlignment.Center, Value = Engine.Volume };
            _volume.ValueChanged += (s, e) => { if (!_setting) { Engine.Volume = e.NewValue; if (Engine.Muted) Engine.Muted = false; } };
            vol.Children.Add(_volume);
            Grid.SetColumn(vol, 2);
            extras.Children.Add(vol);
            _info.Children.Add(extras);

            // ---------------- panel lateral: cola y letra
            var sideRoot = new Grid { Margin = new Thickness(6, 10, 22, 18) };
            sideRoot.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            sideRoot.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            var tabs = new Grid { Margin = new Thickness(14, 12, 10, 8) };
            tabs.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tabs.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var tabRow = new StackPanel { Orientation = Orientation.Horizontal };
            _tabQueue = Ui.Chip("A continuación", true, () => SetTab(0));
            _tabLyrics = Ui.Chip("Letra", false, () => SetTab(1));
            tabRow.Children.Add(_tabQueue);
            tabRow.Children.Add(_tabLyrics);
            tabs.Children.Add(tabRow);
            _sideClose = Ui.IconBtn(G.Close, () => { _sideOpen = false; Layout2(); }, "Cerrar", 44, 16);
            _sideClose.HorizontalAlignment = HorizontalAlignment.Right;
            Grid.SetColumn(_sideClose, 1);
            tabs.Children.Add(_sideClose);
            sideRoot.Children.Add(tabs);
            _queueList = new StackPanel { Margin = new Thickness(6, 0, 6, 12) };
            _queueScroll = Ui.Scroll(_queueList);
            Grid.SetRow(_queueScroll, 1);
            sideRoot.Children.Add(_queueScroll);
            _lyricsList = new StackPanel { Margin = new Thickness(18, 10, 18, 220) };
            _lyricsScroll = Ui.Scroll(_lyricsList);
            _lyricsScroll.ScrollChanged += (s, e) =>
            {
                if (e.VerticalChange != 0 && e.ExtentHeightChange == 0 && (DateTime.Now - _autoScrollAt).TotalMilliseconds > 700)
                    _userScroll = DateTime.Now;
            };
            _lyricsScroll.Visibility = Visibility.Collapsed;
            Grid.SetRow(_lyricsScroll, 1);
            sideRoot.Children.Add(_lyricsScroll);
            _side = new Border
            {
                Background = Ui.Hex("#CC121110"),
                CornerRadius = new CornerRadius(18),
                BorderBrush = Ui.Hex("#22FFFFFF"),
                BorderThickness = new Thickness(1),
                Child = sideRoot,
                Margin = new Thickness(0, 0, 0, 0)
            };
            Grid.SetColumn(_side, 1);
            _main.Children.Add(_side);

            SizeChanged += (s, e) => Layout2();
            Engine.SongChanged += () => { if (IsOpen) PaintSong(); };
            Engine.StateChanged += () => { if (IsOpen) PaintState(); };
            Engine.QueueChanged += () => { if (IsOpen && _tab == 0) PaintQueue(); };
            Library.Changed += () => { if (IsOpen) PaintState(); };
            Downloads.Changed += () => { if (IsOpen) PaintState(); };
            _timer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(250) };
            _timer.Tick += (s, e) => Tick();
            PreviewKeyDown += OnKey;
        }

        private DateTime _autoScrollAt = DateTime.MinValue;

        // ------------------------------------------------------------ abrir / cerrar

        public void Open()
        {
            if (Engine.Current == null) return;
            IsOpen = true;
            Visibility = Visibility.Visible;
            _shownKey = null;
            PaintSong();
            PaintState();
            Layout2();
            _timer.Start();
            double h = ActualHeight > 0 ? ActualHeight : (MainWindow.Instance?.ActualHeight ?? 800);
            var a = new DoubleAnimation(h, 0, TimeSpan.FromMilliseconds(260)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
            _slide.BeginAnimation(TranslateTransform.YProperty, a);
            Focusable = true;
            Focus();
        }

        public void Close()
        {
            if (!IsOpen) return;
            IsOpen = false;
            _timer.Stop();
            double h = ActualHeight > 0 ? ActualHeight : 800;
            var a = new DoubleAnimation(0, h, TimeSpan.FromMilliseconds(220)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
            a.Completed += (s, e) => { if (!IsOpen) Visibility = Visibility.Collapsed; };
            _slide.BeginAnimation(TranslateTransform.YProperty, a);
        }

        /// <summary>Regresar: primero cierra el panel de cola/letra en vertical.</summary>
        public bool Back()
        {
            if (!IsOpen) return false;
            if (!_wide && _sideOpen) { _sideOpen = false; Layout2(); return true; }
            Close();
            return true;
        }

        private void OnKey(object sender, KeyEventArgs e)
        {
            if (!IsOpen) return;
            if (e.Key == Key.Left) { Engine.Seek(Engine.Position - 10); e.Handled = true; }
            else if (e.Key == Key.Right) { Engine.Seek(Engine.Position + 10); e.Handled = true; }
            else if (e.Key == Key.Up) { Engine.Volume = Engine.Volume + 0.05; PaintState(); e.Handled = true; }
            else if (e.Key == Key.Down) { Engine.Volume = Engine.Volume - 0.05; PaintState(); e.Handled = true; }
        }

        // ------------------------------------------------------------ acomodo según el tamaño

        private void Layout2()
        {
            double w = ActualWidth, h = ActualHeight;
            if (w <= 0 || h <= 0) return;
            _wide = w >= 1000;
            if (_wide)
            {
                _main.ColumnDefinitions[1].Width = new GridLength(Math.Min(460, Math.Max(360, w * 0.34)));
                Grid.SetColumn(_side, 1);
                Grid.SetColumnSpan(_side, 1);
                _side.Visibility = Visibility.Visible;
                _side.Margin = new Thickness(0);
                _left.Visibility = Visibility.Visible;
                _sideClose.Visibility = Visibility.Collapsed;
                _sideToggleQueue.Visibility = Visibility.Collapsed;
                _sideToggleLyrics.Visibility = Visibility.Collapsed;
            }
            else
            {
                _main.ColumnDefinitions[1].Width = new GridLength(0);
                Grid.SetColumn(_side, 0);
                Grid.SetColumnSpan(_side, 2);
                _side.Margin = new Thickness(16, 0, -6, 0);
                _side.Visibility = _sideOpen ? Visibility.Visible : Visibility.Collapsed;
                _left.Visibility = _sideOpen ? Visibility.Hidden : Visibility.Visible;
                _sideClose.Visibility = Visibility.Visible;
                _sideToggleQueue.Visibility = Visibility.Visible;
                _sideToggleLyrics.Visibility = Visibility.Visible;
            }
            double leftW = _wide ? w - _main.ColumnDefinitions[1].Width.Value : w;
            double artMax = Math.Min(leftW - 120, h - 400);
            double art = Math.Max(180, Math.Min(560, artMax));
            _art.Width = art;
            _art.Height = art;
            _info.Width = Math.Max(art, Math.Min(leftW - 80, 560));
            if (_tab == 0) PaintQueue(); else PaintLyrics();
        }

        private void OpenSide(int tab)
        {
            _sideOpen = true;
            SetTab(tab);
            Layout2();
        }

        private void SetTab(int tab)
        {
            _tab = tab;
            Ui.SetChip(_tabQueue, tab == 0);
            Ui.SetChip(_tabLyrics, tab == 1);
            _queueScroll.Visibility = tab == 0 ? Visibility.Visible : Visibility.Collapsed;
            _lyricsScroll.Visibility = tab == 1 ? Visibility.Visible : Visibility.Collapsed;
            if (tab == 0) PaintQueue(); else { _lyricsKey = null; PaintLyrics(); }
        }

        // ------------------------------------------------------------ pintar

        private void PaintSong()
        {
            var s = Engine.Current;
            if (s == null) { Close(); return; }
            _title.Text = s.Title;
            _artist.Text = s.Artist;
            _source.Text = string.IsNullOrEmpty(Engine.Source) ? "Tu música" : Engine.Source;
            Ui.SetCover(_art, s.Image, 640);
            if (_artUrl != s.Image)
            {
                _artUrl = s.Image;
                SetAmbient(s.Image);
            }
            if (_shownKey != s.Key)
            {
                _shownKey = s.Key;
                _lyricIndex = -1;
                if (_tab == 1 || _wide) { _lyricsKey = null; PaintLyrics(); }
            }
            if (_tab == 0) PaintQueue();
            PaintState();
        }

        private async void SetAmbient(string url)
        {
            if (string.IsNullOrEmpty(url)) { _ambient.Background = null; return; }
            var bmp = await Images.Get(url, 48);
            if (bmp == null || _artUrl != url) return;
            var brush = new ImageBrush(bmp) { Stretch = Stretch.UniformToFill };
            RenderOptions.SetBitmapScalingMode(brush, BitmapScalingMode.Linear);
            brush.Freeze();
            _ambient.Background = brush;
        }

        private void PaintState()
        {
            var s = Engine.Current;
            if (s == null) return;
            _play.Content = Engine.Playing ? G.Pause : G.Play;
            _shuffle.Foreground = Ui.B(Prefs.S.Shuffle ? "Gold" : "Text2");
            _repeat.Content = Prefs.S.Repeat == 2 ? G.RepeatOne : G.Repeat;
            _repeat.Foreground = Ui.B(Prefs.S.Repeat > 0 ? "Gold" : "Text2");
            bool fav = Library.IsFavorite(s);
            _heart.Content = fav ? G.HeartFill : G.Heart;
            _heart.Foreground = Ui.B(fav ? "Gold" : "Text");
            _heart.Visibility = s.NeedsLookup ? Visibility.Hidden : Visibility.Visible;
            bool dl = Downloads.Has(s);
            _download.Content = dl ? G.Downloaded : G.Download;
            _download.Foreground = Ui.B(dl || Downloads.IsQueued(s) ? "Gold" : "Text");
            _mute.Content = Engine.Muted || Engine.Volume < 0.01 ? G.Mute : G.Volume;
            _setting = true;
            _volume.Value = Engine.Volume;
            _setting = false;
            _sleep.Text = Engine.SleepEndOfSong ? "Se detiene al terminar la canción"
                : Engine.SleepAt.HasValue ? "Se detiene a las " + Engine.SleepAt.Value.ToString("h:mm tt") : "";
            _artist.Text = Engine.Loading && !Engine.Playing ? "Cargando…" : s.Artist;
            Tick();
        }

        private void Tick()
        {
            if (!IsOpen) return;
            double d = Engine.Duration, p = Engine.Position;
            if (!_dragging)
            {
                _setting = true;
                _seek.Maximum = Math.Max(1, d);
                _seek.Value = Math.Max(0, Math.Min(_seek.Maximum, p));
                _setting = false;
                _pos.Text = Tx.Time((long)p);
            }
            _dur.Text = d > 0 ? Tx.Time((long)d) : "--:--";
            if (_lyrics != null && _lyrics.Synced && _lyricsScroll.Visibility == Visibility.Visible) FollowLyrics(p);
        }

        private void PaintQueue()
        {
            if (!IsOpen || _queueScroll.Visibility != Visibility.Visible) return;
            if (!_wide && !_sideOpen) return;
            _queueList.Children.Clear();
            var q = Engine.Queue;
            int idx = Engine.Index;
            if (idx < 0 || idx >= q.Count) return;
            _queueList.Children.Add(Label("Sonando ahora"));
            _queueList.Children.Add(QueueRow(q[idx], idx, true));
            if (idx + 1 < q.Count)
            {
                var head = new Grid { Margin = new Thickness(10, 18, 4, 6) };
                var l = Ui.T("A continuación", 15, "Text", true);
                l.VerticalAlignment = VerticalAlignment.Center;
                head.Children.Add(l);
                var clear = new Button { Style = Ui.S("IconBtn"), Width = double.NaN, Height = 36, FontFamily = Ui.Font, FontSize = 13, Content = "Limpiar", Foreground = Ui.B("Muted"), HorizontalAlignment = HorizontalAlignment.Right };
                clear.Click += (s, e) => Engine.ClearUpcoming();
                head.Children.Add(clear);
                _queueList.Children.Add(head);
                int end = Math.Min(q.Count, idx + 80);
                for (int i = idx + 1; i < end; i++) _queueList.Children.Add(QueueRow(q[i], i, false));
            }
            else
            {
                var t = Ui.T(Prefs.S.Autoplay ? "Al terminar seguirán canciones parecidas." : "No hay más canciones en la cola.", 14, "Muted", false, true);
                t.Margin = new Thickness(12, 18, 12, 0);
                _queueList.Children.Add(t);
            }
        }

        private static FrameworkElement Label(string text)
        {
            var t = Ui.T(text, 15, "Text", true);
            t.Margin = new Thickness(10, 4, 0, 6);
            return t;
        }

        private FrameworkElement QueueRow(Song s, int index, bool current)
        {
            var row = new Border { Height = 60, CornerRadius = new CornerRadius(10), Padding = new Thickness(8, 0, 4, 0), Background = current ? Ui.Hex("#1AFFCF4A") : Brushes.Transparent, Cursor = Cursors.Hand };
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var c = Ui.Cover(s.Image, 44, 6, 90);
            c.VerticalAlignment = VerticalAlignment.Center;
            g.Children.Add(c);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 8, 0) };
            sp.Children.Add(Ui.T(s.Title, 14.5, current ? "Gold" : "Text", true));
            sp.Children.Add(Ui.T(s.Artist, 12.5, "Muted"));
            Grid.SetColumn(sp, 1);
            g.Children.Add(sp);
            if (!current)
            {
                var x = Ui.IconBtn(G.Close, () => Engine.RemoveAt(index), "Quitar de la cola", 40, 13);
                x.Foreground = Ui.B("Muted");
                Grid.SetColumn(x, 2);
                g.Children.Add(x);
            }
            row.Child = g;
            if (!current)
            {
                Ui.Hover(row);
                Ui.Tap(row, () => Engine.JumpTo(index));
            }
            row.MouseRightButtonUp += (o, e) => { e.Handled = true; SongMenu.Show(s); };
            return row;
        }

        private async void PaintLyrics()
        {
            if (!IsOpen) return;
            var s = Engine.Current;
            if (s == null) return;
            if (_lyricsKey == s.Key) return;
            _lyricsKey = s.Key;
            _lyrics = null;
            _lyricIndex = -1;
            _lyricsList.Children.Clear();
            _lyricsList.Children.Add(Ui.T("Buscando la letra…", 18, "Muted", false, true));
            if (s.NeedsLookup) return;
            var ly = await LyricsService.Find(s);
            if (_lyricsKey != s.Key) return;
            _lyrics = ly;
            _lyricsList.Children.Clear();
            if (ly.Empty)
            {
                _lyricsList.Children.Add(Ui.T("No encontramos la letra de esta canción.", 18, "Muted", false, true));
                return;
            }
            if (!ly.Synced)
            {
                var t = Ui.T(ly.Plain, 19, "Text2", false, true);
                t.LineHeight = 30;
                _lyricsList.Children.Add(t);
                return;
            }
            foreach (var line in ly.Lines)
            {
                var l = line;
                var t = Ui.T(string.IsNullOrWhiteSpace(l.Text) ? "♪" : l.Text, 22, "Muted2", true, true);
                t.FontWeight = FontWeights.Bold;
                t.Margin = new Thickness(0, 0, 0, 16);
                t.Cursor = Cursors.Hand;
                t.Background = Brushes.Transparent;
                Ui.Tap(t, () => { Engine.Seek(l.At); _userScroll = DateTime.MinValue; });
                _lyricsList.Children.Add(t);
            }
            var credit = Ui.T("Letra sincronizada", 12, "Muted2");
            credit.Margin = new Thickness(0, 20, 0, 0);
            _lyricsList.Children.Add(credit);
        }

        private void FollowLyrics(double pos)
        {
            var lines = _lyrics.Lines;
            int i = -1;
            for (int k = 0; k < lines.Count; k++)
            {
                if (lines[k].At <= pos + 0.25) i = k;
                else break;
            }
            if (i == _lyricIndex) return;
            for (int k = 0; k < lines.Count && k < _lyricsList.Children.Count; k++)
            {
                var t = _lyricsList.Children[k] as TextBlock;
                if (t == null) continue;
                t.Foreground = Ui.B(k == i ? "Text" : k < i ? "Muted" : "Muted2");
            }
            _lyricIndex = i;
            if (i < 0 || i >= _lyricsList.Children.Count) return;
            if ((DateTime.Now - _userScroll).TotalSeconds < 4) return;
            var el = _lyricsList.Children[i] as FrameworkElement;
            if (el == null) return;
            try
            {
                var pt = el.TransformToAncestor(_lyricsList).Transform(new Point(0, 0));
                double target = Math.Max(0, pt.Y + _lyricsList.Margin.Top - _lyricsScroll.ViewportHeight * 0.32);
                _autoScrollAt = DateTime.Now;
                _lyricsScroll.ScrollToVerticalOffset(target);
            }
            catch { }
        }

        // ------------------------------------------------------------ temporizador

        private void SleepMenu()
        {
            var items = new List<Opt>();
            foreach (int m in new[] { 15, 30, 45, 60, 90 })
            {
                int min = m;
                items.Add(new Opt(G.Moon, min + " minutos", () => { Engine.SetSleep(min); Toast.Show("La música se detendrá en " + min + " minutos"); }));
            }
            items.Add(new Opt(G.Music, "Al terminar esta canción", () => { Engine.SetSleepEndOfSong(); Toast.Show("Se detendrá al terminar la canción"); }));
            if (Engine.SleepAt.HasValue || Engine.SleepEndOfSong)
                items.Add(new Opt(G.Close, "Apagar temporizador", () => { Engine.SetSleep(0); Toast.Show("Temporizador apagado"); }, true));
            Sheet.Menu("Temporizador", "Detener la música después de…", null, items);
        }
    }
}
