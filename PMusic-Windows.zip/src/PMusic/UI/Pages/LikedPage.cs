using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>Me gusta: tus canciones favoritas (las mismas del teléfono).</summary>
    public sealed class LikedPage : Page
    {
        public override string Tab => "liked";

        private readonly StackPanel _body = new StackPanel();
        private readonly ScrollViewer _scroll;
        private readonly TextBlock _count;
        private readonly StackPanel _listHost = new StackPanel();
        private readonly TextBox _filter;
        private readonly Button[] _sorts = new Button[3];
        private readonly CheckBox _auto;
        private int _builtVersion = -1;
        private string _builtFilter = "";
        private SongList _list;

        public LikedPage()
        {
            var banner = new Border
            {
                CornerRadius = new CornerRadius(20),
                Padding = new Thickness(24),
                Background = new LinearGradientBrush(Color.FromArgb(0x66, 0xFF, 0xCF, 0x4A), Color.FromArgb(0x10, 0xFF, 0xCF, 0x4A), 90)
            };
            var bg = new Grid();
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var heart = new Border
            {
                Width = 150,
                Height = 150,
                CornerRadius = new CornerRadius(16),
                Background = new LinearGradientBrush(Color.FromRgb(0xFF, 0xCF, 0x4A), Color.FromRgb(0x9A, 0x4B, 0x1A), 45),
                Child = Ui.Icon(G.HeartFill, 60, "OnGold")
            };
            bg.Children.Add(heart);
            var info = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24, 0, 0, 0) };
            info.Children.Add(Ui.T("LISTA", 12, "Text2", true));
            var title = Ui.H("Me gusta", 40);
            info.Children.Add(title);
            _count = Ui.T("", 15, "Text2");
            _count.Margin = new Thickness(0, 4, 0, 16);
            info.Children.Add(_count);
            var buttons = new WrapPanel();
            var play = Ui.Pill("Reproducir", () => PlayAll(false), true, G.Play);
            play.Margin = new Thickness(0, 0, 10, 8);
            buttons.Children.Add(play);
            var shuffle = Ui.Pill("Aleatorio", () => PlayAll(true), false, G.Shuffle);
            shuffle.Margin = new Thickness(0, 0, 10, 8);
            buttons.Children.Add(shuffle);
            var autoRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 0, 8) };
            _auto = new CheckBox { Style = Ui.S("Switch") };
            _auto.Click += (s, e) =>
            {
                Library.SetAutoFavorites(_auto.IsChecked == true);
                Toast.Show(_auto.IsChecked == true ? "Tus Me gusta se descargarán para escucharlos sin internet" : "Descarga automática apagada");
            };
            autoRow.Children.Add(_auto);
            var autoLbl = Ui.T("Descargar", 14, "Text2", true);
            autoLbl.VerticalAlignment = VerticalAlignment.Center;
            autoLbl.Margin = new Thickness(10, 0, 0, 0);
            autoRow.Children.Add(autoLbl);
            buttons.Children.Add(autoRow);
            info.Children.Add(buttons);
            Grid.SetColumn(info, 1);
            bg.Children.Add(info);
            banner.Child = bg;
            _body.Children.Add(banner);

            var tools = new Grid { Margin = new Thickness(0, 22, 0, 10) };
            tools.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MaxWidth = 420 });
            tools.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var fieldHost = new Grid();
            _filter = new TextBox { Style = Ui.S("Field"), Height = 46, FontSize = 15, Padding = new Thickness(46, 0, 16, 0) };
            fieldHost.Children.Add(_filter);
            var ic = Ui.Icon(G.Search, 15, "Muted");
            ic.HorizontalAlignment = HorizontalAlignment.Left;
            ic.Margin = new Thickness(18, 0, 0, 0);
            ic.IsHitTestVisible = false;
            fieldHost.Children.Add(ic);
            var hint = Ui.T("Buscar en Me gusta", 15, "Muted2");
            hint.IsHitTestVisible = false;
            hint.VerticalAlignment = VerticalAlignment.Center;
            hint.Margin = new Thickness(48, 0, 0, 0);
            fieldHost.Children.Add(hint);
            _filter.TextChanged += (s, e) =>
            {
                hint.Visibility = _filter.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                Build(true);
            };
            tools.Children.Add(fieldHost);
            var sorts = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
            string[] names = { "Recientes", "A-Z", "Artista" };
            for (int i = 0; i < 3; i++)
            {
                int k = i;
                _sorts[i] = Ui.Chip(names[i], Prefs.S.FavoritesSort == i, () =>
                {
                    Prefs.S.FavoritesSort = k;
                    Prefs.Save();
                    Build(true);
                });
                sorts.Children.Add(_sorts[i]);
            }
            Grid.SetColumn(sorts, 1);
            tools.Children.Add(sorts);
            _body.Children.Add(tools);
            _body.Children.Add(_listHost);
            _body.Children.Add(Ui.Space(30));

            _scroll = Ui.Scroll(_body);
            Ui.NearBottom(_scroll, () => _list?.More());
            Children.Add(_scroll);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                _body.Margin = new Thickness(side, 20, side, 10);
                heart.Width = heart.Height = ActualWidth >= 800 ? 150 : 100;
            };
            Library.Changed += () => { if (IsLoaded) Build(false); };
        }

        public override void OnShow() => Build(false);

        private List<Song> Sorted()
        {
            IEnumerable<Song> list = Library.Favorites;
            string f = Tx.Plain(_filter.Text);
            if (f.Length > 0) list = list.Where(s => Tx.Plain(s.Title + " " + s.Artist).Contains(f));
            if (Prefs.S.FavoritesSort == 1) list = list.OrderBy(s => s.Title, StringComparer.CurrentCultureIgnoreCase);
            else if (Prefs.S.FavoritesSort == 2) list = list.OrderBy(s => s.Artist, StringComparer.CurrentCultureIgnoreCase).ThenBy(s => s.Title, StringComparer.CurrentCultureIgnoreCase);
            return list.ToList();
        }

        private void Build(bool force)
        {
            if (!force && _builtVersion == Library.Version && _builtFilter == _filter.Text) return;
            _builtVersion = Library.Version;
            _builtFilter = _filter.Text;
            for (int i = 0; i < 3; i++) Ui.SetChip(_sorts[i], Prefs.S.FavoritesSort == i);
            _auto.IsChecked = Library.AutoFavorites;
            int n = Library.Favorites.Count;
            long secs = Library.Favorites.Sum(s => s.Seconds);
            _count.Text = Tx.Count(n, "canción", "canciones") + (secs > 0 ? " · " + Tx.Minutes(secs) : "") + (Account.CanSync ? " · sincronizado con tu teléfono" : "");
            _listHost.Children.Clear();
            _list = null;
            var songs = Sorted();
            if (songs.Count == 0)
            {
                var t = Ui.T(n == 0 ? "Toca el corazón de cualquier canción para guardarla aquí." : "Ninguna canción coincide.", 15, "Muted", false, true);
                t.Margin = new Thickness(6, 20, 0, 0);
                _listHost.Children.Add(t);
                return;
            }
            _list = new SongList(songs, "Me gusta");
            _listHost.Children.Add(_list);
        }

        private void PlayAll(bool shuffle)
        {
            var songs = Sorted();
            if (songs.Count == 0) { Toast.Show("Aún no tienes canciones en Me gusta"); return; }
            Engine.PlayList(songs, 0, "Me gusta", shuffle);
        }
    }
}
