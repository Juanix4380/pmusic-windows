using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>Buscar canciones y artistas, con sugerencias, búsquedas recientes y géneros.</summary>
    public sealed class SearchPage : Page
    {
        public override string Tab => "search";

        private static readonly string[][] Genres =
        {
            new[] { "Regional mexicano", "#9a4b1a" }, new[] { "Corridos", "#7a5a1f" }, new[] { "Banda", "#b0306a" },
            new[] { "Norteño", "#2f6f6a" }, new[] { "Cumbias", "#1f7a5a" }, new[] { "Reggaetón", "#5b2f8c" },
            new[] { "Pop latino", "#2f5f7a" }, new[] { "Rock en español", "#3f4f8a" }, new[] { "Baladas románticas", "#8c2f4a" },
            new[] { "Mariachi", "#6a4a1a" }, new[] { "Sierreño", "#6f5a2f" }, new[] { "Salsa", "#a3402a" },
            new[] { "Rap en español", "#4a4a4a" }, new[] { "Electrónica", "#2a5a8c" }, new[] { "Éxitos de los 80", "#8c5a1f" },
            new[] { "Éxitos de los 90", "#5a3f8a" }
        };

        private readonly TextBox _box;
        private readonly TextBlock _hint;
        private readonly Button _clear;
        private readonly StackPanel _content = new StackPanel();
        private readonly ScrollViewer _scroll;
        private readonly StackPanel _suggest = new StackPanel();
        private readonly Border _suggestHost;
        private readonly DispatcherTimer _typing;
        private CancellationTokenSource _cts;
        private string _query = "";
        private bool _settingText;
        private SongList _list;

        public SearchPage()
        {
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var top = new StackPanel();
            var title = Ui.H("Buscar", 30);
            title.Margin = new Thickness(0, 0, 0, 14);
            top.Children.Add(title);
            var field = new Grid();
            _box = new TextBox { Style = Ui.S("Field"), Height = 56, FontSize = 17, Padding = new Thickness(52, 0, 54, 0) };
            field.Children.Add(_box);
            var icon = Ui.Icon(G.Search, 19, "Muted");
            icon.HorizontalAlignment = HorizontalAlignment.Left;
            icon.Margin = new Thickness(22, 0, 0, 0);
            icon.IsHitTestVisible = false;
            field.Children.Add(icon);
            _hint = Ui.T("¿Qué quieres escuchar?", 17, "Muted2");
            _hint.IsHitTestVisible = false;
            _hint.VerticalAlignment = VerticalAlignment.Center;
            _hint.Margin = new Thickness(55, 0, 0, 0);
            field.Children.Add(_hint);
            _clear = Ui.IconBtn(G.Close, () => { _box.Text = ""; _box.Focus(); }, "Borrar", 46, 15);
            _clear.HorizontalAlignment = HorizontalAlignment.Right;
            _clear.Margin = new Thickness(0, 0, 6, 0);
            _clear.Visibility = Visibility.Collapsed;
            field.Children.Add(_clear);
            top.Children.Add(field);
            Children.Add(top);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                top.Margin = new Thickness(side, 20, side, 6);
                _content.Margin = new Thickness(side, 8, side, 30);
                _suggestHost.Margin = new Thickness(side, 0, side, 0);
            };

            _scroll = Ui.Scroll(_content);
            Ui.NearBottom(_scroll, () => _list?.More());
            Grid.SetRow(_scroll, 1);
            Children.Add(_scroll);

            _suggestHost = new Border
            {
                Background = Ui.B("Panel"),
                BorderBrush = Ui.B("Stroke"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(16),
                VerticalAlignment = VerticalAlignment.Top,
                Padding = new Thickness(0, 6, 0, 6),
                Child = _suggest,
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(_suggestHost, 1);
            Children.Add(_suggestHost);

            _typing = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(320) };
            _typing.Tick += (s, e) => { _typing.Stop(); Suggest(); };
            _box.TextChanged += (s, e) =>
            {
                _hint.Visibility = _box.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
                _clear.Visibility = _box.Text.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
                if (_settingText) return;
                _typing.Stop();
                if (_box.Text.Trim().Length >= 2) _typing.Start();
                else HideSuggest();
                if (_box.Text.Length == 0) ShowStart();
            };
            _box.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter) { Run(_box.Text); e.Handled = true; }
                else if (e.Key == Key.Escape) { HideSuggest(); e.Handled = true; }
            };
            _box.LostKeyboardFocus += (s, e) => UiThread.After(200, HideSuggest);
            ShowStart();
        }

        public override void OnShow()
        {
            if (_query.Length == 0) ShowStart();
        }

        public void FocusBox()
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => { _box.Focus(); _box.SelectAll(); }));
        }

        public override bool OnBack()
        {
            if (_suggestHost.Visibility == Visibility.Visible) { HideSuggest(); return true; }
            if (_query.Length > 0) { SetText(""); _query = ""; ShowStart(); return true; }
            return false;
        }

        private void SetText(string t)
        {
            _settingText = true;
            _box.Text = t;
            _box.CaretIndex = t.Length;
            _settingText = false;
        }

        // ------------------------------------------------------------ inicio: recientes y géneros

        private void ShowStart()
        {
            _query = "";
            _list = null;
            _content.Children.Clear();
            if (Prefs.S.Searches.Count > 0)
            {
                _content.Children.Add(Ui.Section("Búsquedas recientes", null, "Borrar", () => { Prefs.S.Searches.Clear(); Prefs.Save(); ShowStart(); }));
                var wrap = new WrapPanel();
                foreach (string q in Prefs.S.Searches)
                {
                    string query = q;
                    var chip = Ui.Chip(query, false, () => Run(query));
                    chip.Margin = new Thickness(0, 0, 10, 10);
                    wrap.Children.Add(chip);
                }
                _content.Children.Add(wrap);
            }
            _content.Children.Add(Ui.Section("Explorar todo"));
            var grid = new WrapPanel();
            double w = ActualWidth > 0 ? ActualWidth - 2 * Side(ActualWidth) : 1000;
            int cols = w >= 1000 ? 4 : w >= 640 ? 3 : 2;
            double tileW = Math.Floor((w - 14 * cols) / cols);
            foreach (var g in Genres)
            {
                string q = g[0];
                grid.Children.Add(Cards.Tile(q, null, g[1], tileW, 96, () => Run(q)));
            }
            _content.Children.Add(grid);
            _scroll.ScrollToTop();
        }

        // ------------------------------------------------------------ sugerencias

        private async void Suggest()
        {
            string text = _box.Text.Trim();
            if (text.Length < 2 || !_box.IsKeyboardFocused) return;
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var ct = _cts.Token;
            List<string> list;
            try { list = await YtMusic.Suggestions(text, ct); }
            catch { return; }
            if (ct.IsCancellationRequested || _box.Text.Trim() != text || !_box.IsKeyboardFocused) return;
            _suggest.Children.Clear();
            foreach (string s in list.Take(7))
            {
                string q = s;
                var row = new Border { Height = 50, Padding = new Thickness(18, 0, 18, 0), Background = Brushes.Transparent, Cursor = Cursors.Hand };
                var sp = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                var ic = Ui.Icon(G.Search, 15, "Muted");
                ic.Margin = new Thickness(0, 0, 14, 0);
                sp.Children.Add(ic);
                sp.Children.Add(Ui.T(q, 15.5, "Text"));
                row.Child = sp;
                Ui.Hover(row);
                Ui.Tap(row, () => Run(q));
                _suggest.Children.Add(row);
            }
            _suggestHost.Visibility = _suggest.Children.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void HideSuggest()
        {
            _suggestHost.Visibility = Visibility.Collapsed;
        }

        // ------------------------------------------------------------ resultados

        public async void Run(string text)
        {
            text = (text ?? "").Trim();
            if (text.Length == 0) return;
            _typing.Stop();
            HideSuggest();
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var ct = _cts.Token;
            SetText(text);
            _query = text;
            Prefs.AddSearch(text);
            Keyboard.ClearFocus();
            _list = null;
            _content.Children.Clear();
            _content.Children.Add(Ui.Section("Resultados para “" + text + "”"));
            var loading = Ui.T("Buscando…", 15, "Muted");
            _content.Children.Add(loading);
            _scroll.ScrollToTop();
            SongPage page;
            try
            {
                page = await YtMusic.Search(text, null, ct);
            }
            catch (OperationCanceledException) { return; }
            catch (Exception e)
            {
                Log.Write("Búsqueda: " + e.Message);
                if (_query != text) return;
                loading.Text = "No se pudo buscar. Revisa tu conexión e intenta otra vez.";
                return;
            }
            if (_query != text || ct.IsCancellationRequested) return;
            _content.Children.Remove(loading);
            var songs = page.Songs.Where(s => !Library.IsHidden(s)).ToList();
            if (songs.Count == 0)
            {
                _content.Children.Add(Ui.T("No encontramos canciones con esa búsqueda.", 15, "Muted"));
                return;
            }
            var actions = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 14) };
            var list = new SongList(songs, "Búsqueda · " + text);
            var play = Ui.Pill("Reproducir", () => Engine.PlayList(list.Songs, 0, "Búsqueda · " + text), true, G.Play);
            play.Margin = new Thickness(0, 0, 10, 0);
            actions.Children.Add(play);
            var mix = Ui.Pill("Mix", () => Engine.StartRadio(list.Songs[0], "Mix · " + text), false, G.Radio);
            mix.Margin = new Thickness(0, 0, 10, 0);
            actions.Children.Add(mix);
            string artist = Tx.MainArtist(songs[0].Artist);
            if (artist.Length > 1 && Tx.Plain(text).Contains(Tx.Plain(artist)))
                actions.Children.Add(Ui.Pill("Ver " + artist, () => Main.Go(ListPage.Artist(artist)), false, G.Person));
            _content.Children.Add(actions);
            string cont = page.Continuation;
            if (!string.IsNullOrEmpty(cont))
            {
                list.LoadMore = async () =>
                {
                    var next = await YtMusic.Search(text, cont);
                    cont = next.Continuation;
                    next.Songs.RemoveAll(s => Library.IsHidden(s));
                    return next;
                };
            }
            _content.Children.Add(list);
            _list = list;
        }
    }
}
