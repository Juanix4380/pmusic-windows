using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>Tu cuenta y ajustes: sincronización, pantalla bloqueada, descargas y cerrar sesión.</summary>
    public sealed class AccountPage : Page
    {
        private readonly StackPanel _body = new StackPanel();
        private readonly TextBlock _sync;
        private readonly CheckBox _power;
        private readonly TextBlock _powerNote;
        private readonly TextBlock _cache;
        private readonly TextBlock _hidden;
        private bool _settingPower;
        private readonly TextBlock _tools;
        private readonly System.Windows.Threading.DispatcherTimer _toolTimer;

        public AccountPage()
        {
            _body.Children.Add(TopBar("Tu cuenta y ajustes"));
            var content = new StackPanel { MaxWidth = 760, HorizontalAlignment = HorizontalAlignment.Stretch };
            _body.Children.Add(content);

            // cuenta
            var acct = new Grid();
            acct.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            acct.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            string name = Account.Current?.Username ?? "";
            acct.Children.Add(new Border
            {
                Width = 64,
                Height = 64,
                CornerRadius = new CornerRadius(32),
                Background = Ui.B("Gold"),
                Child = new TextBlock { Text = name.Length > 0 ? name.Substring(0, 1).ToUpperInvariant() : "?", FontSize = 26, FontWeight = FontWeights.Bold, Foreground = Ui.B("OnGold"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
            });
            var who = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(18, 0, 0, 0) };
            who.Children.Add(Ui.T(name, 20, "Text", true));
            who.Children.Add(Ui.T(Account.ExpiryText, 14, "Muted"));
            var kind = Ui.T(Account.CanSync ? "Sesión de música · no usa conexiones de TV" : "Acceso alternativo · sin sincronización", 13, "Muted2");
            kind.Margin = new Thickness(0, 2, 0, 0);
            who.Children.Add(kind);
            Grid.SetColumn(who, 1);
            acct.Children.Add(who);
            content.Children.Add(Ui.Card(acct, 18, "Card", new Thickness(20)));

            // sincronización
            var syncBox = new StackPanel();
            syncBox.Children.Add(Title("Sincronización con tu teléfono", G.Sync));
            _sync = Ui.T("", 14, "Muted", false, true);
            _sync.Margin = new Thickness(0, 4, 0, 12);
            syncBox.Children.Add(_sync);
            var syncNow = Ui.Pill("Sincronizar ahora", () => { var t = Cloud.Run(); }, false, G.Sync);
            syncNow.HorizontalAlignment = HorizontalAlignment.Left;
            syncNow.IsEnabled = Account.CanSync;
            syncBox.Children.Add(syncNow);
            content.Children.Add(Gap(Ui.Card(syncBox, 18, "Card", new Thickness(20))));

            // pantalla bloqueada
            var lockBox = new StackPanel();
            lockBox.Children.Add(Title("Pantalla bloqueada", G.Power));
            var explain = Ui.T("La música sigue sonando con la tablet bloqueada (Windows + L) y cuando la pantalla se apaga sola; en la pantalla de bloqueo salen la portada y los botones anterior, pausa y siguiente. " +
                "Ojo: desde Windows 11 24H2, si presionas el botón de encendido para suspender o cierras la tapa del teclado, Windows corta el audio de todas las apps. " +
                "Para bloquear sin que se corte usa Windows + L, o activa la opción de abajo.", 14, "Text2", false, true);
            explain.Margin = new Thickness(0, 4, 0, 14);
            explain.LineHeight = 21;
            lockBox.Children.Add(explain);
            _power = new CheckBox { Style = Ui.S("Switch") };
            _power.Click += (s, e) => TogglePower();
            lockBox.Children.Add(SwitchRow(_power, "Botón de encendido: solo apagar la pantalla", "Presionas el botón y solo se apaga la pantalla, sin suspender, así la música sigue. Desactivado, el botón suspende la tablet y Windows corta la música."));
            _powerNote = Ui.T("", 12.5, "Muted2", false, true);
            _powerNote.Margin = new Thickness(0, 6, 0, 0);
            lockBox.Children.Add(_powerNote);
            content.Children.Add(Gap(Ui.Card(lockBox, 18, "Card", new Thickness(20))));

            // reproducción
            var playBox = new StackPanel();
            playBox.Children.Add(Title("Reproducción", G.Play));
            var auto = new CheckBox { Style = Ui.S("Switch"), IsChecked = Prefs.S.Autoplay };
            auto.Click += (s, e) => { Prefs.S.Autoplay = auto.IsChecked == true; Prefs.Save(); };
            playBox.Children.Add(SwitchRow(auto, "Reproducción automática", "Al terminar tu lista siguen canciones parecidas."));
            content.Children.Add(Gap(Ui.Card(playBox, 18, "Card", new Thickness(20))));

            // descargas y espacio
            var dlBox = new StackPanel();
            dlBox.Children.Add(Title("Descargas y espacio", G.Download));
            var favAuto = new CheckBox { Style = Ui.S("Switch"), IsChecked = Library.AutoFavorites };
            favAuto.Click += (s, e) => Library.SetAutoFavorites(favAuto.IsChecked == true);
            dlBox.Children.Add(SwitchRow(favAuto, "Descargar Me gusta automáticamente", "Para escucharlos sin internet. Se guardan en Música › P Music."));
            _cache = Ui.T("", 14, "Muted", false, true);
            _cache.Margin = new Thickness(0, 14, 0, 10);
            dlBox.Children.Add(_cache);
            var dlButtons = new WrapPanel();
            var open = Ui.Pill("Abrir descargas", () =>
            {
                try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + Paths.Downloads() + "\"") { UseShellExecute = true }); }
                catch { Toast.Show("No se pudo abrir la carpeta"); }
            }, false, G.Folder);
            open.Margin = new Thickness(0, 0, 10, 8);
            dlButtons.Children.Add(open);
            var clear = Ui.Pill("Limpiar caché", () =>
            {
                Streams.ClearCache();
                Toast.Show("Caché limpia");
                PaintCache();
            }, false, G.Clear);
            clear.Margin = new Thickness(0, 0, 10, 8);
            dlButtons.Children.Add(clear);
            dlBox.Children.Add(dlButtons);
            content.Children.Add(Gap(Ui.Card(dlBox, 18, "Card", new Thickness(20))));

            // canciones ocultas
            var hidBox = new StackPanel();
            hidBox.Children.Add(Title("Canciones ocultas", G.Hide));
            _hidden = Ui.T("", 14, "Muted", false, true);
            _hidden.Margin = new Thickness(0, 4, 0, 12);
            hidBox.Children.Add(_hidden);
            var manage = Ui.Pill("Ver ocultas", ShowHidden, false, G.Hide);
            manage.HorizontalAlignment = HorizontalAlignment.Left;
            hidBox.Children.Add(manage);
            content.Children.Add(Gap(Ui.Card(hidBox, 18, "Card", new Thickness(20))));

            // diagnóstico
            var diagBox = new StackPanel();
            diagBox.Children.Add(Title("Diagnóstico", G.Info));
            _tools = Ui.T("", 14, "Muted", false, true);
            _tools.Margin = new Thickness(0, 4, 0, 12);
            diagBox.Children.Add(_tools);
            var diagButtons = new WrapPanel();
            var showLog = Ui.Pill("Ver registro", ShowLog, false, G.Info);
            showLog.Margin = new Thickness(0, 0, 10, 8);
            diagButtons.Children.Add(showLog);
            var prepare = Ui.Pill("Preparar respaldo", () => { Streams.PrepareTools(); Toast.Show("Preparando el respaldo…"); }, false, G.Sync);
            prepare.Margin = new Thickness(0, 0, 10, 8);
            diagButtons.Children.Add(prepare);
            diagBox.Children.Add(diagButtons);
            content.Children.Add(Gap(Ui.Card(diagBox, 18, "Card", new Thickness(20))));
            _toolTimer = UiThread.Every(1000, () => { if (IsLoaded) _tools.Text = "Método de respaldo: " + Streams.ToolText; });

            var logout = Ui.Pill("Cerrar sesión", () => Sheet.Confirm("¿Cerrar sesión?",
                "Tu música se queda guardada en tu cuenta. Las descargas siguen en Música › P Music.", "Cerrar sesión", () => Main.Logout(null)), false, G.Logout);
            logout.HorizontalAlignment = HorizontalAlignment.Left;
            logout.Margin = new Thickness(0, 22, 0, 0);
            content.Children.Add(logout);

            var ver = Ui.T("P Music para Windows " + typeof(AccountPage).Assembly.GetName().Version.ToString(3), 12.5, "Muted2");
            ver.Margin = new Thickness(2, 22, 0, 30);
            content.Children.Add(ver);

            var scroll = Ui.Scroll(_body);
            Children.Add(scroll);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                content.Margin = new Thickness(side, 10, side, 10);
            };
            Cloud.StatusChanged += PaintSync;
            Unloaded += (s, e) =>
            {
                Cloud.StatusChanged -= PaintSync;
                _toolTimer.Stop();
            };
            Loaded += (s, e) => _toolTimer.Start();
        }

        private static FrameworkElement Gap(FrameworkElement e)
        {
            e.Margin = new Thickness(0, 14, 0, 0);
            return e;
        }

        private static FrameworkElement Title(string text, string glyph)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 4) };
            var ic = Ui.Icon(glyph, 18, "Gold");
            ic.Margin = new Thickness(0, 0, 12, 0);
            sp.Children.Add(ic);
            sp.Children.Add(Ui.T(text, 17, "Text", true));
            return sp;
        }

        private static FrameworkElement SwitchRow(CheckBox box, string title, string sub)
        {
            var g = new Grid { Margin = new Thickness(0, 6, 0, 0) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var sp = new StackPanel { Margin = new Thickness(0, 0, 16, 0) };
            sp.Children.Add(Ui.T(title, 15.5, "Text", true, true));
            var s = Ui.T(sub, 13, "Muted", false, true);
            s.Margin = new Thickness(0, 3, 0, 0);
            sp.Children.Add(s);
            g.Children.Add(sp);
            Grid.SetColumn(box, 1);
            g.Children.Add(box);
            return g;
        }

        public override void OnShow()
        {
            PaintSync();
            PaintCache();
            _hidden.Text = Library.HiddenSongs.Count == 0 ? "No tienes canciones ocultas." : Tx.Count(Library.HiddenSongs.Count, "canción oculta", "canciones ocultas") + " (no salen en mixes ni búsquedas).";
            ReadPower();
        }

        private void PaintSync()
        {
            if (!Account.CanSync) { _sync.Text = "Con el acceso alternativo tu biblioteca se guarda solo en esta PC."; return; }
            if (Cloud.Busy) { _sync.Text = "Sincronizando…"; return; }
            string last = Cloud.LastSync == DateTime.MinValue ? "todavía no" : "hoy a las " + Cloud.LastSync.ToString("h:mm tt", CultureInfo.CurrentCulture);
            _sync.Text = "Me gusta, carpetas, recientes y la canción que escuchabas se comparten con tu teléfono. Última vez: " + last + "." +
                         (string.IsNullOrEmpty(Cloud.LastError) ? "" : " (" + Cloud.LastError + ")");
        }

        private void PaintCache()
        {
            double cache = Streams.CacheBytes() / 1048576.0;
            double dl = Downloads.Bytes() / 1048576.0;
            _cache.Text = "Descargas: " + dl.ToString("0", CultureInfo.InvariantCulture) + " MB · Caché para reproducir sin cortes: " + cache.ToString("0", CultureInfo.InvariantCulture) + " MB (máximo 1.5 GB, se limpia sola).";
        }

        private async void ReadPower()
        {
            _power.IsEnabled = false;
            _powerNote.Text = "Revisando…";
            bool on = await Task.Run(() => PowerSettings.ButtonTurnsOffDisplay());
            _settingPower = true;
            _power.IsChecked = on;
            _settingPower = false;
            _power.IsEnabled = true;
            _powerNote.Text = on ? "Listo: el botón de encendido solo apaga la pantalla." : "";
        }

        private async void TogglePower()
        {
            if (_settingPower) return;
            bool want = _power.IsChecked == true;
            _power.IsEnabled = false;
            bool ok = await Task.Run(() => PowerSettings.SetButtonDisplayOff(want));
            _power.IsEnabled = true;
            if (!ok)
            {
                Toast.Show("Windows no permitió el cambio. Hazlo en Configuración › Sistema › Energía.");
                ReadPower();
                return;
            }
            Prefs.S.AskedPowerButton = true;
            Prefs.Save();
            _powerNote.Text = want ? "Listo: el botón de encendido solo apaga la pantalla." : "El botón de encendido vuelve a suspender la tablet.";
        }

        /// <summary>Últimas líneas del registro (para mandar foto si algo falla).</summary>
        private void ShowLog()
        {
            string text;
            try
            {
                using (var fs = new System.IO.FileStream(Paths.File("log.txt"), System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite | System.IO.FileShare.Delete))
                using (var sr = new System.IO.StreamReader(fs))
                {
                    var lines = sr.ReadToEnd().Replace("\r", "").Split('\n');
                    int from = Math.Max(0, lines.Length - 90);
                    text = string.Join("\n", lines, from, lines.Length - from).Trim();
                }
            }
            catch (Exception e) { text = "No se pudo leer el registro: " + e.Message; }
            var root = new DockPanel { Margin = new Thickness(20, 12, 20, 8) };
            var head = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var t = Ui.T("Registro (lo más nuevo abajo)", 18, "Text", true);
            t.VerticalAlignment = VerticalAlignment.Center;
            head.Children.Add(t);
            var buttons = new StackPanel { Orientation = Orientation.Horizontal };
            var copy = Ui.Pill("Copiar", () =>
            {
                try { Clipboard.SetText(text); Toast.Show("Registro copiado"); } catch { Toast.Show("No se pudo copiar"); }
            }, false, G.Link);
            copy.Margin = new Thickness(0, 0, 8, 0);
            buttons.Children.Add(copy);
            buttons.Children.Add(Ui.Pill("Cerrar", Sheet.Close));
            Grid.SetColumn(buttons, 1);
            head.Children.Add(buttons);
            DockPanel.SetDock(head, Dock.Top);
            root.Children.Add(head);
            var body = new TextBlock
            {
                Text = text,
                FontFamily = new FontFamily("Cascadia Mono, Consolas"),
                FontSize = 12,
                Foreground = Ui.B("Text2"),
                TextWrapping = TextWrapping.Wrap
            };
            var sv = Ui.Scroll(body);
            root.Children.Add(sv);
            Sheet.Show(root, 980);
            sv.Dispatcher.BeginInvoke(new Action(() => sv.ScrollToEnd()), System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void ShowHidden()
        {
            if (Library.HiddenSongs.Count == 0) { Toast.Show("No tienes canciones ocultas"); return; }
            var items = new List<Opt>();
            foreach (string key in Library.HiddenSongs)
            {
                string k = key;
                string label = k.Replace("|", " · ");
                items.Add(new Opt(G.Hide, label, () =>
                {
                    Library.Unhide(k);
                    Toast.Show("Ya puede volver a salir");
                    OnShow();
                }));
            }
            Sheet.Menu("Canciones ocultas", "Toca una para que vuelva a salir", null, items);
        }
    }
}
