using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>Biblioteca: carpetas, recientes, descargas y artistas.</summary>
    public sealed class LibraryPage : Page
    {
        public override string Tab => "library";

        private readonly StackPanel _body = new StackPanel();
        private readonly StackPanel _content = new StackPanel();
        private readonly ScrollViewer _scroll;
        private readonly Button[] _chips = new Button[4];
        private SongList _list;
        private int _builtVersion = -1, _builtTab = -1, _builtDownloads = -1;

        public LibraryPage()
        {
            var head = new Grid();
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.Children.Add(Ui.H("Tu biblioteca", 30));
            var add = Ui.Pill("Nueva carpeta", NewFolder, false, G.Add);
            Grid.SetColumn(add, 1);
            head.Children.Add(add);
            _body.Children.Add(head);

            var chips = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 18, 0, 6) };
            string[] names = { "Carpetas", "Recientes", "Descargas", "Artistas" };
            for (int i = 0; i < 4; i++)
            {
                int k = i;
                _chips[i] = Ui.Chip(names[i], Prefs.S.LibraryTab == i, () =>
                {
                    Prefs.S.LibraryTab = k;
                    Prefs.Save();
                    Build(true);
                });
                chips.Children.Add(_chips[i]);
            }
            _body.Children.Add(Ui.HScroll(chips));
            _body.Children.Add(_content);
            _body.Children.Add(Ui.Space(30));
            _scroll = Ui.Scroll(_body);
            Ui.NearBottom(_scroll, () => _list?.More());
            Children.Add(_scroll);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                _body.Margin = new Thickness(side, 20, side, 10);
            };
            Library.Changed += () => { if (IsLoaded) Build(false); };
            Downloads.Changed += () => { if (IsLoaded && Prefs.S.LibraryTab == 2) Build(false); };
        }

        public override void OnShow() => Build(false);

        private void NewFolder()
        {
            Sheet.Input("Nueva carpeta", "Nombre de la carpeta", "", "Crear", name =>
            {
                var f = Library.CreateFolder(name);
                if (f != null) Toast.Show("Carpeta creada");
            });
        }

        private void Build(bool force)
        {
            int tab = Math.Max(0, Math.Min(3, Prefs.S.LibraryTab));
            int dl = Downloads.Count * 1000 + Downloads.Pending;
            if (!force && _builtVersion == Library.Version && _builtTab == tab && (tab != 2 || _builtDownloads == dl)) return;
            _builtVersion = Library.Version;
            _builtTab = tab;
            _builtDownloads = dl;
            for (int i = 0; i < 4; i++) Ui.SetChip(_chips[i], i == tab);
            _content.Children.Clear();
            _list = null;
            if (tab == 0) BuildFolders();
            else if (tab == 1) BuildRecent();
            else if (tab == 2) BuildDownloads();
            else BuildArtists();
        }

        // ------------------------------------------------------------ carpetas

        private void BuildFolders()
        {
            var wrap = new WrapPanel { Margin = new Thickness(0, 14, 0, 0) };
            wrap.Children.Add(FolderCard("Me gusta", Tx.Count(Library.Favorites.Count, "canción", "canciones"), null, true, () => Main.Go(new LikedPage())));
            foreach (var f in Library.Folders)
            {
                var folder = f;
                string sub = Tx.Count(folder.Songs.Count, "canción", "canciones") + (Library.AutoFolders.Contains(folder.Name) ? " · se descarga" : "");
                wrap.Children.Add(FolderCard(folder.Name, sub, folder.Songs.FirstOrDefault()?.Image, false, () => Main.Go(ListPage.ForFolder(folder))));
            }
            _content.Children.Add(wrap);
            if (Library.Folders.Count == 0)
            {
                var t = Ui.T("Crea carpetas para guardar tus canciones como en el teléfono (también se sincronizan).", 14, "Muted", false, true);
                t.Margin = new Thickness(4, 10, 0, 0);
                _content.Children.Add(t);
            }
        }

        private FrameworkElement FolderCard(string name, string sub, string art, bool liked, Action tap)
        {
            var sp = new StackPanel { Width = 176, Margin = new Thickness(0, 0, 18, 22), Background = Brushes.Transparent, Cursor = Cursors.Hand };
            if (liked)
            {
                sp.Children.Add(new Border
                {
                    Width = 176,
                    Height = 176,
                    CornerRadius = new CornerRadius(12),
                    Background = new LinearGradientBrush(Color.FromRgb(0xFF, 0xCF, 0x4A), Color.FromRgb(0x9A, 0x4B, 0x1A), 45),
                    Child = Ui.Icon(G.HeartFill, 54, "OnGold")
                });
            }
            else if (string.IsNullOrEmpty(art))
            {
                sp.Children.Add(new Border { Width = 176, Height = 176, CornerRadius = new CornerRadius(12), Background = Ui.B("CardHi"), Child = Ui.Icon(G.Folder, 48, "Muted2") });
            }
            else sp.Children.Add(Ui.Cover(art, 176, 12, 300));
            var t = Ui.T(name, 15, "Text", true);
            t.Margin = new Thickness(2, 10, 2, 0);
            sp.Children.Add(t);
            var s = Ui.T(sub, 13, "Muted");
            s.Margin = new Thickness(2, 2, 2, 0);
            sp.Children.Add(s);
            Ui.Tap(sp, tap);
            return sp;
        }

        // ------------------------------------------------------------ recientes

        private void BuildRecent()
        {
            var recent = Library.Recent.ToList();
            var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 14, 0, 10) };
            if (recent.Count > 0)
            {
                var play = Ui.Pill("Reproducir", () => Engine.PlayList(recent, 0, "Escuchado recientemente"), true, G.Play);
                play.Margin = new Thickness(0, 0, 10, 0);
                bar.Children.Add(play);
                bar.Children.Add(Ui.Pill("Borrar historial", () => Sheet.Confirm("¿Borrar historial?", "Se borra lo escuchado recientemente en todos tus dispositivos.", "Borrar", Library.ClearRecent), false, G.Delete));
            }
            _content.Children.Add(bar);
            if (recent.Count == 0)
            {
                _content.Children.Add(Ui.T("Aquí aparecerá lo último que escuches.", 14, "Muted"));
                return;
            }
            _list = new SongList(recent, "Escuchado recientemente");
            _content.Children.Add(_list);
        }

        // ------------------------------------------------------------ descargas

        private void BuildDownloads()
        {
            var songs = Downloads.All();
            var card = new StackPanel { Margin = new Thickness(0, 14, 0, 12) };
            double mb = Downloads.Bytes() / 1048576.0;
            card.Children.Add(Ui.T(Tx.Count(songs.Count, "canción descargada", "canciones descargadas") + " · " + mb.ToString("0", CultureInfo.InvariantCulture) + " MB", 15, "Text", true));
            var where = Ui.T("Se guardan en Música › P Music y suenan aunque no tengas internet.", 13, "Muted", false, true);
            where.Margin = new Thickness(0, 4, 0, 0);
            card.Children.Add(where);
            int pending = Downloads.Pending;
            if (pending > 0)
            {
                var p = Ui.T("Descargando " + Tx.Count(pending, "canción", "canciones") + "…", 13, "Gold", true);
                p.Margin = new Thickness(0, 6, 0, 0);
                card.Children.Add(p);
            }
            var bar = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) };
            if (songs.Count > 0)
            {
                var play = Ui.Pill("Reproducir", () => Engine.PlayList(songs, 0, "Descargas"), true, G.Play);
                play.Margin = new Thickness(0, 0, 10, 8);
                bar.Children.Add(play);
                var sh = Ui.Pill("Aleatorio", () => Engine.PlayList(songs, 0, "Descargas", true), false, G.Shuffle);
                sh.Margin = new Thickness(0, 0, 10, 8);
                bar.Children.Add(sh);
            }
            var open = Ui.Pill("Abrir carpeta", () =>
            {
                try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + Paths.Downloads() + "\"") { UseShellExecute = true }); }
                catch { Toast.Show("No se pudo abrir la carpeta"); }
            }, false, G.Folder);
            open.Margin = new Thickness(0, 0, 10, 8);
            bar.Children.Add(open);
            if (pending > 0)
            {
                var stop = Ui.Pill("Cancelar pendientes", Downloads.CancelPending, false, G.Close);
                stop.Margin = new Thickness(0, 0, 10, 8);
                bar.Children.Add(stop);
            }
            card.Children.Add(bar);
            _content.Children.Add(card);
            if (songs.Count == 0)
            {
                _content.Children.Add(Ui.T("Usa “Descargar” en los tres puntitos de una canción, o activa la descarga en Me gusta o en una carpeta.", 14, "Muted", false, true));
                return;
            }
            _list = new SongList(songs, "Descargas");
            _content.Children.Add(_list);
        }

        // ------------------------------------------------------------ artistas

        private void BuildArtists()
        {
            var followed = Library.FollowedArtists.ToList();
            var top = Library.TopArtists(24).Where(a => !followed.Any(f => Tx.SameArtist(f, a))).ToList();
            if (followed.Count > 0)
            {
                _content.Children.Add(Ui.Section("Artistas que sigues"));
                foreach (var a in followed) _content.Children.Add(ArtistRow(a, true));
            }
            if (top.Count > 0)
            {
                _content.Children.Add(Ui.Section("Los que más escuchas"));
                foreach (var a in top) _content.Children.Add(ArtistRow(a, false));
            }
            if (followed.Count == 0 && top.Count == 0)
            {
                var t = Ui.T("Cuando escuches música aparecerán aquí tus artistas.", 14, "Muted");
                t.Margin = new Thickness(4, 16, 0, 0);
                _content.Children.Add(t);
            }
        }

        private FrameworkElement ArtistRow(string name, bool following)
        {
            var row = new Border { Height = 72, CornerRadius = new CornerRadius(12), Padding = new Thickness(8, 0, 8, 0), Background = Brushes.Transparent, Cursor = Cursors.Hand };
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            string art = Library.Favorites.Concat(Library.Recent).FirstOrDefault(s => Tx.SameArtist(s.Artist, name))?.Image;
            var c = Ui.Cover(art, 56, 28, 120);
            c.VerticalAlignment = VerticalAlignment.Center;
            g.Children.Add(c);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(14, 0, 10, 0) };
            sp.Children.Add(Ui.T(name, 16, "Text", true));
            sp.Children.Add(Ui.T(following ? "Siguiendo" : "Artista", 13, following ? "Gold" : "Muted"));
            Grid.SetColumn(sp, 1);
            g.Children.Add(sp);
            var mix = Ui.IconBtn(G.Radio, () => Main.Go(ListPage.Mix(name)), "Mix de " + name, 46, 18);
            Grid.SetColumn(mix, 2);
            g.Children.Add(mix);
            row.Child = g;
            Ui.Hover(row);
            Ui.Tap(row, () => Main.Go(ListPage.Artist(name)));
            return row;
        }
    }
}
