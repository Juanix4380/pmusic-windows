using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>Inicio: saludo, accesos rápidos, tops, mixes para ti, Top México, Me gusta y recientes.</summary>
    public sealed class HomePage : Page
    {
        public override string Tab => "home";

        public static readonly string[][] ChartsList =
        {
            new[] { "Top 100 canciones México", "Top México", "#b0306a" },
            new[] { "Top 100 canciones global", "Top Global", "#3f4f8a" },
            new[] { "En tendencia México música", "En tendencia", "#8c5a1f" },
            new[] { "Virales México", "Lo más viral", "#1f7a5a" },
            new[] { "Lo nuevo regional mexicano", "Lo nuevo · Regional", "#9a4b1a" },
            new[] { "Novedades urbano latino", "Lo nuevo · Urbano", "#5b2f8c" },
            new[] { "Novedades pop latino", "Lo nuevo · Pop", "#2f5f7a" },
            new[] { "Estrenos corridos", "Estrenos · Corridos", "#7a5a1f" }
        };

        private static readonly string[] Moods = { "🔥 Estrenos", "Corridos", "Regional mexicano", "Banda", "Cumbias", "Pop", "Rock", "Románticas", "Para entrenar", "Para relajarte" };
        private static readonly string[] MixColors = { "#8c5a1f", "#5b2f8c", "#1f7a5a", "#b0306a", "#2f5f7a", "#9a4b1a", "#3f4f8a", "#7a5a1f" };

        private readonly StackPanel _body = new StackPanel();
        private readonly ScrollViewer _scroll;
        private readonly TextBlock _greeting;
        private readonly StackPanel _personal = new StackPanel();
        private readonly StackPanel _top = new StackPanel();
        private int _builtVersion = -1;
        private double _builtWidth;
        private bool _topLoaded;

        public HomePage()
        {
            var header = new Grid();
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var brand = new StackPanel { Orientation = Orientation.Horizontal };
            var logo = new Image { Source = Images.Asset("logo.png"), Width = 44, Height = 44 };
            RenderOptions.SetBitmapScalingMode(logo, BitmapScalingMode.HighQuality);
            brand.Children.Add(new Border { CornerRadius = new CornerRadius(10), ClipToBounds = true, Child = logo });
            var names = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 0, 0) };
            var t1 = Ui.T("PACHECO'S MUSIC", 19, "Gold", true);
            t1.FontWeight = FontWeights.Bold;
            names.Children.Add(t1);
            names.Children.Add(Ui.T("TU MÚSICA, TU ESTILO", 10, "Muted", true));
            brand.Children.Add(names);
            header.Children.Add(brand);
            var acct = AccountButton();
            Grid.SetColumn(acct, 1);
            header.Children.Add(acct);
            _body.Children.Add(header);

            _greeting = Ui.H(Ui.Greeting(), 30);
            _greeting.Margin = new Thickness(0, 26, 0, 14);
            _body.Children.Add(_greeting);

            var moods = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (string m in Moods)
            {
                string q = m.Replace("🔥 ", "");
                moods.Children.Add(Ui.Chip(m, false, () => Main.OpenSearch(q)));
            }
            _body.Children.Add(Ui.HScroll(moods));
            _body.Children.Add(_personal);

            _body.Children.Add(Ui.Section("Tops y lanzamientos", "Listas que se actualizan solas"));
            var charts = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var c in ChartsList)
            {
                var chart = c;
                charts.Children.Add(Cards.Tile(chart[1], chart[1].StartsWith("Top", StringComparison.Ordinal) ? "TOP" : "NUEVO", chart[2], 160, 160,
                    () => Main.Go(ListPage.Chart(chart[0], chart[1]))));
            }
            _body.Children.Add(Ui.HScroll(charts));
            _body.Children.Add(_top);
            _body.Children.Add(Ui.Space(30));

            _scroll = Ui.Scroll(_body);
            Children.Add(_scroll);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                _body.Margin = new Thickness(side, 18, side, 20);
                if (Math.Abs(ActualWidth - _builtWidth) > 120) { _builtVersion = -1; Rebuild(); }
            };
            Library.Changed += () => { if (IsLoaded) Rebuild(); };
        }

        private FrameworkElement AccountButton()
        {
            string name = Account.Current?.Username ?? "";
            string initial = name.Length > 0 ? name.Substring(0, 1).ToUpperInvariant() : "?";
            var circle = new Border
            {
                Width = 46,
                Height = 46,
                CornerRadius = new CornerRadius(23),
                Background = Ui.B("Gold"),
                Cursor = Cursors.Hand,
                ToolTip = "Tu cuenta y ajustes",
                Child = new TextBlock { Text = initial, FontSize = 19, FontWeight = FontWeights.Bold, Foreground = Ui.B("OnGold"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
            };
            Ui.Tap(circle, () => Main.Go(new AccountPage()));
            return circle;
        }

        public override void OnShow()
        {
            _greeting.Text = Ui.Greeting();
            Rebuild();
            if (!_topLoaded) LoadTop();
        }

        /// <summary>Lo personal (accesos, mixes, Me gusta, recientes) se rehace solo si cambió algo.</summary>
        private void Rebuild()
        {
            if (_builtVersion == Library.Version || ActualWidth <= 0) return;
            _builtVersion = Library.Version;
            _builtWidth = ActualWidth;
            _personal.Children.Clear();

            // accesos rápidos
            var quick = new UniformGrid { Columns = ActualWidth >= 900 ? 4 : 2, Margin = new Thickness(0, 22, 0, 0) };
            quick.Children.Add(QuickTile("Me gusta", null, true, () => Main.Go(new LikedPage())));
            foreach (var f in Library.Folders.Take(3))
            {
                var folder = f;
                quick.Children.Add(QuickTile(folder.Name, folder.Songs.FirstOrDefault()?.Image, false, () => Main.Go(ListPage.ForFolder(folder))));
            }
            var recent = Library.Recent.ToList();
            int slots = (quick.Columns == 4 ? 8 : 6) - quick.Children.Count;
            for (int i = 0; i < recent.Count && slots > 0; i++, slots--)
            {
                int idx = i;
                quick.Children.Add(QuickTile(recent[i].Title, recent[i].Image, false, () => Engine.PlayList(recent, idx, "Escuchado recientemente")));
            }
            _personal.Children.Add(quick);

            // mixes para ti
            var artists = Library.TopArtists(8);
            if (artists.Count > 0)
            {
                _personal.Children.Add(Ui.Section("Mixes para ti", "Hechos con lo que más escuchas"));
                var row = new StackPanel { Orientation = Orientation.Horizontal };
                for (int i = 0; i < artists.Count; i++)
                {
                    string a = artists[i];
                    string art = Library.Favorites.Concat(Library.Recent).FirstOrDefault(s => Tx.SameArtist(s.Artist, a))?.Image;
                    row.Children.Add(Cards.Tile("Mix de " + a, "MIX", MixColors[i % MixColors.Length], 170, 170, () => Main.Go(ListPage.Mix(a)), art));
                }
                _personal.Children.Add(Ui.HScroll(row));
            }

            // Me gusta
            if (Library.Favorites.Count > 0)
            {
                _personal.Children.Add(Ui.Section("Tus Me gusta", Tx.Count(Library.Favorites.Count, "canción", "canciones"), "Ver todo", () => Main.Go(new LikedPage())));
                var favs = Library.Favorites.ToList();
                var row = new StackPanel { Orientation = Orientation.Horizontal };
                for (int i = 0; i < Math.Min(16, favs.Count); i++)
                {
                    int idx = i;
                    row.Children.Add(Cards.ForSong(favs[i], 156, () => Engine.PlayList(favs, idx, "Me gusta")));
                }
                _personal.Children.Add(Ui.HScroll(row));
            }

            // recientes
            if (recent.Count > 0)
            {
                _personal.Children.Add(Ui.Section("Escuchado recientemente", null, "Ver todo",
                    () => Main.Go(ListPage.Static("Escuchado recientemente", Library.Recent.ToList(), "Lo último que sonó"))));
                var row = new StackPanel { Orientation = Orientation.Horizontal };
                for (int i = 0; i < Math.Min(16, recent.Count); i++)
                {
                    int idx = i;
                    row.Children.Add(Cards.ForSong(recent[i], 156, () => Engine.PlayList(recent, idx, "Escuchado recientemente")));
                }
                _personal.Children.Add(Ui.HScroll(row));
            }
        }

        private FrameworkElement QuickTile(string title, string art, bool liked, Action tap)
        {
            var b = new Border
            {
                Height = 64,
                CornerRadius = new CornerRadius(10),
                Background = Ui.B("CardHi"),
                Margin = new Thickness(0, 0, 10, 10),
                Cursor = Cursors.Hand
            };
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            if (liked)
            {
                var heart = new Border
                {
                    Width = 64,
                    Height = 64,
                    CornerRadius = new CornerRadius(10, 0, 0, 10),
                    Background = new LinearGradientBrush(Color.FromRgb(0xFF, 0xCF, 0x4A), Color.FromRgb(0x9A, 0x4B, 0x1A), 45),
                    Child = Ui.Icon(G.HeartFill, 26, "OnGold")
                };
                g.Children.Add(heart);
            }
            else
            {
                var c = Ui.Cover(art, 64, 10, 120);
                c.CornerRadius = new CornerRadius(10, 0, 0, 10);
                g.Children.Add(c);
            }
            var t = Ui.T(title, 14, "Text", true, true);
            t.MaxHeight = 40;
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(12, 0, 10, 0);
            Grid.SetColumn(t, 1);
            g.Children.Add(t);
            b.Child = g;
            Ui.Tap(b, tap);
            b.MouseEnter += (s, e) => b.Background = Ui.Hex("#FF2E2B26");
            b.MouseLeave += (s, e) => b.Background = Ui.B("CardHi");
            return b;
        }

        private async void LoadTop()
        {
            _topLoaded = true;
            var top = await Charts.TopMexico();
            if (top.Count == 0) { _topLoaded = false; return; }
            _top.Children.Clear();
            _top.Children.Add(Ui.Section("Top México", "Lo más escuchado hoy", "Ver todo", () => Main.Go(ListPage.Static("Top México", top, "Lo más escuchado hoy en México"))));
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            for (int i = 0; i < Math.Min(20, top.Count); i++)
            {
                int idx = i;
                var card = Cards.ForSong(top[i], 156, () => Engine.PlayList(top, idx, "Top México"));
                row.Children.Add(card);
            }
            _top.Children.Add(Ui.HScroll(row));
        }
    }
}
