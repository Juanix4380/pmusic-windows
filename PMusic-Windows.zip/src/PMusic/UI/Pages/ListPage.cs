using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI.Pages
{
    /// <summary>
    /// Una lista de canciones con encabezado grande: carpeta, top, mix de artista, artista o
    /// cualquier lista fija (recientes, Top México).
    /// </summary>
    public sealed class ListPage : Page
    {
        private readonly string _title;
        private string _subtitle;
        private readonly Func<Task<List<Song>>> _loader;
        private List<Song> _songs;
        private readonly Folder _folder;
        private readonly string _artist;
        private readonly bool _radio;
        private readonly string _kind;

        private readonly StackPanel _body = new StackPanel();
        private readonly ScrollViewer _scroll;
        private readonly Border _cover;
        private readonly TextBlock _titleText, _sub;
        private readonly WrapPanel _buttons = new WrapPanel();
        private readonly StackPanel _listHost = new StackPanel();
        private SongList _list;
        private int _builtVersion = -1;
        private bool _loading;

        private ListPage(string kind, string title, string subtitle, List<Song> songs, Func<Task<List<Song>>> loader, Folder folder, string artist, bool radio)
        {
            _kind = kind;
            _title = title;
            _subtitle = subtitle;
            _songs = songs;
            _loader = loader;
            _folder = folder;
            _artist = artist;
            _radio = radio;

            _body.Children.Add(TopBar("", Ui.IconBtn(G.More, MoreMenu, "Más opciones")));
            var head = new Grid { Margin = new Thickness(0, 6, 0, 0) };
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _cover = Ui.Cover("", 180, artist != null ? 90 : 14, 360);
            head.Children.Add(_cover);
            var info = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24, 0, 0, 0) };
            info.Children.Add(Ui.T(KindLabel(), 12, "Text2", true));
            _titleText = Ui.H(title, 36);
            _titleText.TextWrapping = TextWrapping.Wrap;
            _titleText.MaxHeight = 96;
            info.Children.Add(_titleText);
            _sub = Ui.T(subtitle ?? "", 14.5, "Muted", false, true);
            _sub.Margin = new Thickness(0, 6, 0, 14);
            info.Children.Add(_sub);
            info.Children.Add(_buttons);
            Grid.SetColumn(info, 1);
            head.Children.Add(info);
            var headHost = new Border { Margin = new Thickness(0, 0, 0, 18), Child = head };
            _body.Children.Add(headHost);
            _body.Children.Add(_listHost);
            _body.Children.Add(Ui.Space(30));
            _scroll = Ui.Scroll(_body);
            Ui.NearBottom(_scroll, () => _list?.More());
            Children.Add(_scroll);
            SizeChanged += (s, e) =>
            {
                double side = Side(ActualWidth);
                _body.Margin = new Thickness(side - 12, 0, side, 10);
                headHost.Margin = new Thickness(12, 0, 0, 18);
                _listHost.Margin = new Thickness(12, 0, 0, 0);
                double c = ActualWidth >= 800 ? 180 : 120;
                _cover.Width = _cover.Height = c;
                if (artist != null) _cover.CornerRadius = new CornerRadius(c / 2);
            };
            if (folder != null || kind == "recent" || artist != null)
            {
                Loaded += (s, e) => Library.Changed += OnLibrary;
                Unloaded += (s, e) => Library.Changed -= OnLibrary;
            }
        }

        private string KindLabel()
        {
            switch (_kind)
            {
                case "folder": return "CARPETA";
                case "chart": return "LISTA";
                case "mix": return "MIX";
                case "artist": return "ARTISTA";
                default: return "LISTA";
            }
        }

        // ------------------------------------------------------------ fábricas

        public static ListPage ForFolder(Folder f) =>
            new ListPage("folder", f.Name, "", f.Songs, null, f, null, false);

        public static ListPage Static(string title, List<Song> songs, string subtitle) =>
            new ListPage(title == "Escuchado recientemente" ? "recent" : "static", title, subtitle, songs, null, null, null, false);

        public static ListPage Chart(string query, string title) =>
            new ListPage("chart", title, "Se actualiza seguido", null, () => YtMusic.PlaylistByQuery(query), null, null, false);

        /// <summary>Canciones de un artista (las suyas primero).</summary>
        public static ListPage Artist(string name) =>
            new ListPage("artist", name, "", null, async () =>
            {
                var page = await YtMusic.Search(name);
                var list = page.Songs;
                if (page.HasMore && list.Count < 30)
                {
                    try { list.AddRange((await YtMusic.Search(name, page.Continuation)).Songs); } catch { }
                }
                var mine = list.Where(s => Tx.SameArtist(s.Artist, name) || Tx.Plain(s.Artist).Contains(Tx.Plain(name))).ToList();
                var rest = list.Where(s => !mine.Contains(s)).ToList();
                return mine.Concat(rest).GroupBy(s => s.Key).Select(g => g.First()).Where(s => !Library.IsHidden(s)).ToList();
            }, null, name, false);

        /// <summary>Mix de un artista: la radio de su canción más popular.</summary>
        public static ListPage Mix(string artist) =>
            new ListPage("mix", "Mix de " + artist, artist + " y artistas parecidos", null, async () =>
            {
                var page = await YtMusic.Search(artist);
                var seed = page.Songs.FirstOrDefault(s => Tx.SameArtist(s.Artist, artist)) ?? page.Songs.FirstOrDefault();
                if (seed == null) return new List<Song>();
                var radio = await YtMusic.Radio(seed.VideoId);
                var list = radio.Songs.Where(s => !Library.IsHidden(s)).ToList();
                if (radio.HasMore)
                {
                    try
                    {
                        var more = await YtMusic.Radio(seed.VideoId, radio.Continuation);
                        var keys = new HashSet<string>(list.Select(x => x.Key));
                        list.AddRange(more.Songs.Where(s => keys.Add(s.Key) && !Library.IsHidden(s)));
                    }
                    catch { }
                }
                if (list.Count == 0) list.Add(seed);
                return list;
            }, null, null, true);

        // ------------------------------------------------------------ mostrar

        public override void OnShow()
        {
            if (_songs == null && _loader != null) Load();
            else Build();
        }

        private void OnLibrary()
        {
            if (!IsLoaded || _builtVersion == Library.Version) return;
            if (_kind == "recent") _songs = Library.Recent.ToList();
            if (_folder != null && !Library.Folders.Contains(_folder)) { Main.Back(); return; }
            Build();
        }

        private async void Load()
        {
            if (_loading) return;
            _loading = true;
            _listHost.Children.Clear();
            _listHost.Children.Add(Ui.T("Cargando…", 15, "Muted"));
            try
            {
                _songs = await _loader();
            }
            catch (Exception e)
            {
                Log.Write("Lista " + _title + ": " + e.Message);
                _songs = null;
                _listHost.Children.Clear();
                var t = Ui.T("No se pudo cargar. Revisa tu conexión.", 15, "Muted");
                _listHost.Children.Add(t);
                var retry = Ui.Pill("Intentar otra vez", Load, false, G.Sync);
                retry.HorizontalAlignment = HorizontalAlignment.Left;
                retry.Margin = new Thickness(0, 12, 0, 0);
                _listHost.Children.Add(retry);
                return;
            }
            finally
            {
                _loading = false;
            }
            Build();
        }

        private void Build()
        {
            var songs = _songs ?? new List<Song>();
            _builtVersion = Library.Version;
            string art = songs.Select(s => s.Image).FirstOrDefault(i => !string.IsNullOrEmpty(i));
            Ui.SetCover(_cover, art, 360);
            if (_folder != null) _titleText.Text = _folder.Name;
            long secs = songs.Sum(s => s.Seconds);
            string count = Tx.Count(songs.Count, "canción", "canciones") + (secs > 0 ? " · " + Tx.Minutes(secs) : "");
            if (_kind == "folder")
                _sub.Text = count + (Library.AutoFolders.Contains(_folder.Name) ? " · se descarga para escuchar sin internet" : "");
            else
                _sub.Text = string.IsNullOrEmpty(_subtitle) ? count : _subtitle + " · " + count;

            _buttons.Children.Clear();
            if (songs.Count > 0)
            {
                var play = Ui.Pill("Reproducir", () => PlayAll(false), true, G.Play);
                play.Margin = new Thickness(0, 0, 10, 8);
                _buttons.Children.Add(play);
                var sh = Ui.Pill("Aleatorio", () => PlayAll(true), false, G.Shuffle);
                sh.Margin = new Thickness(0, 0, 10, 8);
                _buttons.Children.Add(sh);
            }
            if (_artist != null)
            {
                bool f = Library.IsFollowing(_artist);
                var follow = Ui.Pill(f ? "Siguiendo" : "Seguir", () =>
                {
                    bool now = Library.ToggleFollow(_artist);
                    Toast.Show(now ? "Siguiendo a " + _artist : "Ya no sigues a " + _artist);
                    Build();
                }, f, f ? G.Check : G.Add);
                follow.Margin = new Thickness(0, 0, 10, 8);
                _buttons.Children.Add(follow);
                var mix = Ui.Pill("Mix", () => Main.Go(Mix(_artist)), false, G.Radio);
                mix.Margin = new Thickness(0, 0, 10, 8);
                _buttons.Children.Add(mix);
            }

            _listHost.Children.Clear();
            _list = null;
            if (songs.Count == 0)
            {
                _listHost.Children.Add(Ui.T(_folder != null
                    ? "Esta carpeta está vacía. Usa “Agregar a una carpeta” en los tres puntitos de una canción."
                    : "No hay canciones aquí.", 15, "Muted", false, true));
                return;
            }
            string source = _kind == "mix" ? _title : _kind == "folder" ? "Carpeta · " + _folder.Name : _title;
            _list = new SongList(songs, source, _folder);
            _listHost.Children.Add(_list);
        }

        private void PlayAll(bool shuffle)
        {
            var songs = _songs ?? new List<Song>();
            if (songs.Count == 0) return;
            string source = _kind == "folder" ? "Carpeta · " + _folder.Name : _title;
            Engine.PlayList(songs, 0, source, shuffle);
        }

        // ------------------------------------------------------------ opciones

        private void MoreMenu()
        {
            var items = new List<Opt>();
            var songs = _songs ?? new List<Song>();
            if (songs.Count > 0)
            {
                items.Add(new Opt(G.Queue, "Agregar todo a la cola", () =>
                {
                    if (Engine.Current == null) Engine.PlayList(songs, 0, _title);
                    else
                    {
                        Engine.AddRange(songs);
                        Toast.Show(Tx.Count(songs.Count, "canción agregada", "canciones agregadas") + " a la cola");
                    }
                }));
                items.Add(new Opt(G.Download, "Descargar todo", () =>
                {
                    Downloads.EnqueueAll(songs);
                    Toast.Show("Descargando " + Tx.Count(songs.Count, "canción", "canciones") + "…");
                }));
            }
            if (_folder != null)
            {
                bool auto = Library.AutoFolders.Contains(_folder.Name);
                items.Add(new Opt(G.Download, auto ? "No descargar automáticamente" : "Descargar automáticamente lo nuevo", () =>
                {
                    Library.SetAutoFolder(_folder, !auto);
                    Toast.Show(!auto ? "Esta carpeta se descargará para escucharla sin internet" : "Descarga automática apagada");
                }));
                items.Add(new Opt(G.Edit, "Cambiar nombre", () => Sheet.Input("Cambiar nombre", "Nombre de la carpeta", _folder.Name, "Guardar", name =>
                {
                    if (!Library.RenameFolder(_folder, name)) Toast.Show("Ya existe una carpeta con ese nombre");
                })));
                items.Add(new Opt(G.Delete, "Borrar carpeta", () => Sheet.Confirm("¿Borrar “" + _folder.Name + "”?",
                    "Se borra en todos tus dispositivos. Las canciones no se borran de Me gusta ni de tus descargas.", "Borrar", () =>
                    {
                        Library.DeleteFolder(_folder);
                        Toast.Show("Carpeta borrada");
                    }), true));
            }
            if (_artist != null)
            {
                bool f = Library.IsFollowing(_artist);
                items.Add(new Opt(f ? G.Check : G.Add, f ? "Dejar de seguir" : "Seguir artista", () =>
                {
                    bool now = Library.ToggleFollow(_artist);
                    Toast.Show(now ? "Siguiendo a " + _artist : "Ya no sigues a " + _artist);
                    Build();
                }));
            }
            if (_loader != null)
                items.Add(new Opt(G.Sync, "Actualizar", () => { _songs = null; Load(); }));
            if (items.Count == 0) return;
            Sheet.Menu(_folder != null ? _folder.Name : _title, _sub.Text, _songs?.FirstOrDefault()?.Image, items);
        }
    }
}
