using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PMusic.Core;

namespace PMusic.UI.Pages
{
    /// <summary>Entrar con usuario y contraseña (la misma cuenta del teléfono).</summary>
    public sealed class LoginPage : Page
    {
        private readonly TextBox _user;
        private readonly PasswordBox _pass;
        private readonly TextBlock _msg;
        private readonly Button _go;
        private bool _busy;

        public LoginPage(string message = null)
        {
            Background = Ui.B("Bg");
            var glow = new Border
            {
                Background = new RadialGradientBrush(Color.FromArgb(0x40, 0xFF, 0xB0, 0x20), Color.FromArgb(0, 0, 0, 0))
                {
                    Center = new Point(0.5, 0.18),
                    GradientOrigin = new Point(0.5, 0.18),
                    RadiusX = 0.7,
                    RadiusY = 0.55
                },
                IsHitTestVisible = false
            };
            Children.Add(glow);

            var card = new StackPanel { Width = 440, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(20) };
            var logo = new Image { Source = Images.Asset("logo.png"), Width = 150, Height = 150, HorizontalAlignment = HorizontalAlignment.Center };
            RenderOptions.SetBitmapScalingMode(logo, BitmapScalingMode.HighQuality);
            card.Children.Add(logo);
            var brand = Ui.T("PACHECO'S MUSIC", 24, "Gold", true);
            brand.FontWeight = FontWeights.Bold;
            brand.HorizontalAlignment = HorizontalAlignment.Center;
            brand.Margin = new Thickness(0, 8, 0, 0);
            card.Children.Add(brand);
            var sub = Ui.T("Inicia sesión con tu cuenta", 15, "Muted");
            sub.HorizontalAlignment = HorizontalAlignment.Center;
            sub.Margin = new Thickness(0, 6, 0, 26);
            card.Children.Add(sub);

            _user = new TextBox { Style = Ui.S("Field"), MaxLength = 80 };
            card.Children.Add(WithHint(_user, "Usuario", out _));
            card.Children.Add(Ui.Space(14));
            _pass = new PasswordBox { Style = Ui.S("SecretField"), MaxLength = 80 };
            TextBlock passHint;
            var passHost = WithHint(_pass, "Contraseña", out passHint);
            _pass.PasswordChanged += (s, e) => passHint.Visibility = _pass.Password.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            card.Children.Add(passHost);

            _msg = Ui.T(message ?? "", 14, "Gold", false, true);
            _msg.Margin = new Thickness(6, 14, 6, 0);
            _msg.TextAlignment = TextAlignment.Center;
            _msg.Visibility = string.IsNullOrEmpty(message) ? Visibility.Collapsed : Visibility.Visible;
            card.Children.Add(_msg);

            _go = Ui.Pill("Entrar", Submit, true);
            _go.Height = 54;
            _go.FontSize = 17;
            _go.Margin = new Thickness(0, 22, 0, 0);
            card.Children.Add(_go);

            var note = Ui.T("Tu sesión de música no usa conexiones de TV.", 12.5, "Muted2", false, true);
            note.TextAlignment = TextAlignment.Center;
            note.Margin = new Thickness(0, 18, 0, 0);
            card.Children.Add(note);

            Children.Add(Ui.Scroll(card));

            _user.KeyDown += (s, e) => { if (e.Key == Key.Enter) { _pass.Focus(); e.Handled = true; } };
            _pass.KeyDown += (s, e) => { if (e.Key == Key.Enter) { Submit(); e.Handled = true; } };
        }

        private static Grid WithHint(Control box, string hint, out TextBlock hintText)
        {
            var g = new Grid();
            g.Children.Add(box);
            var t = Ui.T(hint, 16, "Muted2");
            t.IsHitTestVisible = false;
            t.VerticalAlignment = VerticalAlignment.Center;
            t.Margin = new Thickness(21, 0, 0, 0);
            g.Children.Add(t);
            if (box is TextBox tb) tb.TextChanged += (s, e) => t.Visibility = tb.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            hintText = t;
            return g;
        }

        public override void OnShow()
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => _user.Focus()));
        }

        private void Show(string text)
        {
            _msg.Text = text ?? "";
            _msg.Visibility = string.IsNullOrEmpty(text) ? Visibility.Collapsed : Visibility.Visible;
        }

        private void Busy(bool on)
        {
            _busy = on;
            _go.IsEnabled = !on;
            _go.Content = on ? "Verificando…" : "Entrar";
            _user.IsEnabled = !on;
            _pass.IsEnabled = !on;
        }

        private async void Submit()
        {
            if (_busy) return;
            string user = _user.Text.Trim(), pass = _pass.Password;
            if (user.Length == 0 || pass.Length == 0) { Show("Escribe tu usuario y contraseña."); return; }
            Show("");
            Busy(true);
            try
            {
                await Account.Login(user, pass);
                Main.EnterApp();
            }
            catch (AuthFailure f)
            {
                Busy(false);
                Show(f.Message);
                if (f.Unavailable) OfferAlternative(user, pass);
            }
            catch (Exception e)
            {
                Log.Error(e, "Login");
                Busy(false);
                Show("No fue posible conectar con el servicio de inicio de sesión.");
            }
        }

        /// <summary>El acceso alternativo no va cifrado: solo con el permiso de la persona.</summary>
        private void OfferAlternative(string user, string pass)
        {
            Sheet.Confirm("¿Intentar con el acceso alternativo?",
                "El servicio principal no respondió. Puedes intentar con el acceso alternativo, pero esa conexión no va cifrada " +
                "(tu usuario y contraseña viajan sin protección). La biblioteca no se sincronizará con el teléfono mientras uses este acceso.",
                "Intentar", async () =>
                {
                    Busy(true);
                    try
                    {
                        await Account.LoginAlternative(user, pass);
                        Main.EnterApp();
                    }
                    catch (AuthFailure f)
                    {
                        Busy(false);
                        Show(f.Message);
                    }
                    catch (Exception e)
                    {
                        Log.Error(e, "Login alternativo");
                        Busy(false);
                        Show("No se pudo conectar con el servidor alternativo.");
                    }
                }, "Ahora no");
        }
    }
}
