using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;

namespace PMusic.UI
{
    /// <summary>La barra de "sonando ahora" de abajo (toca para abrir el reproductor grande).</summary>
    public sealed class MiniPlayer : Border
    {
        private readonly Border _cover;
        private readonly TextBlock _title, _artist;
        private readonly Button _play, _heart;
        private readonly Border _bar;
        private readonly Grid _barHost;

        public MiniPlayer()
        {
            Margin = new Thickness(10, 0, 10, 8);
            CornerRadius = new CornerRadius(14);
            Background = Ui.Hex("#FF1C1A16");
            BorderBrush = Ui.Hex("#FF3A3326");
            BorderThickness = new Thickness(1);
            Height = 72;
            Visibility = Visibility.Collapsed;

            var root = new Grid();
            var g = new Grid { Margin = new Thickness(10, 0, 8, 0) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var tapArea = new Grid { Background = Brushes.Transparent, Cursor = Cursors.Hand };
            tapArea.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tapArea.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _cover = Ui.Cover("", 50, 8, 100);
            _cover.VerticalAlignment = VerticalAlignment.Center;
            tapArea.Children.Add(_cover);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 10, 0) };
            _title = Ui.T("", 15, "Text", true);
            _artist = Ui.T("", 13, "Muted");
            sp.Children.Add(_title);
            sp.Children.Add(_artist);
            Grid.SetColumn(sp, 1);
            tapArea.Children.Add(sp);
            Grid.SetColumnSpan(tapArea, 2);
            Ui.Tap(tapArea, () => MainWindow.Instance.OpenPlayer());
            g.Children.Add(tapArea);

            var buttons = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            _heart = Ui.IconBtn(G.Heart, () =>
            {
                var s = Engine.Current;
                if (s == null) return;
                bool now = Library.ToggleFavorite(s);
                Toast.Show(now ? "Agregada a Me gusta" : "Quitada de Me gusta");
            }, "Me gusta", 48, 19);
            buttons.Children.Add(_heart);
            buttons.Children.Add(Ui.IconBtn(G.Prev, Engine.Previous, "Anterior", 48, 19));
            _play = Ui.IconBtn(G.Play, Engine.Toggle, "Reproducir / pausar", 52, 24);
            buttons.Children.Add(_play);
            buttons.Children.Add(Ui.IconBtn(G.Next, () => Engine.Next(false), "Siguiente", 48, 19));
            Grid.SetColumn(buttons, 2);
            g.Children.Add(buttons);
            root.Children.Add(g);

            _barHost = new Grid { VerticalAlignment = VerticalAlignment.Bottom, Height = 3, Margin = new Thickness(14, 0, 14, 1), IsHitTestVisible = false };
            _barHost.Children.Add(new Border { Background = Ui.Hex("#22FFFFFF"), CornerRadius = new CornerRadius(2) });
            _bar = new Border { Background = Ui.B("Gold"), CornerRadius = new CornerRadius(2), HorizontalAlignment = HorizontalAlignment.Left, Width = 0 };
            _barHost.Children.Add(_bar);
            root.Children.Add(_barHost);
            Child = root;

            Engine.SongChanged += Paint;
            Engine.StateChanged += Paint;
            Library.Changed += Paint;
            UiThread.Every(500, Progress);
        }

        public void Paint()
        {
            var s = Engine.Current;
            Visibility = s == null || MainWindow.Instance == null || !MainWindow.Instance.ShellVisible ? Visibility.Collapsed : Visibility.Visible;
            if (s == null) return;
            _title.Text = s.Title;
            _artist.Text = Engine.Loading && !Engine.Playing ? Engine.LoadingText : s.Artist;
            Ui.SetCover(_cover, s.Image, 100);
            _play.Content = Engine.Playing ? G.Pause : G.Play;
            bool fav = Library.IsFavorite(s);
            _heart.Content = fav ? G.HeartFill : G.Heart;
            _heart.Foreground = Ui.B(fav ? "Gold" : "Text");
            _heart.Visibility = s.NeedsLookup ? Visibility.Collapsed : Visibility.Visible;
        }

        private void Progress()
        {
            if (Visibility != Visibility.Visible) return;
            if (Engine.Loading && !Engine.Playing) _artist.Text = Engine.LoadingText;
            double d = Engine.Duration, p = Engine.Position;
            double w = _barHost.ActualWidth;
            _bar.Width = d > 0 && w > 0 ? Math.Max(0, Math.Min(w, w * p / d)) : 0;
        }
    }
}
