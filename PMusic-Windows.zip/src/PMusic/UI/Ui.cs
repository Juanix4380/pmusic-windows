using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace PMusic.UI
{
    /// <summary>Íconos (Segoe Fluent / MDL2).</summary>
    public static class G
    {
        public const string Play = "";
        public const string Pause = "";
        public const string Prev = "";
        public const string Next = "";
        public const string Shuffle = "";
        public const string Repeat = "";
        public const string RepeatOne = "";
        public const string Heart = "";
        public const string HeartFill = "";
        public const string Home = "";
        public const string Search = "";
        public const string Library = "";
        public const string Folder = "";
        public const string Download = "";
        public const string Downloaded = "";
        public const string Delete = "";
        public const string More = "";
        public const string Add = "";
        public const string Back = "";
        public const string Down = "";
        public const string Volume = "";
        public const string Mute = "";
        public const string Account = "";
        public const string Settings = "";
        public const string Sync = "";
        public const string Recent = "";
        public const string Queue = "";
        public const string Close = "";
        public const string Music = "";
        public const string Audio = "";
        public const string Moon = "";
        public const string Power = "";
        public const string Radio = "";
        public const string Lyrics = "";
        public const string Edit = "";
        public const string Link = "";
        public const string Hide = "";
        public const string Person = "";
        public const string Up = "";
        public const string DownArrow = "";
        public const string Check = "";
        public const string Clear = "";
        public const string Info = "";
        public const string Logout = "";
    }

    /// <summary>Piezas de interfaz hechas en código (colores, textos, botones, portadas).</summary>
    public static class Ui
    {
        public static Brush B(string key) => (Brush)Application.Current.FindResource(key);
        public static FontFamily Font => (FontFamily)Application.Current.FindResource("Font");
        public static FontFamily Icons => (FontFamily)Application.Current.FindResource("Icons");
        public static Style S(string key) => (Style)Application.Current.FindResource(key);

        public static SolidColorBrush Hex(string hex)
        {
            var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
            b.Freeze();
            return b;
        }

        public static TextBlock T(string text, double size, string brush = "Text", bool bold = false, bool wrap = false)
        {
            var t = new TextBlock
            {
                Text = text ?? "",
                FontSize = size,
                Foreground = B(brush),
                FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal,
                TextTrimming = wrap ? TextTrimming.None : TextTrimming.CharacterEllipsis,
                TextWrapping = wrap ? TextWrapping.Wrap : TextWrapping.NoWrap
            };
            return t;
        }

        public static TextBlock H(string text, double size = 24)
        {
            var t = T(text, size, "Text", true);
            t.FontWeight = FontWeights.Bold;
            return t;
        }

        public static TextBlock Icon(string glyph, double size, string brush = "Text")
        {
            return new TextBlock
            {
                Text = glyph,
                FontFamily = Icons,
                FontSize = size,
                Foreground = B(brush),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
        }

        public static Button IconBtn(string glyph, Action click, string tip = null, double size = 48, double font = 20)
        {
            var b = new Button { Style = S("IconBtn"), Content = glyph, Width = size, Height = size, FontSize = font };
            if (tip != null) b.ToolTip = tip;
            if (click != null) b.Click += (s, e) => click();
            return b;
        }

        public static Button Pill(string text, Action click, bool gold = false, string glyph = null)
        {
            object content = text;
            if (glyph != null)
            {
                var sp = new StackPanel { Orientation = Orientation.Horizontal };
                var ic = new TextBlock { Text = glyph, FontFamily = Icons, FontSize = 16, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 10, 0) };
                sp.Children.Add(ic);
                sp.Children.Add(new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center });
                content = sp;
            }
            var b = new Button { Style = S(gold ? "GoldPill" : "Pill"), Content = content };
            if (click != null) b.Click += (s, e) => click();
            return b;
        }

        /// <summary>Chip de selección (categorías, filtros).</summary>
        public static Button Chip(string text, bool selected, Action click)
        {
            var b = new Button
            {
                Style = S("Pill"),
                Content = text,
                MinHeight = 40,
                FontSize = 14,
                Padding = new Thickness(18, 0, 18, 0),
                Margin = new Thickness(0, 0, 10, 0)
            };
            SetChip(b, selected);
            if (click != null) b.Click += (s, e) => click();
            return b;
        }

        public static void SetChip(Button b, bool selected)
        {
            b.Background = selected ? B("Gold") : B("CardHi");
            b.BorderBrush = selected ? B("Gold") : B("Stroke");
            b.Foreground = selected ? B("OnGold") : B("Text");
        }

        /// <summary>Portada cuadrada con esquinas redondeadas (nota musical mientras carga).</summary>
        public static Border Cover(string url, double size, double radius = 8, int decode = 0)
        {
            var ph = Icon(G.Music, Math.Max(14, size * 0.36), "Muted2");
            var b = new Border
            {
                Width = size,
                Height = size,
                CornerRadius = new CornerRadius(radius),
                Background = B("CardHi"),
                Child = ph
            };
            SetCover(b, url, decode > 0 ? decode : (int)Math.Min(600, Math.Max(64, size * 1.6)));
            return b;
        }

        public static void SetCover(Border b, string url, int decode)
        {
            var ph = b.Child as UIElement;
            if (string.IsNullOrWhiteSpace(url))
            {
                b.Tag = null;
                b.Background = B("CardHi");
                if (ph != null) ph.Visibility = Visibility.Visible;
                return;
            }
            if (Equals(b.Tag, url)) return;
            Images.LoadInto(b, ph, url, decode);
        }

        /// <summary>Toque o clic sin arrastrar (no se dispara al desplazar la lista con el dedo).</summary>
        public static void Tap(UIElement el, Action action)
        {
            Point start = new Point();
            bool down = false;
            el.PreviewMouseLeftButtonDown += (s, e) => { down = true; start = e.GetPosition(null); };
            el.MouseLeave += (s, e) => down = false;
            el.MouseLeftButtonUp += (s, e) =>
            {
                if (!down) return;
                down = false;
                var p = e.GetPosition(null);
                if (Math.Abs(p.X - start.X) > 12 || Math.Abs(p.Y - start.Y) > 12) return;
                if (e.OriginalSource is DependencyObject d && IsInsideButton(d, el)) return;
                e.Handled = true;
                action();
            };
        }

        private static bool IsInsideButton(DependencyObject d, UIElement root)
        {
            while (d != null && !ReferenceEquals(d, root))
            {
                if (d is ButtonBase || d is Slider || d is TextBox) return true;
                d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
            }
            return false;
        }

        /// <summary>Fondo suave al pasar el mouse.</summary>
        public static void Hover(Border b, Brush normal = null)
        {
            var hover = B("GoldSoft");
            b.MouseEnter += (s, e) => { if (e.StylusDevice == null) b.Background = Hex("#14FFFFFF"); };
            b.MouseLeave += (s, e) => b.Background = normal ?? Brushes.Transparent;
        }

        /// <summary>Lista vertical que se desplaza con el dedo (sin rebote de la ventana).</summary>
        public static ScrollViewer Scroll(UIElement content)
        {
            var sv = new ScrollViewer
            {
                Content = content,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalFirst,
                Focusable = false,
                CanContentScroll = false
            };
            sv.ManipulationBoundaryFeedback += (s, e) => e.Handled = true;
            return sv;
        }

        /// <summary>Fila horizontal que se desplaza con el dedo; la rueda del mouse sigue bajando la página.</summary>
        public static ScrollViewer HScroll(UIElement content)
        {
            var sv = new ScrollViewer
            {
                Content = content,
                VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
                PanningMode = PanningMode.HorizontalFirst,
                Focusable = false
            };
            sv.ManipulationBoundaryFeedback += (s, e) => e.Handled = true;
            // Si el dedo va hacia arriba o abajo sobre la fila, se desplaza la página completa.
            sv.AddHandler(UIElement.ManipulationDeltaEvent, new EventHandler<ManipulationDeltaEventArgs>((s, e) =>
            {
                var cum = e.CumulativeManipulation.Translation;
                if (Math.Abs(cum.Y) <= Math.Abs(cum.X)) return;
                var parent = FindParent<ScrollViewer>(VisualTreeHelper.GetParent(sv));
                if (parent != null) parent.ScrollToVerticalOffset(parent.VerticalOffset - e.DeltaManipulation.Translation.Y);
            }), true);
            sv.PreviewMouseWheel += (s, e) =>
            {
                if (Keyboard.Modifiers == ModifierKeys.Shift)
                {
                    sv.ScrollToHorizontalOffset(sv.HorizontalOffset - e.Delta);
                    e.Handled = true;
                    return;
                }
                e.Handled = true;
                var parent = FindParent<ScrollViewer>(VisualTreeHelper.GetParent(sv));
                if (parent != null)
                {
                    var args = new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta) { RoutedEvent = UIElement.MouseWheelEvent, Source = sv };
                    parent.RaiseEvent(args);
                }
            };
            return sv;
        }

        /// <summary>Al acercarse al final de la lista (para dibujar o pedir más).</summary>
        public static void NearBottom(ScrollViewer sv, Action a)
        {
            sv.ScrollChanged += (s, e) =>
            {
                if (sv.ScrollableHeight - sv.VerticalOffset < 900) a();
            };
        }

        public static T FindParent<T>(DependencyObject d) where T : DependencyObject
        {
            while (d != null)
            {
                if (d is T t) return t;
                d = VisualTreeHelper.GetParent(d);
            }
            return null;
        }

        public static Border Card(UIElement child, double radius = 14, string brush = "Card", Thickness? padding = null)
        {
            return new Border
            {
                Background = B(brush),
                CornerRadius = new CornerRadius(radius),
                Padding = padding ?? new Thickness(16),
                Child = child
            };
        }

        public static FrameworkElement Space(double h) => new Border { Height = h };

        /// <summary>Encabezado de sección ("Escuchado recientemente" + "Ver todo").</summary>
        public static FrameworkElement Section(string title, string subtitle = null, string action = null, Action onAction = null)
        {
            var g = new Grid { Margin = new Thickness(0, 26, 0, 12) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var sp = new StackPanel();
            sp.Children.Add(H(title, 22));
            if (!string.IsNullOrEmpty(subtitle))
            {
                var st = T(subtitle, 13, "Muted");
                st.Margin = new Thickness(0, 2, 0, 0);
                sp.Children.Add(st);
            }
            g.Children.Add(sp);
            if (action != null && onAction != null)
            {
                var b = new Button { Style = S("IconBtn"), Width = double.NaN, Height = 40, FontFamily = Font, FontSize = 14, FontWeight = FontWeights.SemiBold, Content = action, Foreground = B("Muted"), Padding = new Thickness(14, 0, 14, 0) };
                b.Click += (s, e) => onAction();
                Grid.SetColumn(b, 1);
                b.VerticalAlignment = VerticalAlignment.Bottom;
                g.Children.Add(b);
            }
            return g;
        }

        public static string Greeting()
        {
            int h = DateTime.Now.Hour;
            if (h < 5) return "Buenas noches";
            if (h < 12) return "Buenos días";
            if (h < 19) return "Buenas tardes";
            return "Buenas noches";
        }
    }
}
