using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using PMusic.Core;
using PMusic.Player;
using PMusic.UI.Pages;

namespace PMusic.UI
{
    /// <summary>Opciones de una canción (los tres puntitos o dejar presionado).</summary>
    public static class SongMenu
    {
        public static void Show(Song s, Folder folder = null)
        {
            if (s == null) return;
            var items = new List<Opt>
            {
                new Opt(G.Next, "Reproducir a continuación", () => Engine.PlayNext(s)),
                new Opt(G.Queue, "Agregar a la cola", () => Engine.AddToQueue(s)),
                new Opt(G.Radio, "Mix de canciones parecidas", () => Engine.StartRadio(s))
            };
            if (!s.NeedsLookup)
            {
                bool fav = Library.IsFavorite(s);
                items.Add(new Opt(fav ? G.HeartFill : G.Heart, fav ? "Quitar de Me gusta" : "Agregar a Me gusta", () =>
                {
                    bool now = Library.ToggleFavorite(s);
                    Toast.Show(now ? "Agregada a Me gusta" : "Quitada de Me gusta");
                }));
                items.Add(new Opt(G.Folder, "Agregar a una carpeta", () => PickFolder(s)));
            }
            if (folder != null)
                items.Add(new Opt(G.Delete, "Quitar de " + folder.Name, () =>
                {
                    Library.RemoveFromFolder(folder, s);
                    Toast.Show("Quitada de " + folder.Name);
                }));
            if (Downloads.Has(s))
                items.Add(new Opt(G.Delete, "Borrar descarga", () => { Downloads.Remove(s); Toast.Show("Descarga borrada"); }));
            else if (s.VideoId != null)
                items.Add(new Opt(G.Download, Downloads.IsQueued(s) ? "Descargando…" : "Descargar (escuchar sin internet)", () =>
                {
                    Downloads.Enqueue(s);
                    Toast.Show("Descargando en Música\\P Music…");
                }));
            string artist = Tx.MainArtist(s.Artist);
            if (artist.Length > 1)
                items.Add(new Opt(G.Person, "Ver artista · " + artist, () => MainWindow.Instance.Go(ListPage.Artist(artist))));
            if (s.VideoId != null)
                items.Add(new Opt(G.Link, "Copiar enlace", () =>
                {
                    try { Clipboard.SetText(Yt.MusicUrl(s.VideoId)); Toast.Show("Enlace copiado"); }
                    catch { Toast.Show("No se pudo copiar"); }
                }));
            items.Add(new Opt(G.Hide, "Ocultar esta canción", () =>
            {
                Library.Hide(s);
                Toast.Show("Ya no saldrá en tus mixes");
            }, true));
            Sheet.Menu(s.Title, s.Artist, s.Image, items);
        }

        public static void PickFolder(Song s)
        {
            var items = new List<Opt>
            {
                new Opt(G.Add, "Nueva carpeta", () => Sheet.Input("Nueva carpeta", "Nombre de la carpeta", "", "Crear", name =>
                {
                    var f = Library.CreateFolder(name);
                    if (f == null) return;
                    Library.AddToFolder(f, s);
                    Toast.Show("Agregada a " + f.Name);
                }))
            };
            foreach (var f in Library.Folders)
            {
                var folder = f;
                items.Add(new Opt(G.Folder, folder.Name + "  ·  " + Tx.Count(folder.Songs.Count, "canción", "canciones"), () =>
                {
                    bool ok = Library.AddToFolder(folder, s);
                    Toast.Show(ok ? "Agregada a " + folder.Name : "Ya estaba en " + folder.Name);
                }));
            }
            Sheet.Menu("Agregar a una carpeta", s.Title, s.Image, items);
        }
    }

    /// <summary>Una fila de canción: portada, título, artista, me gusta y más opciones.</summary>
    public sealed class SongRow : Border
    {
        public readonly Song Song;
        public readonly int Index;
        private readonly TextBlock _title;
        private readonly TextBlock _playing;
        private readonly Button _heart;
        private readonly TextBlock _dl;

        public SongRow(Song s, int index, Action<int> play, Folder folder)
        {
            Song = s;
            Index = index;
            Height = 66;
            CornerRadius = new CornerRadius(10);
            Padding = new Thickness(8, 0, 2, 0);
            Background = Brushes.Transparent;
            Cursor = Cursors.Hand;
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var coverHost = new Grid { VerticalAlignment = VerticalAlignment.Center };
            coverHost.Children.Add(Ui.Cover(s.Image, 50, 6, 100));
            _playing = Ui.Icon(G.Audio, 20, "Gold");
            var shade = new Border { Width = 50, Height = 50, CornerRadius = new CornerRadius(6), Background = Ui.Hex("#99000000"), Child = _playing };
            coverHost.Children.Add(shade);
            g.Children.Add(coverHost);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(14, 0, 10, 0) };
            _title = Ui.T(s.Title, 15.5, "Text", true);
            var sub = Ui.T(s.Subtitle, 13, "Muted");
            sub.Margin = new Thickness(0, 2, 0, 0);
            sp.Children.Add(_title);
            sp.Children.Add(sub);
            Grid.SetColumn(sp, 1);
            g.Children.Add(sp);
            _dl = Ui.Icon(G.Download, 15, "Gold");
            _dl.Margin = new Thickness(0, 0, 8, 0);
            _dl.ToolTip = "Descargada";
            Grid.SetColumn(_dl, 2);
            g.Children.Add(_dl);
            _heart = Ui.IconBtn(G.Heart, () =>
            {
                bool now = Library.ToggleFavorite(Song);
                Toast.Show(now ? "Agregada a Me gusta" : "Quitada de Me gusta");
            }, "Me gusta", 46, 18);
            _heart.Visibility = s.NeedsLookup ? Visibility.Collapsed : Visibility.Visible;
            Grid.SetColumn(_heart, 3);
            g.Children.Add(_heart);
            var more = Ui.IconBtn(G.More, () => SongMenu.Show(Song, folder), "Más opciones", 46, 18);
            Grid.SetColumn(more, 4);
            g.Children.Add(more);
            Child = g;
            Ui.Hover(this);
            Ui.Tap(this, () => play(Index));
            MouseRightButtonUp += (o, e) => { e.Handled = true; SongMenu.Show(Song, folder); };
            Refresh();
        }

        public void Refresh()
        {
            var cur = Engine.Current;
            bool isCur = cur != null && cur.Key == Song.Key;
            _title.Foreground = Ui.B(isCur ? "Gold" : "Text");
            if (_playing.Parent is Border shade) shade.Visibility = isCur ? Visibility.Visible : Visibility.Collapsed;
            bool fav = Library.IsFavorite(Song);
            _heart.Content = fav ? G.HeartFill : G.Heart;
            _heart.Foreground = Ui.B(fav ? "Gold" : "Muted");
            _dl.Visibility = Downloads.Has(Song) ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    /// <summary>
    /// Lista de canciones que se va dibujando por partes al bajar (fluida aunque tengas cientos de
    /// Me gusta) y que puede pedir más resultados al llegar al final.
    /// </summary>
    public sealed class SongList : StackPanel
    {
        private readonly List<Song> _songs;
        private readonly string _source;
        private readonly Folder _folder;
        private readonly List<SongRow> _rows = new List<SongRow>();
        private int _shown;
        private const int PageSize = 50;
        private bool _loadingMore;

        /// <summary>Pide la siguiente página (búsquedas). null = no hay más.</summary>
        public Func<Task<SongPage>> LoadMore;
        public Action<List<Song>, int> PlayOverride;

        public SongList(List<Song> songs, string source, Folder folder = null)
        {
            _songs = songs ?? new List<Song>();
            _source = source;
            _folder = folder;
            Loaded += (s, e) =>
            {
                Engine.SongChanged += Refresh;
                Library.Changed += Refresh;
                Downloads.Changed += Refresh;
                Refresh();
            };
            Unloaded += (s, e) =>
            {
                Engine.SongChanged -= Refresh;
                Library.Changed -= Refresh;
                Downloads.Changed -= Refresh;
            };
            More();
        }

        public List<Song> Songs => _songs;

        public void More()
        {
            if (!IsLoaded && _shown > 0) return;
            if (_shown < _songs.Count)
            {
                int end = Math.Min(_songs.Count, _shown + PageSize);
                for (int i = _shown; i < end; i++)
                {
                    var r = new SongRow(_songs[i], i, Play, _folder);
                    _rows.Add(r);
                    Children.Add(r);
                }
                _shown = end;
                return;
            }
            if (LoadMore != null && !_loadingMore) FetchMore();
        }

        private async void FetchMore()
        {
            _loadingMore = true;
            try
            {
                var page = await LoadMore();
                if (page != null && page.Songs.Count > 0)
                {
                    var keys = new HashSet<string>(_songs.Select(x => x.Key));
                    foreach (var s in page.Songs) if (keys.Add(s.Key)) _songs.Add(s);
                    More();
                }
                if (page == null || !page.HasMore) LoadMore = null;
            }
            catch (Exception e)
            {
                Log.Write("Más resultados: " + e.Message);
                LoadMore = null;
            }
            finally
            {
                _loadingMore = false;
            }
        }

        private void Play(int i)
        {
            if (PlayOverride != null) PlayOverride(_songs, i);
            else Engine.PlayList(_songs, i, _source);
        }

        private void Refresh()
        {
            foreach (var r in _rows) r.Refresh();
        }
    }

    /// <summary>Tarjetas de las filas horizontales del inicio.</summary>
    public static class Cards
    {
        public static FrameworkElement ForSong(Song s, double size, Action tap)
        {
            var sp = new StackPanel { Width = size, Margin = new Thickness(0, 0, 16, 0), Background = Brushes.Transparent, Cursor = Cursors.Hand };
            sp.Children.Add(Ui.Cover(s.Image, size, 10, (int)Math.Min(400, size * 1.6)));
            var t = Ui.T(s.Title, 14.5, "Text", true);
            t.Margin = new Thickness(2, 9, 2, 0);
            sp.Children.Add(t);
            var a = Ui.T(s.Artist, 13, "Muted");
            a.Margin = new Thickness(2, 2, 2, 0);
            sp.Children.Add(a);
            Ui.Tap(sp, tap);
            sp.MouseRightButtonUp += (o, e) => { e.Handled = true; SongMenu.Show(s); };
            return sp;
        }

        /// <summary>Mosaico de color con texto (tops, géneros, mixes).</summary>
        public static FrameworkElement Tile(string label, string top, string color, double w, double h, Action tap, string art = null)
        {
            var c = (Color)ColorConverter.ConvertFromString(color);
            var brush = new LinearGradientBrush(c, Color.FromRgb(17, 16, 16), new Point(0, 0), new Point(1, 1));
            brush.Freeze();
            var g = new Grid { Width = w, Height = h, Margin = new Thickness(0, 0, 14, 14), Cursor = Cursors.Hand };
            var bg = new Border { CornerRadius = new CornerRadius(12), Background = brush };
            g.Children.Add(bg);
            if (!string.IsNullOrEmpty(art))
            {
                var cov = Ui.Cover(art, Math.Min(w, h) * 0.5, 8);
                cov.HorizontalAlignment = HorizontalAlignment.Right;
                cov.VerticalAlignment = VerticalAlignment.Bottom;
                cov.Margin = new Thickness(0, 0, 10, 10);
                cov.RenderTransform = new RotateTransform(14, cov.Width / 2, cov.Height / 2);
                g.Children.Add(cov);
            }
            if (!string.IsNullOrEmpty(top))
            {
                var tt = Ui.T(top, 11, "Gold", true);
                tt.Margin = new Thickness(14, 12, 10, 0);
                tt.VerticalAlignment = VerticalAlignment.Top;
                g.Children.Add(tt);
            }
            var name = Ui.T(label, h >= 140 ? 18 : 16, "Text", true, true);
            name.FontWeight = FontWeights.Bold;
            name.Margin = new Thickness(14, 0, 12, 12);
            name.VerticalAlignment = VerticalAlignment.Bottom;
            name.MaxWidth = string.IsNullOrEmpty(art) ? w - 26 : w * 0.55;
            name.HorizontalAlignment = HorizontalAlignment.Left;
            g.Children.Add(name);
            Ui.Tap(g, tap);
            return g;
        }
    }
}
