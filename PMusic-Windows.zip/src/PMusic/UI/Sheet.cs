using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace PMusic.UI
{
    public sealed class Opt
    {
        public string Glyph;
        public string Text;
        public Action Run;
        public bool Danger;
        public Opt(string glyph, string text, Action run, bool danger = false) { Glyph = glyph; Text = text; Run = run; Danger = danger; }
    }

    /// <summary>Ventanitas encima de todo (menús, preguntas, escribir un nombre) sin abrir otra ventana.</summary>
    public static class Sheet
    {
        private static Grid Layer => MainWindow.Instance?.SheetLayer;
        public static bool IsOpen => Layer != null && Layer.Children.Count > 0;
        private static Action _onClose;

        public static void Show(UIElement content, double maxWidth = 520, Action onClose = null)
        {
            var layer = Layer;
            if (layer == null) return;
            layer.Children.Clear();
            _onClose = onClose;
            var scrim = new Border { Background = Ui.Hex("#B3000000") };
            bool pressed = false;
            scrim.MouseLeftButtonDown += (s, e) => pressed = true;
            scrim.TouchDown += (s, e) => pressed = true;
            scrim.MouseLeftButtonUp += (s, e) => { if (pressed) Close(); };
            scrim.TouchUp += (s, e) => { if (!pressed) return; Close(); e.Handled = true; };
            layer.Children.Add(scrim);
            var panel = new Border
            {
                Background = Ui.B("Panel"),
                BorderBrush = Ui.B("Stroke"),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(22),
                MaxWidth = maxWidth,
                Margin = new Thickness(18),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Center,
                Padding = new Thickness(0, 8, 0, 10),
                Child = content
            };
            panel.MaxHeight = Math.Max(300, (MainWindow.Instance?.ActualHeight ?? 700) * 0.86);
            panel.MouseLeftButtonUp += (s, e) => e.Handled = true;
            panel.TouchUp += (s, e) => e.Handled = true;
            layer.Children.Add(panel);
            layer.Visibility = Visibility.Visible;
            panel.Opacity = 0;
            var tt = new TranslateTransform(0, 24);
            panel.RenderTransform = tt;
            var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
            panel.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(160)));
            tt.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(200)) { EasingFunction = ease });
        }

        public static void Close()
        {
            var layer = Layer;
            if (layer == null || layer.Children.Count == 0) return;
            layer.Children.Clear();
            layer.Visibility = Visibility.Collapsed;
            var c = _onClose;
            _onClose = null;
            c?.Invoke();
        }

        private static FrameworkElement Header(string title, string subtitle, string art, bool round = false)
        {
            var g = new Grid { Margin = new Thickness(22, 14, 22, 10) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            if (art != null)
            {
                var c = Ui.Cover(art, 56, round ? 28 : 8);
                c.Margin = new Thickness(0, 0, 14, 0);
                g.Children.Add(c);
            }
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var t = Ui.T(title, 18, "Text", true, true);
            t.MaxHeight = 52;
            sp.Children.Add(t);
            if (!string.IsNullOrEmpty(subtitle))
            {
                var st = Ui.T(subtitle, 13, "Muted", false, true);
                st.Margin = new Thickness(0, 3, 0, 0);
                sp.Children.Add(st);
            }
            Grid.SetColumn(sp, 1);
            g.Children.Add(sp);
            return g;
        }

        /// <summary>Menú de opciones grandes (para el dedo).</summary>
        public static void Menu(string title, string subtitle, string art, IEnumerable<Opt> items)
        {
            var root = new DockPanel();
            var head = Header(title, subtitle, art);
            DockPanel.SetDock(head, Dock.Top);
            root.Children.Add(head);
            var line = new Border { Height = 1, Background = Ui.B("Stroke"), Margin = new Thickness(0, 4, 0, 6) };
            DockPanel.SetDock(line, Dock.Top);
            root.Children.Add(line);
            var list = new StackPanel();
            foreach (var it in items)
            {
                if (it == null) continue;
                var row = new Border { Height = 56, Padding = new Thickness(22, 0, 22, 0), Background = Brushes.Transparent, Cursor = Cursors.Hand };
                var sp = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                var ic = Ui.Icon(it.Glyph ?? G.More, 20, it.Danger ? "Muted" : "Text2");
                ic.Width = 30;
                ic.Margin = new Thickness(0, 0, 16, 0);
                sp.Children.Add(ic);
                var tx = Ui.T(it.Text, 16, it.Danger ? "Muted" : "Text");
                tx.VerticalAlignment = VerticalAlignment.Center;
                sp.Children.Add(tx);
                row.Child = sp;
                Ui.Hover(row);
                var action = it.Run;
                Ui.Tap(row, () => { Close(); action?.Invoke(); });
                list.Children.Add(row);
            }
            root.Children.Add(Ui.Scroll(list));
            Show(root);
        }

        /// <summary>Pregunta con dos botones.</summary>
        public static void Confirm(string title, string message, string ok, Action onOk, string cancel = "Cancelar")
        {
            var sp = new StackPanel { Margin = new Thickness(26, 18, 26, 12) };
            sp.Children.Add(Ui.T(title, 20, "Text", true, true));
            var m = Ui.T(message, 15, "Text2", false, true);
            m.Margin = new Thickness(0, 10, 0, 22);
            m.LineHeight = 22;
            sp.Children.Add(m);
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            if (cancel != null)
            {
                var c = Ui.Pill(cancel, Close);
                c.Margin = new Thickness(0, 0, 10, 0);
                buttons.Children.Add(c);
            }
            buttons.Children.Add(Ui.Pill(ok, () => { Close(); onOk?.Invoke(); }, true));
            sp.Children.Add(buttons);
            Show(sp, 520);
        }

        /// <summary>Escribir un texto (nombre de carpeta).</summary>
        public static void Input(string title, string hint, string initial, string ok, Action<string> onOk)
        {
            var sp = new StackPanel { Margin = new Thickness(26, 18, 26, 12) };
            sp.Children.Add(Ui.T(title, 20, "Text", true, true));
            var box = new TextBox { Style = Ui.S("Field"), Text = initial ?? "", Margin = new Thickness(0, 16, 0, 20), MaxLength = 60 };
            var hintText = Ui.T(hint ?? "", 16, "Muted2");
            hintText.IsHitTestVisible = false;
            hintText.Margin = new Thickness(20, 0, 0, 0);
            hintText.VerticalAlignment = VerticalAlignment.Center;
            var g = new Grid();
            g.Children.Add(box);
            g.Children.Add(hintText);
            hintText.Visibility = string.IsNullOrEmpty(box.Text) ? Visibility.Visible : Visibility.Collapsed;
            box.TextChanged += (s, e) => hintText.Visibility = box.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            hintText.Margin = new Thickness(20, 16, 0, 20);
            sp.Children.Add(g);
            Action done = () =>
            {
                string v = box.Text.Trim();
                if (v.Length == 0) return;
                Close();
                onOk?.Invoke(v);
            };
            box.KeyDown += (s, e) => { if (e.Key == Key.Enter) { done(); e.Handled = true; } };
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var c = Ui.Pill("Cancelar", Close);
            c.Margin = new Thickness(0, 0, 10, 0);
            buttons.Children.Add(c);
            buttons.Children.Add(Ui.Pill(ok, done, true));
            sp.Children.Add(buttons);
            Show(sp, 520);
            box.Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => { box.Focus(); box.SelectAll(); }));
        }
    }

    /// <summary>Avisos cortos abajo de la pantalla.</summary>
    public static class Toast
    {
        private static DispatcherTimer _timer;

        public static void Show(string text)
        {
            var host = MainWindow.Instance?.ToastHost;
            if (host == null || string.IsNullOrWhiteSpace(text)) return;
            host.Child = new TextBlock
            {
                Text = text,
                Foreground = Ui.B("OnGold"),
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                MaxWidth = 520
            };
            host.Visibility = Visibility.Visible;
            host.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(140)));
            if (_timer == null)
            {
                _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(2600) };
                _timer.Tick += (s, e) =>
                {
                    _timer.Stop();
                    var h = MainWindow.Instance?.ToastHost;
                    if (h == null) return;
                    var a = new DoubleAnimation(0, TimeSpan.FromMilliseconds(220));
                    a.Completed += (s2, e2) => h.Visibility = Visibility.Collapsed;
                    h.BeginAnimation(UIElement.OpacityProperty, a);
                };
            }
            _timer.Stop();
            _timer.Start();
        }
    }
}
