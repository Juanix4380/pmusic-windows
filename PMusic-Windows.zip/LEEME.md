# P Music para Windows (Surface Go 2 / Windows 10 y 11)

La misma app de música del teléfono, hecha para tablet táctil: negro y dorado, pestañas abajo
(Inicio, Buscar, Me gusta, Biblioteca), barra de "sonando ahora" y reproductor grande.

## Compilar en GitHub (sin computadora)

1. Crea un repositorio nuevo, por ejemplo `pmusic-windows` (puede ser privado).
2. Sube el archivo `.github/workflows/build.yml` en la ruta **`.github/workflows/`**
   (Add file → Upload files, escribiendo esa carpeta con el punto al inicio).
3. Sube `PMusic-Windows.zip` tal cual a la raíz del repositorio.
4. En **Actions** se compila solo (unos 4 minutos). Al terminar en verde, en **Releases** →
   **Assets** descarga **PMusic.exe** (no el zip del código).
5. Abre PMusic.exe en la Surface. Si Windows avisa "Windows protegió su PC": Más información → Ejecutar de todas formas.

No hay que instalar nada: es un solo .exe.

## Pantalla bloqueada (como el teléfono)

- La música **sigue sonando con la tablet bloqueada con Windows + L** y cuando **la pantalla se apaga sola**.
- En la **pantalla de bloqueo** aparecen la portada, el nombre y los botones **anterior / pausa / siguiente**
  (también en el panel de volumen y con las teclas multimedia del teclado de la Surface).
- Si Windows pausa la música al bloquear, apagar la pantalla o despertar, la app la **reanuda sola** donde iba.
- **Límite de Windows 11 (24H2 y más nuevo):** si presionas el botón de encendido para *suspender* o cierras
  la tapa del teclado, Windows corta el audio de todas las apps. Para que no pase, en
  *Tu cuenta y ajustes → Pantalla bloqueada* activa **"Botón de encendido: solo apagar la pantalla"**
  (o en Windows: Configuración → Sistema → Energía y batería → Controles de tapa y botón de encendido →
  "Al presionar el botón de encendido": **Apagar la pantalla**, con batería y con cargador).

## Carga de canciones

- Primero intenta el enlace directo (rápido). Al mismo tiempo baja la canción completa; si el enlace no abre
  en 10 s o se corta, sigue con la copia completa **en el mismo segundo** (no brinca a otra canción).
- La actual y las 2 siguientes se guardan en caché: el cambio es inmediato y un corte de internet no la detiene.
- **Sin internet** la canción espera y **sigue sola** cuando regresa la conexión.
- La primera vez que abres la app se prepara en segundo plano un método de respaldo (≈ 70 MB, una sola vez):
  si el rápido falla, la app usa ese automáticamente.

## Lo que trae

- **Entrar** con el mismo usuario y contraseña del teléfono (sesión de música, no usa conexiones de TV).
  Si el servicio principal no responde, ofrece el acceso alternativo **solo si tú aceptas** (sin cifrar).
- **Sincronización con el teléfono**: Me gusta, carpetas, recientes, artistas que sigues, canciones
  ocultas y **la canción donde te quedaste** (puedes seguir en la tablet lo que oías en el teléfono y al revés).
- **Inicio**: saludo, géneros rápidos, accesos rápidos, Tops y lanzamientos, Mixes para ti (por los artistas
  que más escuchas), Top México, tus Me gusta y lo escuchado recientemente.
- **Buscar**: sugerencias al escribir, búsquedas recientes, géneros, resultados que siguen cargando al bajar,
  Reproducir todo y Mix.
- **Me gusta**: reproducir, aleatorio, buscar dentro, ordenar (recientes, A-Z, artista) y descarga automática.
- **Biblioteca**: carpetas (crear, renombrar, borrar, descarga automática), recientes, descargas y artistas.
- **Reproductor**: portada grande, barra de avance, aleatorio, repetir (lista / canción), volumen,
  **cola** (saltar, quitar, limpiar), **letra sincronizada** (toca una línea para ir ahí), **mix de canciones
  parecidas**, agregar a carpeta, descargar y **temporizador** (15–90 min o al terminar la canción).
- **Reproducción automática**: al terminar tu lista siguen canciones parecidas.
- **Descargas** para escuchar sin internet en *Música › P Music*.
- Caché de 1.5 GB: la siguiente canción se prepara antes, así el cambio es inmediato y sin cortes.

## Táctil, mouse y teclado

| Acción | Cómo |
|---|---|
| Opciones de una canción | Tres puntitos, dejar presionado o clic derecho |
| Abrir reproductor grande | Tocar la barra de "sonando ahora" |
| Pausa / reproducir | Espacio |
| Siguiente / anterior | Ctrl + → / Ctrl + ← (o teclas multimedia) |
| Adelantar / regresar 10 s | → / ← en el reproductor grande |
| Me gusta a la canción actual | Ctrl + L |
| Buscar | Ctrl + F |
| Regresar | Esc o deslizar atrás del mouse |
| Pantalla completa | F11 |

## Notas

- Los datos de la app están en `%LocalAppData%\PMusic` (registro de errores en `log.txt`).
- La contraseña y la sesión se guardan cifradas con tu usuario de Windows.
- Si algo falla, manda foto de `%LocalAppData%\PMusic\log.txt` (ahí dice qué método se usó y por qué falló).
